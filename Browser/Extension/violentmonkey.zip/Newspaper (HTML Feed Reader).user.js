// ==UserScript==
// @name         Newspaper (HTML Feed Reader)
// @namespace    i2p.schimon.newspaper
// @description  Native Feed Viewer. Render syndication feeds (supports ActivityStreams, Atom, JSON Feed, OPML, RDF, RSS, RSS-in-JSON and SMF)
// @author       Schimon Jehudah
// @collaborator CY Fung
// @collaborator NotYou
// @homepageURL  https://sjehuda.github.io/newspaper.html
// @supportURL   https://greasyfork.org/en/scripts/465932-newspaper/feedback
// @copyright    2023 - 2024, Schimon Jehudah (http://schimon.i2p)
// @license      MIT; https://opensource.org/licenses/MIT
// @icon         data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDAgMTAwIj48dGV4dCB5PSIuOWVtIiBmb250LXNpemU9IjkwIj7wn5OwPC90ZXh0Pjwvc3ZnPgo=
// @exclude      *?streamburner_active=0
// @exclude      *&streamburner_active=0
// @match        file:///*
// @match        *://*/*
// @version      24.07.19
// @run-at       document-start
// @grant        GM.setValue
// @grant        GM.getValue
// @grant        GM.registerMenuCommand
// @downloadURL https://update.greasyfork.org/scripts/465932/Newspaper%20%28HTML%20Feed%20Reader%29.user.js
// @updateURL https://update.greasyfork.org/scripts/465932/Newspaper%20%28HTML%20Feed%20Reader%29.meta.js
// ==/UserScript==

/*

TODO

ADD AN XSLT TO THE OPML!

XPath: Migrate to XPath so that it would be easier to
select and possible to select elements with colon.

json https://www.timburton.com/news?format=json

Open directly from HTML
To overcome XML -> HTML issue
To open files foced to be downloaded https://ffmpeg.org/main.rss

Follow: Drop-down menu
Next and Previous to be at the left side

Ad filtering

Place Subtitles under About title which will be placed at the bottom of the page
May include feed icon too
See https://forums.ubports.com/topic/3257.rss

Turn subtitle (top) to about (bottom)
https://ethresear.ch/t/design-idea-to-solve-the-scalability-problem-of-a-decentralized-social-media-platform/10523.rss

FIXME

12bytes
https://12bytes.org/feed.json
https://12bytes.org/feed.xml

https://trung.fun/atom.en.xml
https://git.sr.ht/~mil/sxmo-utils/log/master/rss.xml (Falkon)
https://www.gov.im/news/RssNews (XSLT stylesheet is absent (404) and that causes the script not to work)

LTR/RTL
https://www.sbtxt.co.il/collections/sabrina.atom
https://sabrinabutterflydesigns.ca/collections/socks.atom
http://www.ynet.co.il/Integration/StoryRss3086.xml

CSS
https://schollz.com/index.xml

TEST FEEDS

http://feeds.japan.cnet.com/rss/cnet/lessig.rdf

NOTE

Enclosures and filesize are realized as expected
https://feeds.podcastmirror.com/higherside-chats

*/

const
  namespace = 'i2p.schimon.newspaper',
  defaultTitle = 'Streamburner',
    // This news feed is brought to you by Streamburner News Reader
  defaultSubtitle = 'News feed rendered with Streamburner',
  defaultAbout = 'No description was provided.',
  rtlLocales = ['ar', 'fa', 'he', 'ji', 'ku', 'ur', 'yi'],
  atomRules = {
    "feedLanguage" : "feed", // NOTE @xml:lang
    "feedTitlePage" : "feed > title",
    "feedSubtitle" : "feed > subtitle",
    "feedLink" : "feed > link",
    "feedDate" : "updated",
    "feedGenerated" : "feed > generator",
    "feedItem" : "entry",
    "feedItemTitle" : "title",
    "feedItemLink" : "link", // NOTE varies and doesn't always contain rel='alternate'
    "feedItemPublished" : "published",
    "feedItemDate" : "updated",
    "feedItemAuthor" : "author",
    "feedItemContent" : "content",
    "feedItemSummary" : "summary",
    "feedItemEnclosure" : "link[rel='enclosure']"
  },
  rdfRules = {
    "feedLanguage" : "channel > language", // TODO Test
    "feedTitlePage" : "channel > title",
    "feedSubtitle" : "channel > description",
    "feedLink" : "channel > link",
    "feedDate" : "date",
    "feedGenerated" : "channel > generator", // TODO Test
    "feedItem" : "item",
    "feedItemTitle" : "title",
    "feedItemLink" : "link",
    "feedItemPublished" : "published", // NOTE Exist?
    "feedItemDate" : "date",
    "feedItemAuthor" : "creator", // dc:publisher
    "feedItemContent" : "description",
    "feedItemEnclosure" : "resource" // TODO Test
  },
  rssRules = {
    "feedLanguage" : "channel > language",
    "feedTitlePage" : "channel > title",
    "feedSubtitle" : "channel > description",
    "feedLink" : "channel > link",
    "feedDate" : "lastBuildDate",
    "feedGenerated" : "channel > generator",
    "feedItem" : "item",
    "feedItemTitle" : "title",
    "feedItemLink" : "link",
    "feedItemPublished" : "published", // NOTE Exist?
    "feedItemDate" : "pubDate",
    "feedItemAuthor" : "dc:creator", // Discourse uses dc:creator
    "feedItemContent" : "description",
    // NOTE prefer content:encoded
    // https://agovernmentofwolves.com/feed/
    //"feedItemSummary" : "content\\:encoded",
    "feedItemEnclosure" : "enclosure",
    "feedItemMedia" : "media:content" // CSS Selectors do not work (not even with CSS.escape `media\\:content`. Move to XPath
  },
  smfRules = {
    // FIXME "smf\\:xml-feed" doesn't appear to work
    // or at least not when it's comming from json
    "feedLanguage" : "smf\\:xml-feed", // NOTE @xml:lang
    "feedTitlePage" : "smf\\:xml-feed", // NOTE @forum-name
    "feedSubtitle" : "smf\\:xml-feed", // NOTE @description
    "feedLink" : "smf\\:xml-feed",
    "feedDate" : "time", // NOTE @generated-date-UTC @generated-date-localized
    "feedGenerated" : "generator",
    "feedItem" : "recent-post",
    "feedItemTitle" : "subject",
    "feedItemLink" : "topic > link",
    "feedItemPublished" : "published", // NOTE Exist?
    "feedItemDate" : "time",
    "feedItemAuthor" : "poster",
    "feedItemContent" : "body",
    "feedItemEnclosure" : "enclosure" // NOTE Doesn't exist
  },
  opmlRules = {
    "feedLanguage" : "head > language", // NOTE Doesn't exist
    "feedTitlePage" : "head > title",
    "feedSubtitle" : "head > description",
    "feedLink" : "head > urlPublic",
    "feedDate" : "head > dateModified", // dateCreated
    "feedItem" : "body outline",
    "feedItemTitle" : "title",
    "feedItemLink" : "htmlUrl",
    "feedItemPublished" : "published", // NOTE Doesn't exist
    "feedItemDate" : "created",
    "feedItemContent" : "description",
    "feedItemSummary" : "text",
    "feedItemEnclosure" : "xmlUrl"
  },
  banner = `<svg width="256" height="100" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient x1="77.1180071%" y1="12.3268731%" x2="3.36110907%" y2="118.781335%" id="a"><stop stop-color="#D446FF" offset="0%"/><stop stop-color="#A0D8FF" offset="100%"/></linearGradient><linearGradient x1="50.7818321%" y1="-17.173918%" x2="76.3448843%" y2="77.2144178%" id="b"><stop stop-color="#3C3C3C" offset="0%"/><stop stop-color="#191919" offset="100%"/></linearGradient><linearGradient x1="148.794275%" y1="-26.5643443%" x2="-21.1415871%" y2="99.3029307%" id="c"><stop stop-color="#D446FF" offset="0%"/><stop stop-color="#A0D8FF" offset="100%"/></linearGradient><linearGradient x1="41.8083357%" y1="20.866645%" x2="95.5956597%" y2="-8.31097281%" id="d"><stop stop-color="#FFF" offset="0%"/><stop stop-color="#DADADA" offset="100%"/></linearGradient><linearGradient x1="52.2801818%" y1="70.5577815%" x2="2.53678786%" y2="8.97706744%" id="e"><stop stop-color="#FFF" offset="0%"/><stop stop-color="#DADADA" offset="100%"/></linearGradient><linearGradient x1="98.684398%" y1="12.9995489%" x2="35.2678133%" y2="40.863838%" id="f"><stop stop-color="#D0D0D0" offset="0%"/><stop stop-color="#FFF" offset="100%"/></linearGradient><linearGradient x1="34.2841787%" y1="31.6476155%" x2="-40.2132134%" y2="123.398162%" id="g"><stop stop-color="#FFDC68" offset="0%"/><stop stop-color="#CE4300" offset="100%"/></linearGradient><linearGradient x1="95.7086811%" y1="2.33776624%" x2="-10.5474304%" y2="34.7418529%" id="h"><stop stop-color="#FFDC68" offset="0%"/><stop stop-color="#CE4300" offset="100%"/></linearGradient><linearGradient x1="55.2222258%" y1="39.6484627%" x2="-63.5655829%" y2="222.055577%" id="i"><stop stop-color="#FFDC68" offset="0%"/><stop stop-color="#CE4300" offset="100%"/></linearGradient></defs><g fill="none" fill-rule="evenodd"><path fill="#252525" fill-rule="nonzero" d="M68.3766216 33.24450169V46.6414437h17.1215335v4.3309176H68.3766216v18.9693703h-4.9083597V28.91359256h23.7622535v4.33090913H68.3766216zm31.2822046-4.92645583h5.5724368L119.81199 69.3461849h-4.966111l-4.157673-11.9244357H93.7687843l-4.1576731 11.9244357H85.078099l14.5807272-41.02813904Zm2.5696738 4.7928662L95.241299 53.1197155h13.945526L102.2285 33.11091206Zm20.879509-4.1973195h4.90836V65.6397065h18.420795v4.3020251h-23.329155zm27.650382 0h4.908369V69.9417316h-4.908369zm48.41257-.4253905c2.714031 0 5.245206.48121024 7.593526 1.44363071 2.367565.9431758 4.407905 2.28094667 6.121021 4.01331259 1.732366 1.73235454 3.089381 3.89780774 4.071046 6.49635944.981671 2.5792957 1.472507 5.4184455 1.472507 8.5174493 0 4.1961709-.837308 7.9303791-2.511923 11.2026246-1.655364 3.2529952-3.965184 5.7745455-6.929458 7.5646511-2.945012 1.770861-6.284623 2.6562914-10.018831 2.6562914-2.463811 0-4.82175-.43309-7.073818-1.2992702-2.252074-.8854361-4.282792-2.1654616-6.092154-3.8400765-1.80935-1.6746149-3.252981-3.8593184-4.330892-6.5541105-1.077922-2.7140367-1.616884-5.7649203-1.616884-9.1526508 0-3.1759995.490836-6.0825226 1.472507-8.7195693.981676-2.6370411 2.329072-4.8506144 4.042188-6.64072001 1.713115-1.8093616 3.753455-3.20487781 6.12102-4.18654862 2.367559-1.00091547 4.927607-1.50137321 7.680145-1.50137321Zm-.259854 4.30203363c-1.751611 0-3.435857.32722172-5.052738.98166514-1.616863.65445477-3.108617 1.61688087-4.475261 2.88727847-1.347399 1.2511471-2.434941 2.9450124-3.262626 5.0815957-.808429 2.117333-1.212643 4.5137703-1.212643 7.1893121 0 2.560051.375344 4.9276129 1.126034 7.1026855.750689 2.1558337 1.770858 3.9651924 3.060506 5.4280763 1.289648 1.4628896 2.810277 2.5985489 4.561887 3.406978 1.770867.8084405 3.666844 1.2126607 5.687931 1.2126607 1.366643 0 2.704411-.2021115 4.013304-.6063346 1.328148-.4042174 2.598552-1.0394161 3.811209-1.9055963 1.212647-.8854361 2.271313-1.9633529 3.176-3.2337505.923925-1.2703975 1.655367-2.8391469 2.194326-4.7062481.558203-1.867107.837304-3.9170723.837304-6.149896 0-2.2713186-.288726-4.3501538-.86618-6.2365054-.577453-1.8863516-1.347393-3.4647261-2.309819-4.7351237-.943176-1.2704032-2.049963-2.3386948-3.32036-3.2048749-1.251159-.88543618-2.550435-1.52063777-3.897828-1.90560483-1.328143-.40421172-2.685158-.60631758-4.071046-.60631758Zm23.397966-3.87664313h6.207638l22.347481 34.32967654V28.91359256h4.908369V69.9417316h-6.20763l-22.34749-34.3874106v34.3874106h-4.908368V28.91359256z"/><path fill="url(#a)" fill-rule="nonzero" d="M174.265411 4.50913925h6.14987L163.062778 24.0848526l-6.178763.4042146z" transform="translate(0 25)"/><path fill="url(#b)" fill-rule="nonzero" d="M162.552309 23.4815553 181.00198 44.933981h-6.323132l-18.305302-21.0482111z" transform="translate(0 25)"/><g transform="translate(0 25)"><ellipse stroke="#A3A3A3" stroke-width=".5" fill="url(#c)" fill-rule="nonzero" cx="26.8134179" cy="26.3507547" rx="26.805321" ry="26.3202814"/><path d="M9.37216085 52.0819111S17.7489335 22.7696899 50.3566889 26.4969018c0 0-20.723434-12.3020208-40.84161386 4.2828996-5.94153114 13.7625736-.14291419 21.3021097-.14291419 21.3021097Z" fill="url(#d)"/><path d="M11.8660211 48.3743096s8.7405326-21.0730284 32.0717549-21.4433648c-17.7350232 4.3205976.0290967 19.6378374.0290967 19.6378374s-14.0287234 12.7111189-32.1008516 1.8055274Z" fill="url(#e)"/><path d="M6.99959641 32.2202162S24.4574437 13.0165918 50.527832 26.2845469c-.4655559-3.607941-3.5497731-7.6814378-9.0780884-8.8452977-1.2220448-.5819257-10.1837464-14.43182348-29.4455641-6.459393 5.9256811.461387 8.4682656 1.291426 8.612541 1.9203488C10.369106 11.1390373 7.33148608 25.722572 6.99959641 32.2202162Z" fill="url(#f)"/><path d="M32.03706 15.9299212s4.4665322-1.5996384 5.0482196 3.1577417c-4.4042039.4155129-5.0482196-3.1577417-5.0482196-3.1577417Z" fill="#202020"/><path d="M9.2551104 52.1772666s7.6361082-24.9093105 33.1663186-25.8730411c0 0-20.7166787-3.7798413-35.34817197 19.3977044-.08112197 3.2790716 2.18185337 6.4753367 2.18185337 6.4753367Z" fill="url(#g)"/><path d="M12.0256021 10.9822724s6.3677384.3703449 8.6411954 1.9339868c.9492333-.1952797 1.7552122-.8451998 1.892222-1.7303694-.8145463-.337105-8.2702464-.9442903-10.5334174-.2036174Z" fill="url(#h)"/><path d="M7.05701562 32.2533371s7.97220928-9.5753699 24.06662038-10.719313c0 0-21.9094907.9901814-23.7487686 7.1768481-.5113449 1.4876671-.31785178 3.5424649-.31785178 3.5424649Z" fill="url(#i)"/></g></g></svg>`,
  quote = `
<p>"The technology that Big Corps, Fortune 500 and Mozilla et al. want you to forget".</p>
<p>-- Alex J. Anderson</p>`,
  htmlSettings = `
<div class="about-newspaper" id="page-settings">
  <h1>Settings</h1>
  <p>Settings are saved instantly upon click.</p>
  <p>Reload for changes to take affect.</p>
  <h2>Appearance</h2>
  <table>
    <tr>
      <td>
        <span>Icon</span>
      </td>
      <td>
        <span>
          <input type="checkbox" name="hide-icon" id="hide-icon"/>
          <label for="hide-icon">Disable Icon</label>
        </span>
      </td>
    </tr>
    <tr>
      <td>
        <span>Articles</span>
      </td>
      <td>
        <span>
          <input type="number" name="item-number" id="item-number" min="3" max="50"/>
          <label>№</label>
        </span>
        <p>Maximum number of articles to display (5 - 50)</p>
      </td>
    </tr>
      <tr>
        <td>
          <span>Text Size</span>
        </td>
        <td>
          <span>
            <input type="number" name="font-size" id="font-size" min="20" max="35"/>
            <label>px.</label>
          </span>
        </td>
      </tr>
      <tr>
        <td>
          <span>Font Style</span>
        </td>
        <td>
          <span>
            <select name="font-type" id="font-type">
              <option value="system-ui">System Default</option>
              <option value="arial">Arial</option>
              <option value="sans">Sans</option>
              <option value="serif">Serif</option>
              <option value="tahoma">Tahoma</option>
            </select>
          </span>
        </td>
      </tr>
      <tr>
        <td>
          <span for="view-mode">Mode</span>
        </td>
        <td>
          <span>
            <select name="view-mode" id="view-mode">
              <option value="bright">Bright</option>
              <option value="dark">Dark</option>
              <option value="sepia">Sepia</option>
            </select>
          </span>
        </td>
      </tr>
      <tr>
        <td>
          <span>Content</span>
        </td>
        <td>
          <span>
            <select name="content" id="content">
              <option value="none">None (Only Title)</option>
              <option value="excerpt">Prefer Excerpt</option>
              <option value="full">Prefer Complete</option>
            </select>
          </span>
        </td>
      </tr>
      <tr>
        <td>
          <span>Stylesheet</span>
        </td>
        <td>
          <span>
            <select name="stylesheet" id="stylesheet">
              <option value="blacklistednews">BlackListedNews</option>
              <option value="waco">Davidian</option>
              <option value="falkon">Falkon</option>
              <option value="greasyfork">Greasy Fork</option>
              <option value="msie">Internet Explorer</option>
              <option value="minicss">mini.css</option>
              <option value="openuserjs">OpenUserJS</option>
              <option value="opera">Opera</option>
              <option value="otter">Otter</option>
              <option value="palemoon">Pale Moon</option>
              <option value="pioneer">Pioneer</option>
              <option value="qupzilla">QupZilla</option>
              <option value="rubyridge">Ruby Ridge</option>
              <option value="simplecss">Simple.css</option>
              <option value="superfastpython">SuperFastPython</option>
              <option value="netscape">Netscape</option>
              <option value="7css">Win7</option>
              <option value="98css">Win9x (ReactOS)</option>
              <option value="xpcss">WinXP</option>
            </select>
          </span>
        </td>
    </tr>
    <tr>
        <td>
          <span>Podcast</span>
        </td>
        <td>
          <span>
            <input type="checkbox" name="play-enclosure" id="play-enclosure"/>
            <label for="play-enclosure">Play Audio</label>
          </span>
          <span>
            <input type="checkbox" name="disable-enclosure" id="disable-enclosure"/>
            <label for="disable-enclosure">Disable Enclosures</label>
          </span>
        </td>
      </tr>
      <tr>
        <td>
          <span>Content</span>
        </td>
        <td>
          <span>
            <input type="checkbox" name="hide-content" id="hide-content"/>
            <label for="hide-content">Content</label>
          </span>
        </td>
      </tr>
      <tr>
        <td>
          <span>Hide Media</span>
        </td>
        <td>
          <span>
            <input type="checkbox" name="hide-audio" id="hide-audio"/>
            <label for="hide-audio">Audio</label>
          </span>
          <span>
            <input type="checkbox" name="hide-image" id="hide-image"/>
            <label for="hide-image">Image</label>
          </span>
          <span>
            <input type="checkbox" name="hide-media" id="hide-media"/>
            <label for="hide-media">Media</label>
          </span>
          <span>
            <input type="checkbox" name="hide-video" id="hide-video"/>
            <label for="hide-video">Video</label>
          </span>
        </td>
      </tr>
    <h2>Content Control</h2>
    <p>Control and filter contents.</p>
    <table>
      <tr>
        <td>
          <span>Filtering</span>
        </td>
        <td>
          <span>
            <input type="checkbox" name="filter" id="filter"/>
            <label for="filter">Enable</label>
          </span>
        </td>
      </tr>
      <tr>
        <td>
          <span>Keywords</span>
        </td>
        <td>
          <span>
            <input type="text" name="keywords" id="keywords"/>
            <label>(comma separates)</label>
          </span>
        </td>
      </tr>
    </table>
    <h2>Subscription handler</h2>
    <p>Select an online service or software to subscribe with.</p>
    <table>
      <tr>
        <td>
          <span>Handler</span>
        </td>
        <td>
          <span>
            <select name="handler" id="handler">
              <option value="desktop">Desktop</option>
              <option value="commafeed">CommaFeed</option>
              <!-- option value="drummer">Drummer</option -->
              <!-- option value="feedbin">Feedbin</option -->
              <!-- option value="feeder">Feeder</option -->
              <!-- option value="feedhq">FeedHQ</option -->
              <!-- option value="feeds">Feeds</option -->
              <!-- option value="feedsonfeeds">Feeds on Feeds</option -->
              <!-- option value="feedland">FeedLand</option -->
              <option value="feedly">Feedly</option>
              <!-- option value="freshrss">FreshRSS</option -->
              <!-- option value="goodnews">Good News</option -->
              <!-- option value="inoreader">Inoreader</option -->
              <!-- option value="miniflux">Miniflux</option -->
              <!-- option value="netvibes">Netvibes</option -->
              <!-- option value="newsblur">NewsBlur</option -->
              <!-- option value="rawdog">rawdog</option -->
              <!-- option value="reader">Reader</option -->
              <!-- option value="reedah">Reedah</option -->
              <!-- option value="rrss">RRSS</option -->
              <!-- option value="selfoss">selfoss</option -->
              <option value="subtome">SubToMe</option>
              <!-- option value="theoldreader">The Old Reader</option -->
              <!-- option value="tt-rss">Tiny Tiny RSS</option -->
              <!-- option value="yarr">yarr</option -->
              <!-- option value="yarrharr">Yarrharr</option -->
              <option value="custom">Custom</option>
            </select>
          </span>
        </td>
      </tr>
    </table>
    <table>
      <tr>
        <td>
          <span>Instance</span>
        </td>
        <td>
          <span>
            <input type="text" name="instance" id="instance"/>
            <label>Enter instance URL.</label>
          </span>
        </td>
      </tr>
    </table>
    <p>Select "Desktop" to use software installed on your device or machine and "Custom" for a custom online reader that is not included on the list.</p>
  </table>
  <div id="buttons">
    <button id="reload">Reload</button>
    <button id="close">Return</button>
  </div>
  <p>* Click reload to apply changes.</p>
</div>`,
  htmlSupport = `
<div class="about-newspaper" id="page-support">
  <h1>Donations</h1>
  <h2>No, thank you. Yet, I do appreciate your concern.</h2>
  <p>Here are some things you can do instead, in no particular order…</p>
  <ul>
    <li>Promote <a href="https://www.rfc-editor.org/rfc/rfc4287">The Atom syndication Format</a>, <a href="https://geminiprotocol.net/">Project Gemini</a>, <a href="https://joinjabber.org/">Jabber</a> (aka XMPP) and BitTorrent in order to get us out from the HTML5 calamity to a better telecommunication system.</li>
    <li>Talk with your friends about the benefits of syndication feeds. That would be a good table talk.</li>
    <li>Use a feed reader. (See list of software in Help menu)</li>
    <li>Teach other people to use feed readers. Blog about feed readers. And about other open technologies and apps.</li>
    <li>Write a blog instead of posting to “social networks”. (You can always re-post to those places if you want to extend your reach.) <a href="https://www.justjournal.com/">Just Journal</a>, <a href="https://micro.blog/">Micro.blog</a> and <a href="https://monocles.social/">monocles.social</a> are good places to get going, and these are not the only ones.</li>
    <li>Petition <a href="http://unicode.org/pending/proposals.html">unicode.org</a> and promote the initiative for the <a href="https://github.com/vhf/unicode-syndication-proposal">Proposal to Include Syndication Symbol</a>.</li>
    <li>Donate to charities that promote literacy.</li>
    <li>Tell other people about cool blogs and feeds you’ve found.</li>
    <li>Support independent podcast apps and desktop software.</li>
    <li>Support your local library.</li>
    <li>Be bold and do your best work.</li>
    <li>Support indie developers. Even though software like Falkon, Newspaper, postmarketOS etc. are free, software are most definitely not free to make, and it costs time and effort to keep improving them. It’s worth it.</li>
    <li>Finally: report bugs and make feature requests on our Issues tracker. We also need testers, writers, and, especially, people who are willing to talk things over. Most of software development is just making decisions, and we appreciate all the help we can get!</li>
    <li>Or: skip helping us, and, instead, help people who need help more than we do. Those people should not be hard to find.</li>
    <li>Buy a meal to a person in need, or, even better, get a job for him or her.</li>
    <li>Establish a family, or if you already are a father or a mother, bring a new healthy child to the world.</li>
    <li>Get more ideas from <a href="https://github.com/Ranchero-Software/NetNewsWire/blob/main/Technotes/HowToSupportNetNewsWire.markdown#here-are-some-things-you-can-do">Ranchero-Software/NetNewsWire</a>.</li>
  </ul>
  <p>If you happen to visit in the Middle East, reach me out and we can meet for a café or tea.</p>
  <p>Sharing is caring, and is exactly what makes us humans.  It's "all of us for all of us" or we're on our own.</p>
  <p>Schimon</p>
  <div class="decor"></div>
  <div class="quote">
    <p>(The syndication technology behind ActivityPub, Atom and XMPP is)</p>
    <p>"The very simple technology that Big Corps, Fortune 500, Mozilla et al. are jealously trying to oppress and conceal from you";</p>
    <p>"Because it unleashes the embodiment of what free and open telecommunication should really be, a truely free-speech-driven internet."</p>
    <p>"The problem, for them, is that if true openness would flourish, it might have the "dire" potential, at least for them, to put many of them off the market".</p>
    <p>-- Alex J. Anderson</p>
  </div>
  <div id="buttons">
    <button class="return-to-feed">Return</button>
  </div>
</div>`,
  htmlAbout = `
<div class="about-newspaper" id="page-about">
  <!-- div id="buttons-custom">
    <span class="button" id="back">❰ Table of Contents</span>
    <span class="button" id="close">Return to Syndication Feed ❱</span>
  </div -->
  <div id="table-of-contents" class="segment">
  <h1>Table Of Contents</h1>
  <ul class="content" id="about-toc">
    <li><a href="#intro">News Feeds And Their Benefits</a></li>
    <li><a href="#feeds"><b>Subscribe To Feeds</b></a></li>
    <li><a href="#software"><b>Get A Feed Reader</b></a></li>
    <!-- li><a href="#services-publish"><b>Speak Your Mind - Unlimitedly</b></a></li -->
    <li><a href="#services-publish"><b>Speak Your Mind</b></a></li>
    <li><a href="#blog">Be A Publisher</a></li>
    <li><a href="#searx">Monitor Your Online Presence</a></li>
    <li><a href="#services-feed"><b>Syndication Feed Services And Software</b></a></li>
    <li><a href="#learn">A Historical Overview</a></li>
    <li><a href="#xslt">The XSLT Technology</a></li>
    <li><a href="#xmpp"><b>Atom Over XMPP: Jabber As A Syndication Platform</b></a></li>
    <!-- li><a href="#html5">The Trouble With CSS3 and JavaScript</a></li -->
    <li><a href="#plea">An Appeal From The Author</a></li>
    <li><a href="#matter"><b>Why Syndication Feeds Matter So Much?</b></a></li>
    <li><a href="#shame">Who Is Trying To Hide Syndication Feeds And Why?</a></li>
    <li><a href="#mozilla">Red Lizard Attacks And Shenanigans</a></li>
    <li><a href="#advertising">The Case Against Advertisers</a></li>
    <li><a href="#proof">Proving That Syndication Feeds Are At A High Demand</a></li>
    <li><a href="#even">Even <i>"They"</i> Have Syndication Feeds</a></li>
    <li><a href="#reason">Another Reason Why Syndication Feeds Will Not Stop</a></li>
    <li><a href="#alternative">What Are The Alternatives?</a></li>
    <li><a href="#support">Learn How You Can Help</a></li>
    <li><a href="#resources">Useful Resources</a></li>
    <li><a href="#memory">To Mr. Anderson</a></li>
    <li><a href="#disclaimer">Disclaimer</a></li>
    <li><a href="#force">About Us</a></li>
  </ul>
  </div>
  <div id="intro" class="segment">
  <h1>👋️ Greetings Syndication Feeds!</h1>
  <h2>Syndicate. Collect. Share!</h2>
  <h3><abbr title="Too long; didn't read">TL;DR</abbr></h3>
  <div class="background">
    <p>RSS (Really Simple Syndication or Rich Site Summary) is a service that allows people to receive news articles from sites quickly and conveniently through the installation of an RSS reader similar to e-mail.</p>
    <p>News provide by RSS news can be allocated into sections, including cultural, economy, international, national, politics, and special feature news.</p>
    <p>Through RSS, you can easily receive news updates on your PC, mobile and tablet without visiting the site yourself.</p>
    <p>Use RSS service to receive news on any site fast and easy.</p>
    <hr/>
    <p>Subscribing to an Atom or RSS feed (henceforth "Syndication Feed") spares the need for you to manually check the site for new content.</p>
    <p>Instead, a software known as "Feed Reader" or "RSS Reader" does that task for you, by constantly monitoring the sites you follow and it automatically informs you of any updates.</p>
    <p>The software can also be commanded to automatically download the new data for you (e.g. Audio Podcasts, Documents, Torrents, Videos etc.).</p>
  </div>
  <div>
    <p>In short, using syndication feeds free you from the manual news checking task.</p>
  </div>
  <h3>About <span class="text-icon orange">Atom</span> &amp; <span class="text-icon orange">RSS</span> Syndication Feeds</h3>
  <h4>A Brief Introduction To A Time-saving Technology</h4>
  <div class="content">
    <p>A syndication feed can include news articles, press releases, blog posts, updates and other changing contents, including audio files (PodCasts), video files (VodCasts), and even BitTorrent files that would let your BitTorrent client to automaticlly download the latest of the latest as soon as it is published.</p>
    <p>Once you subscribe to a feed, the Feed Reader automatically checks for new content and organizes it in an easily and readable format, and it keeps you updated with the latest news, and you can collect syndication feeds from various of sources in one place without visiting multiple sites.</p>
    <p>To retrieve syndication feed content, you can download Feed Readers or use browsers that support syndication feeds.</p>
    <p><b>Note:</b> RSS is an abbreviation of "Really Simple Syndication". Atom Syndication Format (RFC 4287) is the standard for RSS.</p>
  </div>
  <div>
  <h3>Syndicated Daily News</h3>
  <!-- h4>The Works Of RSS: Simplified Explanation And Benefits</h4 -->
  <!-- h4>How RSS Works: Simplified Explanation And Benefits</h4 -->
  <h4>How Syndication Feeds Work: Simplified Explanation And Benefits.</h4>
  <div class="content">
    <p>Syndication News Feeds form a mean for content and media publishers to reach a wider audience easily.  They allow you to receive information directly without the going from site to site.</p>
    <p>Essentially, feeds, as a whole, embody a function that allows “Feed Readers” to access multiple sites, automatically looking for new contents and then posting the information about new contents and updates to another site, mobile app or desktop software at your office.</p>
    <p>Feeds provide a simple way to keep up with the latest news, events, package and delivery status information posted on different sites such as news sites, music sites, content sites (aka “social networks”), torrent indexers, podcasts and <a href="#feeds" class="link">more</a>; all, in one single spot.</p>
    <p>In the hope that you would find this software useful; and in the hope that you would enjoy and get the most out of this software!</p>
    <p>Read more on <a href="http://rss.userland.com/howUseRSS">How You Can Use RSS</a> and <a href="http://rss.userland.com/whyImportant">Why is RSS Important?</a> and <a href="https://marcus.io/blog/making-rss-more-visible-again-with-slash-feeds">Making RSS more accessible with a /feeds page</a>.</p>
  </div>
  </div>
  <div id="who">
  <h3>Who Is Using Syndication Feeds And What For?</h3>
  <h4>Learn How You Can Take Advantage of Syndication Feeds</h4>
  <div class="content">
    <p>Amongst those who make use of syndication feeds are Accountants, Analysts, Engineers, Farmers, Government Ministries, Intelligence Agencies, Lawyers, Militaries, Parliaments, Police, Programmers, Publishers, Realtors, Reasearchers, Statisticians, Tribunals, Weather Stations, and many others.</p>
    <p>And the uses are vast, to name just a few:</p>
    <ul>
      <li>Publishing of events;</li>
      <li>Monitoring of inventory;</li>
      <li>Receiving search results;</li>
      <li>Sharing of data and information;</li>
      <li>Automating BitTorrent downloads;</li>
      <li>Publishing of laws and regulations;</li>
      <li>Weather forecasting and monitoring;</li>
      <li>Monitoring of stock market and trades;</li>
      <li>Publishing of court decisions and verdicts;</li>
      <li>Publishing of real estate and vacancy boards;</li>
      <li>Communicating of information, including mailing-list archives;</li>
      <li>Publishing blog posts and news updates, including urgent ones;</li>
      <li>Managing, remote controlling and supervising of automated machines (IoT, so called) and peripherals; and</li>
      <li>So much more…</li>
    </ul>
    <p>Start Using Syndication Feeds, <i>Today!</i></p>
  </div>
  </div>
  </div>
  <span class="decor"></span>
  <!-- div><span>📗 Recommended Feeds</span -->
  <!-- div><span>{ } &lt;rss&gt; Is Everywhere</span -->
  <div id="feeds" class="segment">
  <h1><span class="text-icon orange">Feeds</span> Are Everywhere</h1>
  <!-- h2>It is no secret that all the pros on the Internet make an extensive use of Syndication Feeds</h2 -->
  <h2>It’s a Well-known Fact That The Internet Pros Extensively Leverage The Power Of Syndication Feeds To Stay Updated With The Latest Information and Trends</h2>
  <div class="content">
    <p>This is a list of feeds that should get you started with your news reader <a href="#software" class="link">app or software</a>.</p>
    <p>You can download this list as an <span class="cursor-pointer" id="opml-selection"><u>OPML Outline</u></span> file which can be imported into other feed readers.</p>
    <p>The filetype formats of the feeds below are vary, from ActivityStreams and JSON to Atom and RDF, not only RSS.</p>
    <p class="background center">Random news feed from <a class="feed-category"></a>: <b><a class="feed-url"></a></b></p>
    <h3>Categories</h3>
    <ul>
      <li><a href="#art">Art, Culture, Literature &amp; Photography</a></li>
      <li><a href="#automation">Automation</a></li>
      <li><a href="#blogroll">Blogroll &amp; Webring</a></li>
      <li><a href="#business">Business &amp; Careers</a></li>
      <li><a href="#code">Coding, Development, SysAdmin &amp; Tutorials</a></li>
      <li><a href="#entertainment">Comic, Entertainment, Games &amp; Memes</a></li>
      <li><a href="#events">Conferences &amp; Events</a></li>
      <li><a href="#cybersecurity">Cybersecurity, Data, IT &amp; Privacy</a></li>
      <li><a href="#data">Data &amp; OSINT</a></li>
      <li><a href="#forum">Discussions, Forums &amp; Message Boards</a></li>
      <li><a href="#diy">DIY, 3D Modeling &amp; Printing, Architecture and Crafting</a></li>
      <li><a href="#wiki">Documentation, Issue Trackers &amp; WikiMedia</a></li>
      <li><a href="#nature">Earth, History, Nature, Science &amp; Weather</a></li>
      <li><a href="#hacking">Electronics, Hardware &amp; Robotics</a></li>
      <li><a href="#family">Family, Fitness, Leisure &amp; Travel</a></li>
      <li><a href="#fantasy">Fantasy, Fiction &amp; Pseudo-Science</a></li>
      <li><a href="#news">Government, History, Media, Politics &amp; World Affairs News</a></li>
      <li><a href="#health">Health, Nutrition &amp; Recipes</a></li>
      <li><a href="#music">Music, Radio, Scores &amp; Sound</a></li>
      <li><a href="#radio">Podcasts &amp; Radio</a></li>
      <li><a href="#shopping">Product, Real Estate, Services, Shopping Reviews &amp; Stores</a></li>
      <li><a href="#activism">Social Action (Activism)</a></li>
      <li><a href="#technology">Software, Guides, Reviews &amp; Technology</a></li>
      <li><a href="#package">Software Package Updates</a></li>
      <li><a href="#project">Software Project Updates</a></li>
      <li><a href="#syndication">Syndication &amp; XML</a></li>
      <li><a href="#telecom">Telecom, Mesh &amp; Mix Protocols</a></li>
      <li><a href="#torrents">Torrents</a></li>
      <li><a href="#video">Videos</a></li>
    </ul>
    <div class="category" id="art">
      <h3>Art, Culture, Literature &amp; Photography</h3>
      <a href="https://4columns.org/feed">4Columns</a>
      <a href="https://queue.acm.org/rss/feeds/latestitems.xml">ACM Queue</a>
      <a href="https://aeon.co/feed.atom">Aeon</a>
      <a href="https://annas-blog.org/rss.xml">Anna’s Blog</a>
      <a href="https://audiobookbay.is/feed/atom/">AudioBook Bay</a>
      <!-- a href="https://barnesreview.org/feed/">Barnes Review</a -->
      <!-- a href="https://www.kusc.org/feed/">Classical KUSC</a -->
      <a href="https://www.dafont.com/new.xml">DaFont</a>
      <a href="http://davidkphotography.com/index.php?x=rss">David Kleinert Photography</a>
      <a href="http://darksitefinder.com/feed/atom/">Dark Site Finder</a>
      <a href="https://tpb.party/rss/new/601">E-books (TPB)</a>
      <a href="https://motd.ambians.com/out/rss/daily-fortunes.xml">Daily Fortunes - Quotes &amp; Quips</a>
      <a href="http://freedif.org/blog.atom">Freedif</a>
      <a href="https://www.kb.nl/rss.xml">Galerij | Koninklijke Bibliotheek</a>
      <a href="https://sacred-texts.com/rss/new.xml">ISTA - Internet Sacred Text Archive</a>
      <a href="https://librivox.org/feed/atom/">LibriVox News</a>
      <a href="https://librivox.org/rss/latest_releases">LibriVox's New Releases</a>
      <a href="https://onlinebooks.library.upenn.edu/newrss.xml">New Online Books</a>
      <a href="https://www.nioc.eu/rss">Nioc Photos</a>
      <a href="https://www.transformativeworks.org/feed/atom/">Organization for Transformative Works</a>
      <a href="https://www.brainyquote.com/link/quotebr.rss">Quotes</a>
      <a href="https://zenfolio.com/feed">Ron Reyes Photography</a>
      <a href="https://thegraphicsfairy.com/feed/atom/">The Graphics Fairy</a>
      <a href="https://publicdomainreview.org/rss.xml">The Public Domain Review</a>
      <a href="https://www.torrent911.me/rss/ebooks">Torrent911</a>
    </div>
    <div class="category" id="automation">
      <h3>Automation</h3>
      <a href="https://www.home-assistant.io/atom.xml">Home Assistant</a>
      <a href="https://zapier.com/blog/feeds/latest/">Zapier</a>
    </div>
    <div class="category" id="blogroll">
      <h3>Blogroll &amp; Webring</h3>
      <a href="https://nerdy.dev/rss.xml">Adam Argyle</a>
      <a href="https://alixandercourt.com/feed/atom/">Alixander Court</a>
      <a href="https://web.lewman.com/feed.xml">Andrew Lewman</a>
      <a href="https://momi.ca/feed.xml">Anjan Momi</a>
      <a href="https://arantius.com/feed.rss">Anthony (Tony) Lieuallen</a>
      <a href="https://automationrhapsody.com/feed/atom/">Automation Rhapsody</a>
      <a href="https://blog.stigok.com/feed.xml">blog of stigok</a>
      <a href="https://carlschwan.eu/index.xml">Carl Schwan</a>
      <a href="https://carlosbecker.com/index.xml">Carlos Becker</a>
      <a href="https://chee.party/feed.xml">cherries by chee rabbits</a>
      <a href="https://chee.party/feeds/everything.xml">cherries: everything by chee rabbits</a>
      <a href="https://copyblogger.com/feed/atom/">Copyblogger</a>
      <a href="https://denshi.org/index.xml">DenshiSite</a>
      <a href="https://tilde.town/~dustin/index.xml">~dustin</a>
      <a href="https://blog.esmailelbob.xyz/feed/atom/">Esmail EL BoB</a>
      <a href="https://www.fivefilters.org/feed/atom/">FiveFilters</a>
      <a href="https://nu.federati.net/api/statuses/user_timeline/16.as">GeniusMusing (@geniusmusing)</a>
      <a href="https://mccor.xyz/rss.xml">Jacob McCormick</a>
      <a href="https://www.janwagemakers.be/jekyll/feed.xml">Jan Wagemakers</a>
      <a href="https://kasesag.me/index.xml">kasesag</a>
      <a href="https://www.kirsle.net/blog.atom">Kirsle</a>
      <a href="https://len.ro/index.xml">len.ro</a>
      <a href="https://nu.federati.net/api/statuses/user_timeline/2.as">LinuxWalt (@lnxw48a1)</a>
      <a href="https://lukesmith.xyz/index.xml">Luke Smith</a>
      <a href="https://blog.mathieui.net/feeds/all.atom.xml">mathieui’s blog</a>
      <a href="https://nadim.computer/rss.xml">Nadim Kobeissi</a>
      <a href="http://www.aaronsw.com/2002/feeds/pgessays.rss">Paul Graham: Essays</a>
      <a href="https://problogger.com/feed/atom/">ProBlogger</a>
      <a href="http://scripting.com/rss.xml">Scripting News</a>
      <a href="http://schneegans.github.io/feed.xml">Simon Schneegans' Blog</a>
      <a href="https://sizeof.cat/atom.xml">sizeof(cat)</a>
      <a href="https://singpolyma.net/feed/action_stream/?full">Stephen Paul Weber</a>
      <a href="http://www.susannaspencer.com/feed/atom/">Susanna Spencer</a>
      <a href="http://thedarnedestthing.com/atom.xml">the darnedest thing</a>
      <a href="https://flu0r1ne.net/logs/rss.xml">The Logs (flu0r1ne.net)</a>
      <a href="https://geniusmusing.com/feed/rss">The Random Thoughts of GeniusMusing</a>
      <a href="https://thoughtcatalog.com/feed/atom/">Thought Catalog</a>
      <a href="https://tomblog.rip/feed/atom/">Tomb Log</a>
      <a href="http://truthstreammedia.com/feed/atom/">Truthstream Media</a>
      <a href="https://unixsheikh.com/feed.rss">unixsheikh.com</a>
      <a href="https://waitbutwhy.com/feed">Wait But Why</a>
      <a href="https://webring.xxiivv.com/#rss">Webring (index)</a>
      <a href="https://willnorris.com/atom.xml">Will Norris</a>
    </div>
    <div class="category" id="business">
      <h3>Business &amp; Careers</h3>
      <a href="https://coderslegacy.com/feed/atom/">CodersLegacy</a>
    </div>
    <div class="category" id="code">
      <h3>Coding, Development, SysAdmin &amp; Tutorials</h3>
      <a href="https://60devs.com/feed.xml">60devs</a>
      <a href="https://www.askpython.com/feed/atom">AskPython</a>
      <a href="https://www.crunchydata.com/blog/rss.xml">CrunchyData</a>
      <a href="https://coderslegacy.com/feed/atom/">CodersLegacy</a>
      <a href="https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1">CodeProject</a>
      <!-- a href="https://datatofish.com/feed/atom/">Data to Fish</a -->
      <a href="https://linux-audit.com/feed/">Linux Audit</a>
      <a href="https://linuxconfig.org/feed">LinuxConfig</a>
      <a href="https://www.linuxguides.de/feed/atom/">Linux Guides</a>
      <a href="https://linuxhandbook.com/rss/">Linux Handbook</a>
      <a href="https://linuxize.com/index.xml">Linuxize</a>
      <a href="https://www.mfitzp.com/feeds/all.atom.xml">Martin Fitzpatrick
</a>
      <a href="https://peps.python.org/peps.rss">Newest Python PEPs</a>
      <a href="https://www.pythonclear.com/feed/atom/">Python Clear</a>
      <a href="https://pythonguides.com/feed/atom/">Python Guides</a>
      <a href="https://realpython.com/atom.xml">Real Python</a>
      <a href="https://superfastpython.com/feed/atom/">Super Fast Python</a>
      <!-- a href="https://vegibit.com/feed/">vegibit</a -->
    </div>
    <div class="category" id="entertainment">
      <h3>Comic, Entertainment, Games &amp; Memes</h3>
      <a href="https://abstrusegoose.com/atomfeed.xml">Abstruse Goose</a>
      <a href="https://www.basicinstructions.net/basic-instructions?format=rss">Basic Instructions</a>
      <a href="https://www.boredpanda.com/feed/atom/">Bored Panda</a>
      <a href="http://cdrom.ca/feed.xml">CD-ROM Journal</a>
      <a href="https://www.crossfire.nu/feed/journals">Crossfire Journals</a>
      <a href="https://www.crossfire.nu/feed/news">Crossfire News</a>
      <a href="https://www.demilked.com/feed/atom/">DeMilked</a>
      <a href="https://dieselsweeties.com/ds-unifeed.xml">Diesel Sweeties</a>
      <a href="https://www.dsogaming.com/feed/atom/">DSOGaming</a>
      <a href="https://www.gamingonlinux.com/article_rss.php">GamingOnLinux</a>
      <a href="https://grrrgraphics.com/feed/atom/">GrrrGraphics</a>
      <a href="https://handheldgameconsoles.com/f.atom">Handheld Game Consoles</a>
      <a href="https://itch.io/blog.rss">itch.io</a>
      <!-- a href="https://joyreactor.com/rss">JoyReactor</a -->
      <!-- a href="https://joyreactor.cc/rss">JoyReactor (RU)</a -->
      <a href="https://lichess.org/blog.atom">Lichess</a>
      <a href="https://mindblur.thecomicseries.com/rss/">Mindblur</a>
      <a href="https://rss.moddb.com/headlines/feed/rss.xml">Mod DB</a>
      <a href="https://pikabu.ru/xmlfeeds.php?cmd=popular">pikabu.ru</a>
      <a href="https://readcomicsonline.ru/feed">Read Comics Online</a>
      <a href="https://revive.thecomicseries.com/rss/">Revive</a>
      <a href="https://pbfcomics.com/feed/">The Perry Bible Fellowship</a>
      <a href="https://toothpastefordinner.com/rss/rss.php">Toothpaste For Dinner</a>
      <a href="https://xkcd.com/atom.xml">xkcd</a>
    </div>
    <div class="category" id="events">
      <h3>Conferences &amp; Events</h3>
      <a href="https://mov.im/feed/pubsub.movim.eu/berlin-xmpp-meetup">Berlin XMPP Meetup</a>
      <a href="https://bsd.network/@bsdcan.rss">BSDCan</a>
      <a href="https://about.cocalc.com/feed/atom/">CoCalc</a>
      <a href="https://datacarpentry.org/feed">Data Carpentry</a>
      <a href="https://defcon.org/defconrss.xml">DEF CON</a>
      <a href="https://fosdem.org/atom.xml">FOSDEM</a>
      <a href="https://joinmobilizon.org/en/news/feed.xml">Mobilizon</a>
      <a href="https://mastodon.social/@pgcon.rss">PGCon</a>
      <a href="http://www.redheadconvention.ie/?feed=atom" title="Irish Red Head Convention in aid of Irish Cancer Society, Crosshaven, Co. Cork.">Irish Red Head Convention</a>
    </div>
    <div class="category" id="cybersecurity">
      <h3>Cybersecurity, IT &amp; Privacy</h3>
      <a href="https://www.404media.co/rss/">404 Media</a>
      <a href="https://abovephone.com/feed/atom/">Above Phone</a>
      <a href="https://www.bleepingcomputer.com/feed/">Bleeping Computer</a>
      <a href="https://cocalc.com/news/rss.xml">CoCalc</a>
      <a href="https://www.comparitech.com/feed/">Comparitech</a>
      <a href="https://hacktivis.me/feed.atom">Cyber-Home of Lanodan</a>
      <a href="https://cyberscoop.com/feed/atom/">CyberScoop</a>
      <a href="https://dataoverhaulers.com/feed/atom/">Data Overhaulers</a>
      <a href="https://decrypt.fail/feed/">decrypt[.]fail</a>
      <a href="https://www.fastly.com/blog_rss.xml">Fastly Blog</a>
      <a href="https://hackread.com/feed/atom/">HackRead</a>
      <a href="https://news.ycombinator.com/rss">Hacker News</a>
      <a href="https://mobiforge.com/feed">mobiForge</a>
      <a href="https://nakedsecurity.sophos.com/feed/">Naked Security</a>
      <a href="https://www.privacytools.io/guides/rss.xml">Privacy Guides</a>
      <a href="https://privacysavvy.com/feed/atom/">PrivacySavvy</a>
      <a href="https://www.rapidseedbox.com/feed">RapidSeedbox</a>
      <a href="https://reclaimthenet.org/feed/">Reclaim The Net</a>
      <a href="https://restoreprivacy.com/feed/">Restore Privacy</a>
      <a href="https://fosstodon.org/@RTP.rss">(RTP) Privacy and Tech Tips</a>
      <a href="https://www.schneier.com/feed/atom/">Schneier on Security</a>
      <a href="http://scripting.com/rss.xml">Scripting News</a>
      <a href="https://securityintelligence.com/feed/atom/">Security Intelligence</a>
      <a href="https://simpleit.rocks/index.xml">Simple IT Rocks</a>
      <a href="https://simplifiedprivacy.com/feed/">Simplified Privacy</a>
      <a href="https://rss.slashdot.org/Slashdot/slashdotIt">Slashdot: IT</a>
      <a href="https://takebackourtech.org/rss/">Take Back Our Tech</a>
      <a href="https://taosecurity.blogspot.com/feeds/posts/default">TaoSecurity</a>
      <a href="https://proton.me/blog/feed">The Proton Blog</a>
      <a href="https://torrentfreak.com/feed/">TorrentFreak</a>
      <a href="https://venturebeat.com/feed/">VentureBeat</a>
    </div>
    <div class="category" id="data">
      <h3>Data &amp; OSINT</h3>
      <a href="https://www.jcchouinard.com/feed/">JC Chouinard</a>
      <a href="https://www.northdata.com/feed.rss?global=true">North Data</a>
      <a href="https://blog.northdata.com/rss.xml">North Data Blog</a>
      <!-- a href="https://opencorporates.com/feed/">OpenCorporates</a -->
    </div>
    <div class="category" id="forum">
      <h3>Discussions, Forums &amp; Message Boards</h3>
      <div class="subcategory">
        <h4>Art, Literature and Music</h4>
        <a href="https://forum.librivox.org/app.php/feed">LibriVox</a>
        <a href="https://community.metabrainz.org/posts.rss">MusicBrainz</a>
        <a href="https://www.usingenglish.com/forum/forums/-/index.rss">UsingEnglish.com</a>
      </div>
      <div class="subcategory">
        <h4>Automation</h4>
        <a href="https://community.home-assistant.io/posts.rss">Home Assistant</a>
        <a href="https://huggingface.co/blog/feed.xml">Hugging Face</a>
        <a href="https://forum.fhem.de/index.php?action=.xml;type=atom">FHEM</a>
      </div>
      <div class="subcategory">
        <h4>Computer</h4>
        <a href="https://community.e.foundation/posts.rss">/e/OS community</a>
        <a href="https://arcolinux.com/feed/">ArcoLinux</a>
        <a href="https://www.armbian.com/feed/">Armbian</a>
        <a href="https://www.antixforum.com/feed/">antiX Linux</a>
        <a href="https://bbs.archlinux.org/extern.php?action=feed&amp;type=atom&amp;limit=20">Arch Linux</a>
        <a href="https://forum.artixlinux.org/index.php?action=.xml&amp;type=atom&amp;limit=20">Artix Linux</a>
        <a href="https://gitlab.com/divested-mobile.atom">DivestOS Mobile</a>
        <a href="https://forums.docker.com/posts.rss">Docker Community Forums</a>
        <a href="https://forum.endeavouros.com/posts.rss">EndeavourOS</a>
        <a href="https://forums.freebsd.org/forums/-/index.rss">FreeBSD</a>
        <a href="https://forum.garudalinux.org/posts.rss">Garuda Linux</a>
        <a href="https://discourse.gnome.org/posts.rss">GNOME</a>
        <a href="https://hardforum.com/forums/-/index.rss">[H]ard</a>
        <a href="https://forums.kali.org/external.php?type=RSS2">Kali Linux</a>
        <a href="http://board.kolibrios.org/app.php/feed">KolibriOS (FASM)</a>
        <a href="https://linux.org/articles/index.rss">Linux.org</a>
        <a href="https://forum.linux-hardware.org/index.php?action=.xml&amp;type=atom&amp;limit=20">Linux Hardware Review</a>
        <a href="https://forum.mxlinux.org/feed">MX Linux</a>
        <a href="https://discourse.nixos.org/posts.rss">NixOS</a>
        <a href="https://labs.parabola.nu/projects/parabola-community-forum/boards/4.atom">Parabola Community Forum</a>
        <a href="https://www.pclinuxos.com/forum/index.php?type=atom&amp;action=.xml">PCLinuxOS</a>
        <a href="https://forum.pine64.org/syndication.php?type=atom1.0">PINE64</a>
        <a href="https://www.psx-place.com/forums/-/index.rss">PSX-Place</a>
        <a href="https://sourceforge.net/p/rescuezilla/activity/feed">Rescuezilla (activity)</a>
        <a href="https://sourceforge.net/p/rescuezilla/discussion/feed.rss">Rescuezilla (discussion)</a>
        <a href="https://reactos.org/forum/app.php/feed">ReactOS</a>
        <a href="https://www.riscosopen.org/forum/posts.rss">ROOL Forum (RISC OS Open)</a>
        <a href="https://www.portablefreeware.com/forums/app.php/feed">The Portable Freeware Collection Forums</a>
        <a href="https://thinkpad-forum.de/forums/-/index.rss">ThinkPad-Forum.de</a>
        <a href="http://usa.x10host.com/mybb/syndication.php?type=atom1.0">UserScripts Archive</a>
        <a href="https://forum.xda-developers.com/f/-/index.rss">XDA Developers</a>
      </div>
      <div class="subcategory">
        <h4>DIY and Household</h4>
        <a href="https://www.diychatroom.com/forums/-/index.rss">DIY Home Improvement</a>
        <a href="https://www.doityourself.com/forum/external.php?type=RSS2">DoItYourself.com</a>
        <a href="https://houserepairtalk.com/forums/-/index.rss">Home Improvement, Remodeling &amp; Repair</a>
      </div>
      <div class="subcategory">
        <h4>Games and Multimedia</h4>
        <a href="https://discourse.ardour.org/posts.rss">Ardour</a>
        <a href="http://stream-recorder.com/forum/external.php?type=RSS2">Audio/video stream recording forums</a>
        <a href="https://www.crossfire.nu/feed/threads">Crossfire</a>
        <a href="https://www.gamingonlinux.com/forum_rss.php">GamingOnLinux</a>
        <a href="https://www.head-fi.org/forums/-/index.rss">Head-Fi</a>
        <a href="https://hydrogenaud.io/index.php?action=.xml;type=atom;limit=20">HydrogenAudio</a>
        <a href="https://forums.libretro.com/posts.rss">Libretro</a>
        <a href="https://obsproject.com/forum/list/-/index.rss">OBS</a>
        <a href="http://forums.dumpshock.com/index.php?act=rssout&amp;id=1">Shadowrun Discussion</a>
        <a href="https://www.vogons.org/feed">VOGONS</a>
        <a href="https://forum.zdoom.org/app.php/feed">ZDoom</a>
      </div>
      <div class="subcategory">
        <h4>Miscellaneous</h4>
        <a href="https://discourse.asciinema.org/posts.rss">asciinema</a>
        <a href="https://www.happiness.com/rss/1-happinesscom-magazine.xml/">Happiness and Meditation</a>
        <a href="https://forum.invoiceninja.com/posts.rss">Invoice Ninja</a>
        <a href="https://www.solveforum.com/forums/forums/-/index.rss">SolveForum</a>
        <a href="https://www.stormfront.org/forum/external.php?type=RSS2">Stormfront</a>
        <a href="https://sqlite.org/forum/timeline.rss">SQLite</a>
        <a href="https://zigforums.com/xml/feed.rss">Zig</a>
      </div>
      <div class="subcategory">
        <h4>Nature</h4>
        <a href="https://www.climate-debate.com/feeds/threads.php" title="Earth is not a globe. There is no weather crisis.">Climate Debate</a>
        <a href="https://flatearth.freeforums.net/rss/public" title="Yes. You and I are living on an enclosed horizontal plane. Do not use the word 'Flat'. The word 'Flat' is a bad reference to our horizontal and level earth. The phrase 'Flat Earth' was intentionally made over the years in order to retract you from looking into this matter.">Level-Earth Education Forum</a>
        <a href="https://ifers.forumotion.com/feed/?type=atom" title="Yes. You and I are living on an enclosed horizontal plane. Do not use the word 'Flat'. The word 'Flat' is a bad reference to our horizontal and level earth. The phrase 'Flat Earth' was intentionally made over the years in order to retract you from looking into this matter.">IFERS (Horizontal and Level Earth)</a>
      </div>
      <div class="subcategory">
        <h4>Network, Privacy and Security</h4>
        <a href="https://community.bitwarden.com/posts.rss">Bitwarden</a>
        <a href="https://discourse.mailinabox.email/posts.rss">Mail-in-a-Box</a>
        <a href="https://discuss.privacyguides.net/posts.rss">Privacy Guides</a>
        <a href="https://smf.rantradio.com/index.php?type=atom;action=.xml">RantMedia Forum</a>
      </div>
      <div class="subcategory">
        <h4>Telecommunication</h4>
        <a href="https://community.asterisk.org/posts.rss">Asterisk</a>
        <a href="https://meta.getaether.net/posts.rss">Meta Aether</a>
        <a href="http://i2pforum.i2p/app.php/feed">I2P support</a>
        <a href="https://discuss.ipfs.tech/posts.rss">IPFS Forums</a>
        <a href="https://forum.jami.net/posts.rss">Jami</a>
        <a href="https://community.jitsi.org/posts.rss">Jitsi</a>
        <a href="https://forum.tribler.org/latest.rss">Tribler</a>
      </div>
    </div>
    <div class="category" id="diy">
      <h3>DIY, 3D Modeling &amp; Printing, Architecture and Crafting</h3>
      <a href="https://all3dp.com/feed/newsfeed">All3DP</a>
      <a href="http://tracker2.postman.i2p/?view=RSS&amp;mapset=85701">Cad/3D Printing</a>
      <a href="https://designoptimal.com/feed/">DesignOptimal</a>
      <a href="https://www.doityourself.com/feed">Doityourself.com</a>
      <a href="https://www.elementalchile.cl/en/feed/">Elemental</a>
      <a href="https://www.familyhandyman.com/feed/">Family Handyman</a>
      <a href="https://www.mom-on-a-mission.blog/all-posts?format=rss">Mom on a Mission</a>
      <a href="https://www.opensourceecology.org/feed/">Open Source Ecology</a>
      <a href="https://tpb.party/rss/new/605">Physibles (TPB)</a>
      <a href="http://yorik.uncreated.net/feed">Yorik's blog</a>
    </div>
    <div class="category" id="wiki">
      <h3>Documentation, Issue Trackers &amp; WikiMedia</h3>
      <a href="https://wiki.alpinelinux.org/w/api.php?hidebots=1&amp;urlversion=1&amp;days=7&amp;limit=50&amp;action=feedrecentchanges&amp;feedformat=atom">Alpine Linux</a>
      <a href="https://wiki.archlinux.org/api.php?hidebots=1&amp;urlversion=1&amp;days=7&amp;limit=50&amp;action=feedrecentchanges&amp;feedformat=atom">ArchWiki</a>
      <a href="https://sourceforge.net/p/aros/activity/feed">AROS Research Operating System</a>
      <a href="https://sourceforge.net/p/butt/activity/feed">Broadcast Using This Tool</a>
      <a href="https://www.coreboot.org/api.php?hidebots=1&amp;urlversion=1&amp;days=7&amp;limit=50&amp;action=feedrecentchanges&amp;feedformat=atom">coreboot</a>
      <a href="https://doomwiki.org/w/api.php?hidebots=1&amp;days=7&amp;limit=50&amp;hidecategorization=1&amp;action=feedrecentchanges&amp;feedformat=atom">DoomWiki.org</a>
      <a href="https://wiki.greasespot.net/api.php?hidebots=1&amp;urlversion=1&amp;days=7&amp;limit=50&amp;action=feedrecentchanges&amp;feedformat=atom">GreaseSpot Wiki</a>
      <a href="https://indieweb.org/wiki/api.php?hidebots=1&amp;urlversion=1&amp;days=7&amp;limit=50&amp;action=feedrecentchanges&amp;feedformat=atom">IndieWeb</a>
      <a href="https://community.kde.org/api.php?hidebots=1&amp;urlversion=1&amp;days=7&amp;limit=50&amp;action=feedrecentchanges&amp;feedformat=atom">KDE Community</a>
      <a href="https://userbase.kde.org/api.php?hidebots=1&amp;translations=filter&amp;urlversion=1&amp;days=7&amp;limit=50&amp;action=feedrecentchanges&amp;feedformat=atom">KDE UserBase</a>
      <a href="http://websvn.kolibrios.org/rss.php?repname=Kolibri+OS&amp;path=%2F&amp;isdir=1&amp;">Kolibri OS</a>
      <a href="https://linux-sunxi.org/api.php?hidebots=1&amp;urlversion=1&amp;days=7&amp;limit=50&amp;action=feedrecentchanges&amp;feedformat=atom">linux-sunxi.org</a>
      <a href="http://source.netsurf-browser.org/netsurf.git/atom/?h=master">NetSurf Browser</a>
      <a href="https://wiki.postmarketos.org/api.php?hidebots=1&amp;urlversion=1&amp;days=7&amp;limit=50&amp;action=feedrecentchanges&amp;feedformat=atom">postmarketOS</a>
      <a href="https://sourceforge.net/p/rescuezilla/activity/feed">Rescuezilla</a>
      <a href="https://gitlab.riscosopen.org/RiscOS.atom">RiscOS activity</a>
      <a href="https://www.riscosopen.org/tracker/rss/tickets">ROOL Tracker</a>
      <a href="https://sourceforge.net/p/salix/activity/feed">Salix OS</a>
      <a href="https://wiki.syslinux.org/wiki/api.php?hidebots=1&amp;days=7&amp;limit=50&amp;hidecategorization=1&amp;action=feedrecentchanges&amp;feedformat=atom">Syslinux</a>
      <a href="https://mirror.git.trinitydesktop.org/cgit/tde/atom/?h=master">Trinity Desktop Environment (tde, branch master)</a>
      <a href="https://bugs.trinitydesktop.org/buglist.cgi?query_format=advanced&amp;title=Bug%20List&amp;ctype=atom">Trinity Bug List</a>
      <a href="https://wiki.trinitydesktop.org/api.php?hidebots=1&amp;urlversion=1&amp;days=7&amp;limit=50&amp;action=feedrecentchanges&amp;feedformat=atom">Trinity Desktop Project</a>
      <a href="https://wikispooks.com/w/api.php?hidebots=1&amp;urlversion=1&amp;days=7&amp;limit=50&amp;action=feedrecentchanges&amp;feedformat=atom">Wikispooks</a>
      <a href="https://wiki.znc.in/api.php?hidebots=1&amp;urlversion=1&amp;days=7&amp;limit=50&amp;action=feedrecentchanges&amp;feedformat=atom">ZNC</a>
    </div>
    <div class="category" id="nature">
      <h3>Earth, History, Nature, Science &amp; Weather</h3>
      <a href="https://ericdubay.wordpress.com/feed/">EricDubay.com</a>
      <a href="https://www.geograph.org.uk/discuss/syndicator.php?forum=1&amp;first=1">Geograph</a>
      <a href="https://www.nhc.noaa.gov/aboutrss.shtml">National Hurricane Center And
Central Pacific Hurricane Center</a>
      <a href="https://www.weather.gov/rss_page.php?site_name=nws">National Weather Service</a>
      <a href="https://roaring.earth/feed/">Roaring Earth</a>
      <a href="https://www.rockandice.com/feed/">Rock and Ice Magazine</a>
      <a href="http://www.rssweather.com/">RSS Weather</a>
      <a href="http://www.atlanteanconspiracy.com/feeds/posts/default">The Atlantean Way</a>
      <a href="https://vetclassics.com/feed/">VETCLASSICS</a>
    </div>
    <div class="category" id="hacking">
      <h3>Electronics, Hardware &amp; Robotics</h3>
      <a href="https://baylibre.com/feed/">BayLibre</a>
      <a href="https://www.c0ffee.net/rss/">c0ffee</a>
      <a href="https://www.ccc.de/de/rss/updates.xml">Chaos Computer Club</a>
      <a href="https://www.complete.org/index.xml">complete.org</a>
      <a href="https://crlf.link/feed.xml">&amp;Cr&#59; &amp;Lf</a>
      <a href="http://dangerousprototypes.com/blog/feed/">Dangerous Prototypes</a>
      <a href="https://pyra-handheld.com/boards/forums/-/index.rss">DragonBox (Pyra and Pandora)</a>
      <a href="https://dojofordrones.com/feed/atom/">Drone Dojo</a>
      <a href="https://electro.pizza/feed.xml">electro·pizza</a>
      <a href="https://blog.flipperzero.one/rss/">Flipper Zero Blog</a>
      <a href="https://www.getdroidtips.com/feed/atom/">Get Droid Tips</a>
      <a href="https://hnrss.org/frontpage">Hacker News</a>
      <a href="https://homehack.nl/feed/atom/">HomeHack</a>
      <a href="http://www.righto.com/feeds/posts/default">Ken Shirriff's blog</a>
      <a href="https://knuxify.github.io/blog/feed.xml">knuxify’s blog</a>
      <a href="https://louwrentius.com/feed/all.atom.xml">Louwrentius</a>
      <a href="https://mansfield-devine.com/speculatrix/feed/">Machina Speculatrix</a>
      <a href="http://moderntoil.com/?feed=rss2">Modern Toil</a>
      <a href="https://n-o-d-e.net/rss/rss.xml">N O D E</a>
      <a href="https://notenoughtech.com/feed/">NotEnoughTECH</a>
      <a href="https://mastodon.social/@olimex.rss">Olimex</a>
      <a href="https://www.open-electronics.org/feed/atom/">Open Electronics</a>
      <a href="https://pimylifeup.com/feed/">Pi My Life Up</a>
      <a href="https://raspberrytips.com/feed/">RaspberryTips</a>
      <a href="https://rfidresearchgroup.com/feed/">RFID Research Group</a>
      <a href="https://smartbuilds.io/feed/">SmartBuilds</a>
      <a href="https://www.thedronegirl.com/feed/">The Drone Girl</a>
      <a href="https://webring.xxiivv.com/#rss">Webring (index)</a>
      <a href="https://wellerpcb.com/feed/">Weller PCB</a>
      <a href="https://xnux.eu/rss.xml">xnux.eu</a>
    </div>
    <div class="category" id="family">
      <h3>Family, Fitness, Leisure &amp; Travel</h3>
      <a href="https://www.baldandbeards.com/feed/">Bald &amp; Beards</a>
      <a href="https://blastaloud.com/feed/atom/">BlastAloud</a>
      <a href="https://dailyurbanista.com/feed/atom/">Daily Urbanista</a>
      <a href="https://divinelifestyle.com/feed/">Divine Lifestyle</a>
      <a href="https://expertvagabond.com/feed/">Expert Vagabond</a>
      <a href="https://www.girlschase.com/rss.xml">Girls Chase</a>
      <a href="https://gmb.io/feed/">GMB Fitness</a>
      <a href="https://www.imom.com/feed/">iMOM</a>
      <a href="http://www.elizabethfoss.com/journal?format=rss">In The Heart of My Home</a>
      <a href="https://latest-fashion-tips.com/feed/">Latest Fashion Tips</a>
      <a href="https://www.lifeadvancer.com/feed/">Life Advancer</a>
      <a href="https://www.mom-on-a-mission.blog/all-posts?format=rss">Mom on a Mission</a>
      <a href="https://rebelliousdevelopment.com/feed">Rebellious Development</a>
      <a href="https://www.artofmanliness.com/feed/">The Art of Manliness</a>
      <a href="https://thebaldbrothers.com/feed/">The Bald Brothers</a>
      <a href="https://theeverygirl.com/feed/">The Everygirl</a>
      <a href="https://thefrugalgirls.com/feed">The Frugal Girls</a>
      <a href="https://trip101.com/feed">Trip101</a>
    </div>
    <div class="category" id="fantasy">
      <h3>Fantasy, Fiction &amp; Pseudo-Science</h3>
      <p>The following sites are manipulative disinformation sites that mostly contain large amounts of AI and CGI type of images, and do not provide verifiable proofs to their fabricated and made up claims.</p>
      <a href="https://blog.discoveryeducation.com/feed/">Discovery Indoctrination Blog</a>
      <a href="https://futurism.com/feed">Futurism</a>
      <a href="https://www.nasa.gov/feeds/iotd-feed" title="SA(T)AN">NASA</a>
      <a href="https://www.nature.com/nature.rss">Nature</a>
      <a href="https://www.sciencealert.com/feed">ScienceAlert</a>
      <a href="https://www.sciencedaily.com/rss/all.xml">ScienceDaily</a>
      <a href="https://scitechdaily.com/feed/">SciTechDaily</a>
      <a href="https://storiesbywilliams.com/feed/">Stories by Williams</a>
    </div>
    <div class="category" id="news">
      <h3>Government, His-story, Media, Politics &amp; World Affairs News</h3>
      <a href="https://12bytes.org/feed.xml">12bytes.org</a>
      <a href="https://www.blacklistednews.com/rss.php">BlackListed News</a>
      <a href="http://cafe.nfshost.com/?feed=atom">CAFE: Canadian Association for Free Expression</a>
      <a href="https://www.historiography-project.org/feed/">Clippings and Commentary</a>
      <a href="https://www.cryptogon.com/?feed=atom">cryptogon</a>
      <a href="https://mastodon.social/@Cryptome.rss">Cryptome</a>
      <a href="https://www.spiegel.de/international/index.rss">DER SPIEGEL</a>
      <a href="http://dprogram.net/feed/">Dprogram.net - Countering Propaganda</a>
      <a href="https://earthnewspaper.com/feed/atom/">EarthNewspaper.com</a>
      <a href="https://fakeologist.com/feed/atom/">Fakeologist</a>
      <a href="https://freedomain.com/feed/atom/">Freedomain – The no. 1 philosophy show online</a>
      <a href="https://www.historicly.net/feed">Historic.ly</a>
      <a href="https://www.informationliberation.com/rss.xml">Information Liberation</a>
      <a href="https://www.icij.org/feed/">International Consortium of Investigative Journalists</a>
      <a href="https://iep.utm.edu/feed/atom/">Internet Encyclopedia of Philosophy</a>
      <a href="https://www.irishexaminer.com/feed/35-top_news.xml">Irish Examiner</a>
      <a href="https://jermwarfare.com/feed">Jerm Warfare</a>
      <a href="https://leohohmann.com/feed/">Leo Hohmann</a>
      <a href="https://www.medialens.org/feed/">Media Lens</a>
      <a href="https://www.mintpressnews.com/feed/">MintPress News</a>
      <a href="https://api.ntd.com/feed">NTD Television</a>
      <a href="https://off-guardian.org/feed/">OffGuardian</a>
      <a href="https://pjnewsletter.com/feed">Patriot Journal</a>
      <a href="https://www.presstv.ir/rss.xml">Press TV</a>
      <a href="https://presswatchers.org/feed/">Press Watch</a>
      <a href="https://redice.tv/rss/news">Red Ice News</a>
      <a href="https://rmx.News/feed/">Remix News</a>
      <a href="https://seymourhersh.substack.com/feed">Seymour Hersh</a>
      <a href="https://rss.slashdot.org/Slashdot/slashdotMain">Slashdot</a>
      <a href="https://stevekirsch.substack.com/feed">Steve Kirsch</a>
      <a href="https://stewpeters.com/feed/atom/">Stew Peters</a>
      <a href="https://strategicinvestment.com/page/str/rssfeed.xml">Strategic Investment</a>
      <a href="https://sandrafinley.ca/blog/?feed=rss2">The Battles</a>
      <a href="https://canadianpatriot.org/feed/">the Canadian patriot</a>
      <a href="https://theconsciousresistance.com/feed/">The Conscious Resistance Network</a>
      <a href="https://dailysceptic.org/feed/">The Daily Sceptic</a>
      <a href="https://www.thegatewaypundit.com/feed/">The Gateway Pundit</a>
      <a href="https://www.interpretermag.com/feed/">The Interpreter</a>
      <a href="http://themostimportantnews.com/feed/atom">The Most Important News</a>
      <a href="https://www.theorganicprepper.com/feed/atom/">The Organic Prepper</a>
      <a href="https://thepeoplesvoice.tv/feed/atom/">The People's Voice</a>
      <a href="https://vigilantcitizen.com/feed/atom/">The Vigilant Citizen</a>
      <a href="https://truthstreammedia.com/feed/atom/">Truthstream Media</a>
      <a href="https://unlimitedhangout.com/feed/atom/">Unlimited Hangout</a>
      <a href="https://vdare.com/generalfeed">VDARE</a>
      <a href="https://www.veteranstoday.com/feed/">VT Foreign Policy</a>
    </div>
    <div class="category" id="health">
      <h3>Health, Nutrition &amp; Recipes</h3>
      <a href="https://www.101cookbooks.com/feed">101 Cookbooks</a>
      <a href="https://www.asweetpeachef.com/feed/">A Sweet Pea Chef</a>
      <a href="https://www.annalenashearthbeat.com/feed/">Annalena's Heart(h)beat</a>
      <a href="https://askannamoseley.com/feed/">Ask Anna</a>
      <a href="https://based.cooking/index.xml">Based Cooking</a>
      <a href="https://www.bonappetit.com/feed/rss">Bon Appétit</a>
      <a href="https://cooknourishbliss.com/feed/">Cook Nourish Bliss</a>
      <a href="https://www.easycookingwithmolly.com/feed/">Easy Cooking with Molly</a>
      <a href="http://www.easypeasyjapanesey.com/blogeasypeasyjapanesey?format=rss">Easy Peasy Japanesey</a>
      <a href="https://farmersforum.com/feed/">Farmers Forum</a>
      <!--a href="https://fathub.org/feed/">FatHub</a-->
      <a href="http://foodly.com/feed/">Foodly</a>
      <a href="https://freezedryguy.com/feed/">Freeze Dry Guy</a>
      <a href="https://heathenherbs.com/feed/">Heathen Herbs</a>
      <a href="https://www.healthyandnaturalworld.com/feed/">Healthy and Natural World</a>
      <a href="https://www.jamieoliver.com/feed/">Jamie Oliver</a>
      <a href="https://jacobwsmith.xyz/cookbook/rss.xml">Jacob's Guide to Possibly Delicious Food</a>
      <a href="https://juicing-for-health.com/feed">Juicing for Health</a>
      <a href="https://www.loveandlemons.com/feed/">Love &amp; Lemons</a>
      <a href="https://thoughts.melonking.net/atom/?section=recipes">Melon's Thoughts - Recipes</a>
      <a href="https://articles.mercola.com/sites/articles/rss.aspx">Mercola.com</a>
      <a href="https://www.mindful.org/feed/">Mindful</a>
      <a href="https://themythicbox.com/feed/">Mythic food</a>
      <a href="https://nutritionaustralia.org/category/recipes/feed/">Nutrition Australia</a>
      <a href="https://pinchofyum.com/feed">Pinch of Yum</a>
      <a href="https://plantbasedwithamy.com/feed/">Plant Based with Amy</a>
      <a href="https://punchdrink.com/feed/">PUNCH</a>
      <a href="https://www.marginalia.nu/recipes/index.xml">Recipes on marginalia.nu</a>
      <a href="https://recipeswitholiveoil.com/feed/">Recipes With Olive Oil</a>
      <a href="https://sallysbakingaddiction.com/feed/">Sally's Baking Addiction</a>
      <a href="https://www.sheknows.com/food-and-recipes/feed/">SheKnows</a>
      <a href="https://steptohealth.com/feed/">Step To Health</a>
      <a href="https://stevekirsch.substack.com/feed">Steve Kirsch</a>
      <a href="https://stopdirtyelectricity.com/feed/">Stop Dirty Electricity</a>
      <a href="https://thegreenloot.com/feed/">The Green Loot</a>
      <a href="https://theprettybee.com/feed/">The Pretty Bee</a>
      <a href="https://traditionalcookingschool.com/feed/">Traditional Cooking School</a>
      <a href="https://wonderfulcook.com/feed/">Wonderful Cook</a>
    </div>
    <div class="category" id="music">
      <h3>Music, Radio, Scores &amp; Sound</h3>
      <a href="https://320kbpshouse.net/feed">320KBPSHOUSE</a>
      <a href="https://acidstag.com/feed/">Acid Stag</a>
      <a href="https://www.free-scores.com/rss/fluxrss-uk.xml">Free-Scores</a>
      <a href="https://www.frostclick.com/wp/index.php/feed/">FrostClick</a>
      <a href="https://www.homemusicproducer.com/rsslatest.xml">Home Music Producer</a>
      <a href="https://imslp.org/wiki/Special:IMSLPRecordingsFeed/atom">IMSLP Recent Recordings</a>
      <a href="https://www.indiegamemusic.com/rss.php?f=1">IndieGameMusic</a>
      <a href="https://intmusic.net/feed">IntMusic</a>
      <a href="https://itopmusicx.com/feed/">iTOPMUSICX</a>
      <a href="https://downloads.khinsider.com/rss">KHInsider Video Game Music</a>
      <a href="https://legismusic.com/feed/">Legis Music</a>
      <a href="https://losslessclub.com/atom.php">LosslessClub</a>
      <a href="https://www.musicaustria.at/feed/">mica – music austria</a>
      <a href="https://nfodb.ru/rss.php">MP3 NFO Database</a>
      <a href="https://tpb.party/rss/new/101">Music (TPB)</a>
      <a href="https://musicrider.org/feed/">Music Rider</a>
      <a href="https://www.music-scores.com/blog/feed/">Music Scores Blog</a>
      <a href="https://losslessalbums.club/rss.xml">New lossless albums</a>
      <a href="https://rss.ngfiles.com/latestsubmissions.xml">Newgrounds</a>
      <a href="https://rss.ngfiles.com/weeklyaudiotop5.xml">Newgrounds (Weekly Top 5)</a>
      <a href="https://opengameart.org/rss.xml">OpenGameArt</a>
      <a href="https://phish.in/feeds/rss">Phish.in</a>
      <a href="https://www.playonloop.com/feed/">PlayOnLoop</a>
      <a href="https://www.radioking.com/blog/feed/">RadioKing Blog</a>
      <a href="https://secondhandsongs.com/rss/new.xml">Second Hand Songs</a>
    </div>
    <div class="category" id="radio">
      <h3>Podcasts &amp; Radio</h3>
      <a href="https://media.ccc.de/podcast.xml">CCC (Chaos Computer Club)</a>
      <a href="https://files.manager-tools.com/files/public/feeds/career_tools_podcasts.xml">Career Tools</a>
      <a href="https://clownfishtv.com/feed/atom/">CFTV (ClownfishTV)</a>
      <a href="https://feeds.megaphone.fm/darknetdiaries">Darknet Diaries</a>
      <a href="https://fakeologist.com/blog/category/audio/fakeologistshow/feed/">Fakeologist Show</a>
      <a href="http://hackerpublicradio.org/hpr_spx_rss.php">Hacker Public Radio</a>
      <a href="https://www.iceagefarmer.com/feed/atom/">Ice Age Farmer</a>
      <a href="https://jameshfetzer.org/feed/">James H. Fetzer</a>
      <a href="https://www.johnderbyshire.com/feed.xml">John Derbyshire's Commentaries</a>
      <a href="http://larkenrose.com/?format=feed&amp;type=atom">Larken Rose</a>
      <a href="https://files.manager-tools.com/files/public/feeds/manager-tools-podcasts.xml">Manager Tools</a>
      <a href="https://mediamonarchy.com/feed/podcast/">Media Monarchy</a>
      <a href="https://feed.podbean.com/ediviney/feed.xml">Midwest Vegan Radio</a>
      <a href="http://www.opensourcetruth.com/feed/atom/">Open Source Truth</a>
      <a href="https://optoutpod.com/index.xml">Opt Out</a>
      <a href="https://www.osnews.com/feed/podcast/">OSnews</a>
      <a href="https://rss.podomatic.net/rss/peacerevolution.podomatic.com/rss2.xml">Peace Revolution</a>
      <a href="https://www.pine64.org/feed/mp3/">PineTalk</a>
      <a href="https://cast.postmarketos.org/feed.rss">postmarketOS</a>
      <a href="https://redice.tv/rss/radio-3fourteen">Radio 3Fourteen</a>
      <a href="https://www.reallibertymedia.com/category/podcasts/feed/?redirect=no">Real Liberty Media</a>
      <a href="https://redice.tv/rss/red-ice-radio">Red Ice Radio</a>
      <a href="https://redice.tv/rss/red-ice-tv">Red Ice TV</a>
      <a href="http://revolutionradio.org/feed/atom/">Revolution Radio</a>
      <a href="https://feed.podbean.com/rightonradio/feed.xml">Right on Radio</a>
      <a href="https://roaring.earth/category/podcast/feed/">Roaring Earth</a>
      <a href="https://shrinkrapradio.com/feed/atom/">Shrink Rap Radio</a>
      <a href="https://speakfreeradio.com/feed/atom/">Speak Free Radio</a>
      <a href="https://talkpython.fm/episodes/rss">Talk Python To Me</a>
      <a href="https://corbettreport.com/feed/atom/">The Corbett Report</a>
      <a href="https://www.thehighersidechats.com/feed/">The Higherside Chats</a>
      <a href="http://robbwolf.com/feed/atom/">The Paleo Diet</a>
      <a href="http://truthstreammedia.com/feed/atom/">Truthstream Media</a>
      <a href="https://youarenotsosmart.com/feed/atom/">You Are Not So Smart</a>
    </div>
    <div class="category" id="shopping">
      <h3>Product, Real Estate, Services, Shopping Reviews &amp; Stores</h3>
      <a href="https://www.alohakb.com/collections/all.atom">ALOHAKB</a>
      <a href="https://www.cambodiaproperty.info/feed/">Cambodia Property</a>
      <a href="https://faddis.com/feed">Faddis Concrete</a>
      <a href="https://www.fanlesstech.com/feeds/posts/default">FanlessTech</a>
      <a href="https://fincadracula.com/en/feed/">Finca Drácula</a>
      <a href="https://fossbytes.com/feed/">Fossbytes</a>
      <a href="https://www.gearrice.com/web-stories/feed/">Gearrice</a>
      <a href="https://www.geartaker.com/feed/">Gear Taker</a>
      <a href="https://www.geniatech.com/products/embedded-mainboards/feed/">Geniatech</a>
      <a href="https://www.gizmochina.com/feed/">Gizmochina</a>
      <a href="https://www.guru3d.com/atom.xml">Guru of 3D</a>
      <a href="https://www.headfonia.com/feed/">Headfonia</a>
      <a href="https://headfonics.com/feed/">Headfonics</a>
      <a href="https://headphone.guru/feed/">Headphone Guru</a>
      <a href="https://kbdfans.com/collections/all.atom">KBDfans® Mechanical Keyboards Store</a>
      <a href="https://lab401.com/collections/flipper-zero.atom">Lab401</a>
      <a href="https://liliputing.com/feed/">Liliputing</a>
      <a href="https://www.megabites.com.ph/feed/">MegaBites</a>
      <a href="https://www.mouser.com/rss/rss.xml">Mouser Electronics Inc.</a>
      <a href="https://newatlas.com/index.rss">New Atlas</a>
      <a href="https://www.notebookcheck.net/RSS-Feed-Notebook-Reviews.8156.0.html">Notebook Reviews</a>
      <a href="https://www.phonearena.com/feed/news">PhoneArena</a>
      <a href="https://www.pocket-lint.com/feed/">Pocket-lint</a>
      <a href="https://www.protoolreviews.com/feed/">Pro Tool Reviews</a>
      <a href="https://www.productsfromcyprus.com/collections/all.atom">Products from Cyprus</a>
      <a href="https://www.producthunt.com/feed">Product Hunt</a>
      <a href="https://www.russh.com/feed/">RUSSH</a>
      <a href="https://www.sheknows.com/feed/">SheKnows</a>
      <a href="https://simplynuc.com/feed/">Simply NUC</a>
      <a href="https://www.soundvisionreview.com/feed/">SoundVisionReview</a>
      <a href="https://www.techbuy.in/feed/">TechBuy</a>
      <a href="https://www.techpowerup.com/rss/news">TechPowerUp</a>
      <a href="https://the-gadgeteer.com/feed/">The Gadgeteer</a>
      <a href="https://www.trustedreviews.com/feed">Trusted Reviews</a>
      <a href="https://tweakers.net/feeds/mixed.xml">Tweakers Mixed</a>
    </div>
    <div class="category" id="activism">
      <h3>Social Action (Activism)</h3>
      <a href="http://cafe.nfshost.com/?feed=atom">CAFE: Canadian Association for Free Expression</a>
      <a href="https://campaignforliberty.org/feed/">Campaign for Liberty</a>
      <!-- a href="https://mastodon.social/@Chips4Israel.rss">Chips4Israel (שבבים בע"מ)</a -->
      <a href="https://demandprogress.org/feed/">Demand Progress</a>
      <a href="https://www.derrickbroze.com/feed/">Derrick Broze</a>
      <a href="https://doctors4covidethics.org/feed/">Doctors for COVID Ethics</a>
      <a href="https://www.fightforthefuture.org/news/feed.xml">Fight for the Future</a>
      <a href="https://fluoridealert.org/feed/">Fluoride Action Network</a>
      <a href="https://www.geoengineeringwatch.org/feed/atom/">Geoengineering Watch</a>
      <a href="https://participatorypolitics.org/feed/">Participatory Politics Foundation</a>
      <a href="http://live-personaldemocracy.pantheonsite.io/rss.xml">Personal Democracy Forum</a>
      <a href="https://primarywater.org/?feed=rss2">Primary Water</a>
      <a href="https://publicknowledge.org/feed/">Public Knowledge</a>
      <a href="https://reclaimyourface.eu/feed/">Reclaim Your Face</a>
      <a href="https://www.saveusnow.org.uk/feed/">SUN (Save Us Now)</a>
      <a href="https://sfconservancy.org/feeds/news/">Software Freedom Conservancy</a>
      <a href="https://stop5g.cz/us/feed/">Stop 5G</a>
      <a href="https://stopdirtyelectricity.com/feed/">Stop Dirty Electricity</a>
      <a href="http://www.stopsprayingus.com/feed/">Stop Spraying Us!</a>
      <a href="https://stopthecrime.net/wp/feed/">Stop The Crime</a>
      <a href="https://takebackourtech.org/rss/">Take Back Our Tech</a>
      <a href="https://theconsciousresistance.com/feed/">The Conscious Resistance Network</a>
    </div>
    <div class="category" id="technology">
      <h3>Software, Guides, Reviews &amp; Technology</h3>
      <a href="http://feeds.arstechnica.com/arstechnica/index">Ars Technica</a>
      <a href="https://www.cnx-software.com/feed/">CNX Software</a>
      <a href="https://www.comparitech.com/feed/">Comparitech</a>
      <a href="https://computer.rip/rss.xml">computers are bad</a>
      <a href="https://disguised.work/atom.xml">Debian Disguised Work</a>
      <a href="https://ddos-guard.net/rss">DDoS-GUARD</a>
      <a href="https://www.dedoimedo.com/rss_feed.xml">Dedoimedo</a>
      <a href="https://www.spiegel.de/thema/energy_and_natural_resources_en/index.rss">DER SPIEGEL - Energy and Natural Resources</a>
      <a href="https://www.denx.de/feed/">DENX Software Engineering</a>
      <a href="https://distrowatch.com/news/news-headlines.xml">DistroWatch</a>
      <a href="https://www.evilsocket.net/atom.xml">evilsocket</a>
      <a href="https://blog.front-matter.io/atom/">Front Matter</a>
      <a href="https://www.gamingonlinux.com/article_rss.php">GamingOnLinux</a>
      <a href="https://www.ghacks.net/feed/">gHacks</a>
      <a href="https://guides.lw1.at/index.xml">guides.lw1.at</a>
      <a href="https://i2p.rocks/blog/feeds/all.atom.xml">i2p.rocks</a>
      <a href="https://incompetech.com/wordpress/feed/">incompetech</a>
      <a href="https://internetpkg.com/feed/">Internet Packages</a>
      <a href="https://planet.jabber.org/atom.xml">Jabber World</a>
      <a href="https://bgstack15.ddns.net/blog/rss.xml">Knowledge Base</a>
      <a href="https://cyber.dabamos.de/blog/feed.rss">Lazy Reading | The Cyber Vanguard</a>
      <a href="https://leimao.github.io/atom.xml">Lei Mao's Log Book</a>
      <a href="https://liliputing.com/feed/">Liliputing</a>
      <a href="https://linuxgameconsortium.com/feed/">Linux Game Consortium</a>
      <a href="https://linuxgizmos.com/feed/">Linux Gizmos</a>
      <a href="https://linmob.net/feed.xml">LINux on MOBile</a>
      <a href="https://www.linuxuprising.com/feeds/posts/default">Linux Uprising Blog</a>
      <a href="https://medevel.com/rss/">MEDevel</a>
      <a href="https://mrfunkedude.com/feed/">Mr. Funk E. Dude's Place</a>
      <a href="https://newatlas.com/index.rss">New Atlas</a>
      <a href="https://nerdstuff.org/index.xml">Nerd Stuff</a>
      <a href="https://www.cyberciti.com/feed/">nixCraft</a>
      <a href="https://www.nngroup.com/feed/rss/">NN/g latest articles and announcements</a>
      <a href="https://www.notebookcheck.net/News.152.100.html">NotebookCheck</a>
      <a href="https://blog.obco.pro/rss/">OblivionCoding</a>
      <a href="https://www.osnews.com/feed/">OSnews</a>
      <a href="https://ostechnix.com/feed/atom/">OSTechNix</a>
      <a href="https://www.pendrivelinux.com/feed/">Pen Drive Linux</a>
      <a href="https://www.phoronix.com/rss.php">Phoronix</a>
      <a href="https://www.simplified.guide/feed.php">Simplified Guide linux</a>
      <a href="https://singpolyma.net/feed/">Singpolyma</a>
      <a href="https://sourceforge.net/blog/feed/">SourceForge Community Blog</a>
      <a href="https://www.sqlservercentral.com/articles/feed">SQLServerCentral</a>
      <a href="https://srinimf.com/feed/">Srinimf</a>
      <a href="https://www.tecmint.com/feed/">Tecmint</a>
      <a href="https://en.blog.nic.cz/category/turris/feed/">Turris</a>
      <a href="https://tuxphones.com/rss/">TuxPhones</a>
      <a href="https://tux.pizza/feed.xml">tux.pizza</a>
      <a href="https://warmcat.com/feed.xml">Warmcat</a>
    </div>
    <div class="category" id="package">
      <h3>Software Package Updates</h3>
      <a href="https://archlinux.org/feeds/packages/">Arch Linux</a>
      <a href="https://aur.archlinux.org/rss/">Arch Linux (AUR)</a>
      <a href="https://www.ctan.org/ctan-ann/atom.xml">CTAN-ANN</a>
      <a href="https://distrowatch.com/news/dw.xml">DistroWatch</a>
      <a href="https://flathub.org/feeds">Flathub</a>
      <a href="https://www.freshports.org/backend/rss2.0.php">FreshPorts</a>
      <a href="https://extensions.gnome.org/rss/">GNOME Shell Extensions</a>
      <a href="https://greasyfork.org/en/scripts.atom?sort=updated">Greasy Fork</a>
      <a href="https://www.hyperbola.info/feeds/packages/">Hyperbola</a>
      <a href="https://store.kde.org/content.rdf">KDE Store</a>
      <a href="http://feeds.launchpad.net/announcements.atom">Launchpad</a>
      <a href="https://metacpan.org/recent.rss">MetaCPAN</a>
      <a href="https://www.opendesktop.org/content.rdf">OpenDesktop Linux Apps</a>
      <a href="https://packagist.org/feeds/packages.rss">Packagist</a>
      <a href="https://www.parabola.nu/feeds/packages/">Parabola GNU/Linux-libre</a>
      <a href="https://pypi.org/rss/updates.xml">PyPI</a>
      <a href="https://slackbuilds.org/rss/ChangeLog.rss">SlackBuilds.org</a>
      <a href="https://www.xfce-look.org/content.rdf">Xfce-Look.org</a>
    </div>
    <div class="category" id="project">
      <h3>Software Project Updates</h3>
      <div class="subcategory">
        <h4>Artificial Intelligence</h4>
        <a href="https://news.agpt.co/feed/">Auto-GPT</a>
        <a href="https://huggingface.co/blog/feed.xml">Hugging Face</a>
        <a href="https://translatelocally.com/rss/">Translate Locally</a>
      </div>
      <div class="subcategory">
        <h4>Blockchain</h4>
        <a href="https://gostco.in/feed/">GOSTcoin</a>
        <a href="https://litecoin.com/rss.xml">Litecoin</a>
        <a href="https://www.getmonero.org/feed.xml">Monero</a>
        <a href="https://pirate.black/feed/">Pirate Chain (ARRR)</a>
      </div>
      <div class="subcategory">
        <h4>Communication and Social Platforms</h4>
        <a href="https://pod.diaspora.software/public/hq.atom">diaspora* HQ</a>
        <a href="https://dino.im/index.xml">Dino</a>
        <a href="https://blog.discourse.org/rss/">Discourse</a>
        <a href="https://ekiga.org/rss.xml">Ekiga</a>
        <a href="https://joinfirefish.org/rss.xml">Firefish</a>
        <a href="https://blog.funkwhale.audio/feeds/all.atom.xml">Funkwhale</a>
        <a href="https://gajim.org/index.xml">Gajim</a>
        <a href="https://www.jsxc.org/feed.xml">JSXC</a>
        <a href="https://jami.net/feed/">Jami</a>
        <a href="https://jitsi.org/feed/">Jitsi</a>
        <a href="https://community.jitsi.org/c/news/5.rss">Jitsi News</a>
        <a href="https://www.kaidan.im/atom.xml">Kaidan</a>
        <a href="https://discourse.mailinabox.email/c/announcements/9.rss">Mail-in-a-Box</a>
        <a href="https://mailcow.email/index.xml">Mailcow</a>
        <a href="https://blog.joinmastodon.org/index.xml">Mastodon</a>
        <a href="https://oxen.io/feed/atom">Oxen Session</a>
        <a href="https://joinpeertube.org/rss-en.xml">PeerTube</a>
        <a href="https://postmarks.glitch.me/index.xml">Postmarks</a>
        <a href="https://soapbox.pub/rss/atom.xml">Soapbox</a>
        <a href="https://typo3.org/rss">TYPO3</a>
      </div>
      <div class="subcategory">
        <h4>Desktop and Mobile Operating Systems</h4>
        <a href="https://artixlinux.org/feed.php">Artix Linux</a>
        <a href="https://www.bodhilinux.com/feed/">Bodhi Linux</a>
        <a href="https://gitlab.com/divested-mobile/divestos-build.atom">DivestOS-(activity)</a>
        <a href="https://droidian.org/index.xml">Droidian</a>
        <a href="https://www.dragonflydigest.com/feed/">DragonFly BSD Digest</a>
        <a href="https://e.foundation/feed/">e Foundation</a>
        <a href="https://www.fiwix.org/rss.xml">Fiwix</a>
        <a href="https://sourceforge.net/p/freedos/news/feed.rss">FreeDOS</a>
        <a href="https://blogs.gnome.org/pabloyoyoista/feed/">GNOME adventures in mobile</a>
        <a href="https://blogs.gnome.org/shell-dev/feed/">GNOME Shell &amp; Mutter</a>
        <a href="https://grapheneos.social/@GrapheneOS.rss">GrapheneOS</a>
        <a href="https://www.haiku-os.org/index.xml">Haiku Project</a>
        <a href="https://libreboot.org/feed.xml">Libreboot</a>
        <a href="https://blog.mobian.org/index.xml">Mobian</a>
        <a href="https://mobile.nixos.org/index.xml">Mobile NixOS</a>
        <a href="https://osmocom.org/news.atom">Open Source Mobile Communications</a>
        <a href="https://www.parabola.nu/feeds/news/">Parabola GNU/Linux-libre</a>
        <a href="https://www.pine64.org/feed/">PINE64</a>
        <a href="https://postmarketos.org/blog/feed.atom">postmarketOS</a>
        <a href="https://www.qemu.org/feed.xml">QEMU</a>
        <a href="https://reactos.org/index.xml">ReactOS</a>
        <a href="https://blog.replicant.us/feed/">Replicant</a>
        <a href="https://forum.salixos.org/app.php/feed/news">Salix OS</a>
        <a href="https://www.trinitydesktop.org/rss.php">Trinity Desktop Environment</a>
        <a href="https://ubports.com/blog/ubports-news-1/feed">UBports</a>
        <a href="https://devices.ubuntu-touch.io/new.xml">Ubuntu Touch</a>
        <a href="https://forums.whonix.org/c/news/21.rss">Whonix</a>
      </div>
      <div class="subcategory">
        <h4>Development and Statistics</h4>
        <a href="https://clojurescript.org/feed.xml">ClojureScript</a>
        <a href="https://git.zx2c4.com/cgit/atom/?h=master">cgit</a>
        <a href="https://www.fltk.org/index.rss">Fast Light Toolkit</a>
        <a href="https://flatassembler.Net/atom.Php">Flat Assembler</a>
        <a href="https://about.gitea.com/index.xml">Gitea</a>
        <a href="https://blog.gtk.org/feed/">GTK Toolkit</a>
        <a href="https://kde.org/index.xml">KDE Desktop</a>
        <a href="https://labplot.kde.org/feed/">LabPlot</a>
        <a href="https://lxqt-project.org/feed.xml">LXQt Desktop</a>
        <a href="https://plausible.io/blog/feed.xml">Plausible Analytics</a>
        <a href="https://www.pypy.org/rss.xml">PyPy</a>
        <a href="https://rubyonrails.org/feed.xml">Ruby on Rails</a>
        <a href="https://blog.rust-lang.org/feed.xml">Rust</a>
      </div>
      <div class="subcategory">
        <h4>Education</h4>
        <a href="https://gcompris.net/feed-en.xml">GCompris</a>
      </div>
      <div class="subcategory">
        <h4>Games</h4>
        <a href="https://play0ad.com/feed/">0 A.D.</a>
        <a href="https://forum.cubers.net/syndication.php?fid=8&amp;limit=5&amp;type=atom1.0">AssaultCube</a>
        <a href="https://itch.io/feed/featured.xml">itch.io Featured Games</a>
        <a href="https://www.libretro.com/index.php/feed/">Libretro (Lakka &amp; RetroArch)</a>
        <a href="https://www.scummvm.org/feeds/atom/">ScummVM</a>
        <a href="https://www.speed-dreams.net/en/feed/">Speed Dreams</a>
        <a href="https://www.supertux.org/feed.xml">SuperTux</a>
        <a href="https://www.winehq.org/news/rss/">WineHQ</a>
        <a href="https://xonotic.org/index.xml">Xonotic</a>
      </div>
      <div class="subcategory">
        <h4>Graphics, Multimedia and Office</h4>
        <a href="https://discourse.ardour.org/c/blog/15.rss">Ardour</a>
        <a href="https://sourceforge.net/p/butt/activity/feed">Broadcast Using This Tool</a>
        <a href="https://xiph.org/flac/feeds/feed.xml">FLAC</a>
        <a href="https://handbrake.fr/rss.php">HandBrake</a>
        <a href="https://jackaudio.org/atom.xml">JACK Audio Connection Kit</a>
        <a href="https://fosstodon.org/@libreoffice.rss">LibreOffice</a>
        <a href="https://obsproject.com/blog/rss">Open Broadcaster Software</a>
        <a href="https://owncast.online/index.xml">Owncast</a>
        <a href="https://phoboslab.org/log/feed">Phoboslab (QOA and QOI)</a>
        <a href="https://kdenlive.org/en/feed/">Kdenlive</a>
        <a href="https://ruffle.rs/feed.xml">Ruffle</a>
        <a href="https://www.khronos.org/feeds/news_feed">The Khronos Group Inc</a>
        <a href="https://www.edrlab.org/feed/">Thorium Reader</a>
        <a href="https://krita.org/en/feed/">Krita</a>
        <a href="http://www.un4seen.com/rss.xml">Un4seen Developments</a>
      </div>
      <div class="subcategory">
        <h4>Network and Telecommunication</h4>
        <a href="https://apps.kde.org/akregator/index.xml">Akregator</a>
        <a href="https://brave.com/index.xml">Brave Browser</a>
        <a href="https://www.dillo.org/feed/">Dillo Browser</a>
        <a href="https://www.falkon.org/atom.xml">Falkon Browser</a>
        <a href="https://github.com/Floorp-Projects/Floorp/releases.atom">Floorp</a>
        <a href="https://leafletjs.com/atom.xml">Leaflet Dev Blog</a>
        <a href="https://lemmy.ml/feeds/c/librewolf.xml?sort=Active">Librewolf</a>
        <a href="https://lzone.de/liferea/blog/feed.xml">Liferea</a>
        <a href="https://www.nagios.com/feed/">Nagios</a>
        <a href="https://netnewswire.blog/feed.xml">NetNewsWire</a>
        <a href="https://blogs.gnome.org/thaller/feed/">NetworkManager</a>
        <a href="https://otter-browser.org/feed/">Otter Browser</a>
        <a href="https://quiterss.org/en/rss.xml">QuiteRSS</a>
        <a href="https://servo.org/blog/feed.xml">Servo</a>
        <a href="https://sourceforge.net/p/shareaza/activity/feed">Shareaza</a>
        <a href="https://spidermonkey.dev/feed.xml">SpiderMonkey</a>
        <a href="https://www.uzbl.org/atom.xml">Uzbl Browser</a>
        <a href="https://webkit.org/feed/atom/">WebKit</a>
      </div>
      <div class="subcategory">
        <h4>Package Management and Recovery Tools</h4>
        <!-- a href="https://cydia.saurik.com/">Cydia App Store</a -->
        <a href="https://f-droid.org/feed.xml">F-Droid Store</a>
        <!-- a href="https://orangefox.tech/feed.xml">OrangeFox</a -->
        <a href="https://twrp.me/feed.xml">TWRP</a>
      </div>
      <div class="subcategory">
        <h4>Miscellaneous</h4>
        <a href="https://bitwarden.com/blog/feed.xml">Bitwarden</a>
        <a href="https://sourceforge.net/p/hyperic-hq/activity/feed">Hyperic Application &amp; System Monitoring</a>
        <a href="https://texample.net/feeds/community/">The TeX community aggregator</a>
        <a href="https://tug.org/rss/tug.xml">TeX Users Group</a>
        <a href="https://techhub.social/@TeXUsersGroup.rss">TeX Users Group Updates</a>
      </div>
      <div class="subcategory">
        <h4>Theme</h4>
        <a href="https://aquoid.com/feed/">Aquoid</a>
        <!-- a href="https://github.com/ClassicOS-Themes">ClassicOS</a -->
        <!-- a href="https://draculatheme.com/">Dracula Theme</a -->
        <!-- a href="https://numixproject.github.io/feed/">Numix Project</a -->
        <!-- a href="https://shimmerproject.org/feed/">Shimmer Project</a -->
      </div>
    </div>
    <div class="category" id="syndication">
      <h3>Syndication &amp; XML</h3>
      <a href="https://activitypub.rocks/feed.xml">ActivityPub Rocks!</a>
      <a href="https://www.rss-specifications.com/blog-feed.xml">An RSS Blog</a>
      <a href="https://www.dublincore.org/index.xml">Dublin Core</a>
      <a href="https://www.feedforall.com/blog-feed.xml">FeedForAll</a>
      <a href="https://www.jsonfeed.org/feed.xml">JSON Feed</a>
      <a href="https://microformats.org/feed">Microformats</a>
      <a href="https://openrss.org/rss">Open RSS</a>
      <a href="http://opml.org/?format=opml">OPML</a>
      <a href="http://feeds.rssboard.org/rssboard">RSS Advisory Board</a>
      <a href="https://www.rss-specifications.com/article-feed.xml">RSS and News Feed Articles</a>
      <a href="http://scripting.com/rss.xml">Scripting News</a>
      <a href="https://blog.saxonica.com/atom.xml">Saxonica</a>
      <a href="http://docs.subtome.com/feed.xml">SubToMe</a>
      <a href="https://sword.cottagelabs.com/feed/">SWORD</a>
      <a href="http://rss.userland.com/xml/rss.xml">UserLand RSS Central</a>
      <a href="http://xml.coverpages.org/covernews.xml">XML Cover Pages</a>
      <a href="https://www.xml.com/feed/all/">XML.com</a>
    </div>
    <div class="category" id="telecom">
      <h3>Telecom, Mesh &amp; Mix Protocols</h3>
      <a href="https://ethlimo.substack.com/feed">ETH.LIMO</a>
      <a href="https://gemini.circumlunar.space/news/atom.xml">Gemini Project</a>
      <a href="https://www.gnunet.org/en/rss.xml">GNUnet</a>
      <a href="https://gopher.zone/index.xml">Highway to the Gopher Zone</a>
      <a href="https://geti2p.net/en/feed/blog/atom">I2P Blog</a>
      <a href="https://blog.ipfs.io/index.xml">IPFS</a>
      <a href="https://www.mysterium.network/blog-feed.xml">Mysterium Network</a>
      <a href="https://blog.nymtech.net/feed">Nym</a>
      <a href="https://openwrt.org/feed.php?mode=list">OpenWrt</a>
      <a href="https://oxen.io/feed/atom">Oxen Lokinet</a>
      <a href="https://panoramix-project.eu/feed/">Panoramix</a>
      <a href="https://phillymesh.net/post/index.xml">Philly Mesh</a>
      <a href="https://blog.torproject.org/feed.xml">Tor Project</a>
      <a href="https://veilid.com/atom.xml">Veilid Project</a>
      <a href="https://www.w3.org/blog/news/feed/atom">W3C</a>
      <a href="https://xmpp.org/feeds/all.atom.xml">XMPP Blog</a>
      <a href="https://yggdrasil-network.github.io/feed.xml">Yggdrasil Network</a>
    </div>
    <div class="category" id="torrents">
      <h3>Torrents</h3>
      <a href="https://androidkino.net/rss.xml">AndroidKino (RU)</a>
      <a href="https://angietorrents.cc/rss.php?custom=1">AngieTorrents</a>
      <a href="https://anidex.info/rss/">AniDex Tracker (JA)</a>
      <a href="https://www.anirena.com/rss.php">AniRena (JA)</a>
      <a href="https://audiobookbay.is/feed/atom/">AudioBook Bay</a>
      <a href="https://bangumi.moe/rss/latest">Bangumi Moe</a>
      <a href="https://eztv.re/ezrss.xml">EZTV</a>
      <a href="http://firebit.org/rss.xml">FireBit</a>
      <a href="https://fosstorrents.com/feed/distribution.xml">FOSS Torrents - Distributions</a>
      <a href="https://fosstorrents.com/feed/game.xml">FOSS Torrents - Games</a>
      <a href="https://fosstorrents.com/feed/software.xml">FOSS Torrents - Softwares</a>
      <a href="https://igg-games.com/feed">Install Guide Games</a>
      <a href="https://www.limetorrents.lol/rss/">Lime Torrents</a>
      <a href="https://nyaa.si/?page=rss">Nyaa</a>
      <a href="https://pcgamestorrents.com/feed">PCGamesTorrents</a>
      <a href="http://tracker2.postman.i2p/?view=AddRSSMap">Postman</a>
      <a href="https://rarbg.to/rss.php">RARBG</a>
      <a href="http://rutor.info/rss.php">RUTOR (EN/RU)</a>
      <a href="https://sktorrent.org/feed_rss.xml">SkTorrent</a>
      <a href="https://tpb.party/rss">The Pirate Bay</a>
      <a href="https://tokyo-tosho.net/rss.php">Tokyo Toshokan</a>
      <!--a href="https://www.tokyotosho.info/rss.php">Tokyo Toshokan</a-->
      <a href="https://www.torlock.com/rss.xml">Torlock</a>
      <a href="https://www.torrent911.me/rss">Torrent911 (FR)</a>
      <a href="https://www.torrentdownload.info/feed_latest">Torrent Download</a>
      <a href="https://www.torrentdownloads.pro/rss.xml">Torrent Downloads</a>
      <a href="https://torrentgalaxy.to/rss">TorrentGalaxy</a>
      <a href="https://booktracker.org/rss.php">Книжный трекер (RU)</a>
      <a href="https://gamestracker.org/torrents/rss/">Торрент игры (RU)</a>
    </div>
    <div class="category" id="video">
      <h3>Videos &amp; PeerTube</h3>
      <a href="https://altcensored.com/feed">altCensored</a>
      <a href="https://denshi.live/feeds/videos.atom">denshi.live</a>
      <a href="https://filmsbykris.com/rss.xml">Films By Kris</a>
      <a href="https://videos.lukesmith.xyz/feeds/videos.atom?sort=-publishedAt&amp;isLocal=true">Luke's Videos</a>
      <a href="https://diode.zone/feeds/videos.atom?videoChannelId=9828">Mr. Funk E. Dude's Place</a>
      <a href="https://media.ccc.de/news.atom">media.ccc.de</a>
      <a href="https://www.opensubtitles.com/" title="RSS Per Movie/Page">OpenSubtitles.com</a>
      <a href="http://truthstreammedia.com/feed/">Truthstream Media</a>
    </div>
    <div class="background center">
      Random news feed from <a class="feed-category"></a>:
      <p><b><a class="feed-url"></a></b></p>
    </div>
  </div>
  </div>
  <span class="decor"></span>
  <div id="software" class="segment">
  <h1>💿 Install Feed Reader Apps For Desktop And Mobile</h1>
  <h2>Take Your News With You - Everywhere You Go</h2>
  <div class="content">
    <p>This is a list of desktop applications, mobile apps and online services for you to choose from.</p>
    <p>This list includes news readers, podcast managers, torrent clients, chat bots, browsers and extensions which support syndication feeds.</p>
    <p>Recommended software are marked with 🔖</p>
    <div id="filter">
      <span class="filter" id="torrent">BitTorrent</span>
      <span class="filter" id="email">Email</span>
      <span class="filter" id="news">News</span>
      <span class="filter" id="music">Podcast</span>
      <span class="filter" id="browser">Browser</span>
    </div>
    <div class="category">
      <h3>Desktop</h3>
      <div class="subcategory" id="unix">
        <h4>Linux</h4>
        <a class="news" href="https://apps.kde.org/akregator/">Akregator</a>
        <a class="music" href="https://amarok.kde.org/">Amarok</a>
        <a class="browser" href="https://brave.com/">Brave</a>
        <a class="email" href="https://www.claws-mail.org/">Claws Mail</a>
        <a class="torrent" href="https://deluge-torrent.org/">Deluge</a>
        <a class="news" href="https://github.com/jeena/FeedTheMonkey">Feed The Monkey</a>
        <a class="news" href="https://fraidyc.at/">Fraidycat</a>
        <a class="music" href="https://gpodder.github.io/">gPodder</a>
        <a class="music" href="https://apps.kde.org/kasts/">Kasts</a>
        <a class="news recom" href="https://leechcraft.org/">LeechCraft</a>
        <a class="news recom" href="https://lzone.de/liferea/">Liferea</a>
        <a class="music" href="https://github.com/son-link/minimal-podcasts-player">Minimal Podcasts Player</a>
        <a class="news recom" href="https://apps.gnome.org/app/com.gitlab.newsflash/">NewsFlash</a>
        <a class="browser" href="https://otter-browser.org/">Otter Browser</a>
        <a class="torrent" href="https://www.qbittorrent.org/">qBittorrent</a>
        <a class="news" href="https://quiterss.org/">QuiteRSS</a>
        <a class="news" href="https://ravenreader.app/">Raven Reader</a>
        <a class="news" href="https://github.com/martinrotter/rssguard">RSS Guard</a>
        <a class="news" href="http://www.rssowl.org/">RSSOwl</a>
        <a class="news" href="https://github.com/Xyrio/RSSOwlnix">RSSOwlnix</a>
        <a class="music" href="https://wiki.gnome.org/Apps/Rhythmbox">Rhythmbox</a>
        <a class="news recom" href="https://textbrowser.github.io/spot-on/">Spot-On</a>
        <a class="music" href="https://strawberrymusicplayer.org/">Strawberry Music Player</a>
        <a class="email" href="https://www.thunderbird.net/">Thunderbird</a>
        <a class="news" href="https://www.open-tickr.net/">TICKR</a>
        <a class="torrent recom" href="https://www.tribler.org/">Tribler</a>
        <a class="browser" href="https://vivaldi.com/features/feed-reader/">Vivaldi</a>
      </div>
      <div class="subcategory" id="mac-os">
        <h4>macOS</h4>
        <a class="music" href="https://amarok.kde.org/">Amarok</a>
        <a class="browser" href="https://brave.com/">Brave</a>
        <a class="torrent" href="https://deluge-torrent.org/">Deluge</a>
        <a class="news" href="http://docserver.scripting.com/drummer/about.opml">Drummer</a>
        <a class="news" href="https://fraidyc.at/">Fraidycat</a>
        <a class="music" href="https://gpodder.github.io/">gPodder</a>
        <a class="news recom" href="https://leechcraft.org/">LeechCraft</a>
        <a class="music" href="https://github.com/son-link/minimal-podcasts-player">Minimal Podcasts Player</a>
        <a class="news recom" href="https://netnewswire.com/">NetNewsWire</a>
        <a class="browser" href="https://otter-browser.org/">Otter Browser</a>
        <a class="torrent" href="https://www.qbittorrent.org/">qBittorrent</a>
        <a class="news" href="https://quiterss.org/">QuiteRSS</a>
        <a class="news" href="https://ravenreader.app/">Raven Reader</a>
        <a class="news" href="https://github.com/martinrotter/rssguard">RSS Guard</a>
        <a class="news" href="http://www.rssowl.org/">RSSOwl</a>
        <a class="news" href="https://github.com/Xyrio/RSSOwlnix">RSSOwlnix</a>
        <a class="news recom" href="https://textbrowser.github.io/spot-on/">Spot-On</a>
        <a class="music" href="https://strawberrymusicplayer.org/">Strawberry Music Player</a>
        <a class="email" href="https://www.thunderbird.net/">Thunderbird</a>
        <a class="torrent recom" href="https://www.tribler.org/">Tribler</a>
        <a class="news recom" href="https://www.vienna-rss.com/">ViennaRSS</a>
        <a class="browser" href="https://vivaldi.com/features/feed-reader/">Vivaldi</a>
      </div>
      <div class="subcategory" id="react-os">
        <h4>React OS</h4>
        <h5>WineHQ and Windows</h5>
        <a class="music" href="https://amarok.kde.org/">Amarok</a>
        <a class="browser" href="https://brave.com/">Brave</a>
        <a class="email" href="https://www.claws-mail.org/">Claws Mail</a>
        <a class="torrent" href="https://deluge-torrent.org/">Deluge</a>
        <a class="news" href="http://www.feeddemon.com/">FeedDemon</a>
        <a class="news" href="https://fraidyc.at/">Fraidycat</a>
        <a class="music" href="https://gpodder.github.io/">gPodder</a>
        <a class="browser" href="http://kmeleonbrowser.org/">K-Meleon</a>
        <a class="news recom" href="https://leechcraft.org/">LeechCraft</a>
        <a class="music" href="https://github.com/son-link/minimal-podcasts-player">Minimal Podcasts Player</a>
        <a class="browser" href="https://otter-browser.org/">Otter Browser</a>
        <a class="torrent" href="https://www.qbittorrent.org/">qBittorrent</a>
        <a class="news" href="https://quiterss.org/">QuiteRSS</a>
        <a class="news" href="https://ravenreader.app/">Raven Reader</a>
        <a class="news" href="http://rssbandit.org/">RSS Bandit</a>
        <a class="news" href="https://github.com/martinrotter/rssguard">RSS Guard</a>
        <a class="news" href="http://www.rssowl.org/">RSSOwl</a>
        <a class="news" href="https://github.com/Xyrio/RSSOwlnix">RSSOwlnix</a>
        <a class="news" href="http://sharpreader.net/">SharpReader</a>
        <a class="news recom" href="https://textbrowser.github.io/spot-on/">Spot-On</a>
        <a class="music" href="https://strawberrymusicplayer.org/">Strawberry Music Player</a>
        <a class="email" href="https://www.thunderbird.net/">Thunderbird</a>
        <a class="torrent recom" href="https://www.tribler.org/">Tribler</a>
        <a class="browser" href="https://vivaldi.com/features/feed-reader/">Vivaldi</a>
      </div>
    </div>
    <div class="category">
      <h3>Mobile</h3>
      <div class="subcategory" id="android-os">
        <h4>Android</h4>
        <h5>Above Phone, AOSPA, CopperheadOS, DivestOS, GrapheneOS and LineageOS</h5>
        <a class="browser" href="https://brave.com/">Brave</a>
        <a class="news" href="https://f-droid.org/en/packages/com.nononsenseapps.feeder/">Feeder</a>
        <a class="news" href="https://f-droid.org/packages/org.decsync.flym/">Flym DecSync</a>
        <a class="music" href="https://apps.kde.org/kasts/">Kasts</a>
        <a class="torrent recom" href="https://f-droid.org/en/packages/org.proninyaroslav.libretorrent/">LibreTorrent</a>
        <a class="music" href="https://f-droid.org/en/packages/io.gitlab.listentogether">ListenTogether</a>
        <a class="news" href="https://f-droid.org/en/packages/co.appreactor.news/">News</a>
        <a class="news" href="https://f-droid.org/en/packages/com.nunti/">Nunti</a>
        <a class="music" href="https://f-droid.org/en/packages/com.podverse.fdroid/">Podverse</a>
        <a class="news" href="https://f-droid.org/en/packages/me.ash.reader/">Read You</a>
        <a class="news" href="https://selfoss.aditu.de/">selfoss</a>
        <a class="news recom" href="https://f-droid.org/en/packages/com.aerotoad.thud/">Thud</a>
        <a class="torrent" href="https://f-droid.org/en/packages/org.transdroid.full/">Transdroid</a>
        <a class="browser" href="https://vivaldi.com/features/feed-reader/">Vivaldi</a>
      </div>
      <div class="subcategory" id="unix">
        <h4>Linux Phone</h4>
        <h5>Droidian, Kupfer Linux, Mobian, Mobile NixOS and postmarketOS</h5>
        <a class="news" href="https://apps.kde.org/alligator/">Alligator</a>
        <a class="news" href="https://gfeeds.gabmus.org/">Feeds</a>
        <a class="music" href="https://gpodder.github.io/">gPodder</a>
        <a class="music" href="https://apps.kde.org/kasts/">Kasts</a>
      </div>
      <div class="subcategory" id="gerda-os">
        <h4>GerdaOS and KaiOS</h4>
        <a class="news" href="https://store.bananahackers.net/#feedolin">feedolin</a>
        <a class="music" href="https://store.bananahackers.net/#FoxCastLite">FoxCast Lite</a>
        <a class="music" href="https://store.bananahackers.net/#Mica">Mica</a>
        <a class="music" href="https://store.bananahackers.net/#PodKast">PodKast</a>
        <a class="music" href="https://store.bananahackers.net/#podlp">PodLP</a>
        <a class="news" href="https://store.bananahackers.net/#n4no.com.rss-reader">RSS Reader</a>
      </div>
      <div class="subcategory" id="ios">
        <h4>iOS</h4>
        <a class="browser" href="https://brave.com/">Brave</a>
        <a class="news" href="https://netnewswire.com/">NetNewsWire</a>
        <a class="music" href="https://github.com/guumeyer/Podcast">Podcast</a>
        <a class="music" href="https://github.com/rafaelclaycon/PodcastApp">PodcastApp</a>
        <a class="news" href="https://selfoss.aditu.de/">selfoss</a>
      </div>
      <div class="subcategory" id="sailfish-os">
        <h4>Sailfish OS</h4>
        <a class="news" href="https://github.com/mkiol/kaktus">Kaktus</a>
        <a class="news" href="https://github.com/donaggio/harbour-feedhaven">Feed Haven</a>
        <a class="news" href="http://gitlab.unique-conception.org/apps-4-sailfish/feed-me">Feed Me</a>
        <a class="music" href="https://gpodder.github.io/">gPodder</a>
        <a class="news" href="https://github.com/walokra/haikala">Haikala</a>
        <a class="news" href="https://github.com/pycage/tidings">Tidings</a>
      </div>
      <div class="subcategory" id="tizen">
        <h4>Tizen</h4>
        <a class="news" href="https://github.com/CESARBR/tizenreader">Tizen Reader</a>
      </div>
      <div class="subcategory" id="ubports">
        <h4>Ubuntu Touch</h4>
        <a class="music" href="https://open-store.io/app/com.mikeasoft.podbird">Podbird</a>
        <a class="music" href="https://open-store.io/app/soy.iko.podphoenix">Podphoenix</a>
        <a class="news" href="https://open-store.io/app/rssreader.florisluiten">RSSreader</a>
        <a class="news" href="https://open-store.io/app/simplestrss.kazord">SimplestRSS</a>
        <!-- a class="torrent" href="https://open-store.io/app/transmission.pavelprosto">Transmission</a -->
        <!-- a class="torrent" href="https://open-store.io/app/tr.davidv.dev">Transmission Remote</a -->
        <a class="news" href="https://open-store.io/app/darkeye.ursses">uRsses</a>
      </div>
    </div>
    <div class="category">
      <h3>Chat Bots</h3>
        <h4>ActivityPub (Mastodon)</h4>
        <a class="news" href="https://codeberg.org/MarvinsMastodonTools/feed2fedi">Feed2Fedi</a>
        <a class="news" href="https://gitlab.com/chaica/feed2toot">Feed2toot</a>
        <a class="news" href="https://git.sp-codes.de/samuel-p/feed2toot-docker">feed2toot-docker</a>
        <h4>XMPP (aka Jabber)</h4>
        <a class="news" href="https://github.com/imattau/atomtopubsub">AtomToPubsub</a>
        <a class="news" href="https://salsa.debian.org/mdosch/feed-to-muc">feed-to-muc</a>
        <a class="news" href="http://www.jotwewe.de/de/xmpp/jabrss/jabrss_en.htm">JabRSS</a>
        <a class="news" href="https://codeberg.org/TheCoffeMaker/Morbot">Morbot</a>
        <a class="news" href="https://gitgud.io/sjehuda/slixfeed">Slixfeed</a>
    </div>
    <div class="category">
      <h3>Browser Extensions</h3>
      <a class="news" href="https://addons.mozilla.org/firefox/addon/boring-rss/">Boring RSS</a>
      <a class="news" href="https://nodetics.com/feedbro/">Feedbro</a>
      <a class="news" href="https://code.guido-berhoerster.org/addons/firefox-addons/feed-preview/">Feed Preview</a>
      <a class="news" href="https://fraidyc.at/">Fraidycat</a>
      <a class="news" href="https://github.com/nt1m/livemarks/">Livemarks</a>
      <a class="news" href="https://github.com/mpod/mpage">mPage</a>
      <a class="news" href="https://github.com/SmartRSS/Smart-RSS">Smart RSS</a>
    </div>
    <div class="category">
      <h3>Terminal</h3>
      <a class="news" href="https://codezen.org/canto-ng/">Canto (The Next Generation RSS)</a>
      <a class="news" href="https://github.com/zefr0x/mujammi">Mujammi' | مجمع</a>
      <a class="news" href="https://newsboat.org/">Newsboat</a>
      <a class="news" href="https://ploum.net/2023-11-25-offpunk2.html">Offpunk</a>
      <a class="news" href="https://sr.ht/~ghost08/photon/">Photon</a>
      <a class="torrent" href="https://github.com/rakshasa/rtorrent">RTorrent</a>
      <a class="torrent" href="https://github.com/dpsenner/bridge-from-torrent-rss-feed-to-rtorrent">bridge-from-torrent-rss-feed-to-rtorrent</a>
      <a class="news" href="https://codemadness.org/sfeed_curses-ui.html">Sfeed</a>
    </div>
    <div class="category">
      <h3>HTML (Self Hosted)</h3>
      <a class="news" href="https://www.commafeed.com/">CommaFeed</a>
      <a class="news" href="https://feedbin.com/">Feedbin</a>
      <a class="news" href="https://feedhq.org/">FeedHQ</a>
      <a class="news" href="https://0xdstn.site/projects/feeds/">Feeds</a>
      <a class="news" href="http://feedonfeeds.com/">Feeds on Feeds</a>
      <a class="news" href="https://freshrss.org/">FreshRSS</a>
      <a class="news" href="https://miniflux.app/">Miniflux</a>
      <a class="news" href="https://offog.org/code/rawdog/">rawdog</a>
      <a class="news" href="https://0xdstn.site/projects/reader/">Reader</a>
      <a class="news" href="https://github.com/acavalin/rrss">RRSS</a>
      <a class="torrent" href="https://github.com/Novik/ruTorrent">ruTorrent</a>
      <a class="news" href="https://selfoss.aditu.de/">selfoss</a>
      <a class="news" href="https://tt-rss.org/">Tiny Tiny RSS</a>
      <a class="news" href="https://github.com/nkanaev/yarr">yarr</a>
      <a class="news" href="https://github.com/twm/yarrharr">Yarrharr</a>
    </div>
    <div class="category">
      <h3>HTML (Service)</h3>
        <a class="news" href="https://www.commafeed.com/">CommaFeed</a>
        <a class="news" href="https://drummer.land/">Drummer</a>
        <a class="news" href="https://feedbin.com/">Feedbin</a>
        <a class="news" href="https://feeder.co/">Feeder</a>
        <a class="news" href="https://feedland.org/">FeedLand</a>
        <a class="news" href="https://feedly.com/">Feedly</a>
        <a class="news" href="https://goodnews.click/">Good News</a>
        <a class="news" href="https://www.inoreader.com/">Inoreader</a>
        <a class="news" href="http://www.netvibes.com/en">Netvibes</a>
        <a class="news" href="https://newsblur.com/">NewsBlur</a>
        <a class="news" href="https://www.reedah.com/">Reedah</a>
        <a class="news" href="https://theoldreader.com/">The Old Reader</a>
    </div>
  </div>
  </div>
  <span class="decor"></span>
  <div id="services-publish" class="segment">
    <h1>🔊 Publishing Platforms With Syndication</h1>
    <h2>Express Yourself Through Text, Audio and Video</h2>
    <!-- h2>Be Truely Social</h2 -->
    <div class="content">
      <!-- p>Truely social means to express yourself through text, audio and video in a truely free platform.</p -->
      <p>Do you want to start a syndication-enabled podcast?</p>
      <p>The following blog and podcast hosting services provide access to syndication. Recommended providers are marked with 🔖</p>
      <div>
        <div class="category">
          <h3>Decentralized Services (ActivityPub)</h3>
          <ul>
            <li><a class="recom" href="https://akkoma.social/">Akkoma</a></li>
            <li><a href="https://joinbookwyrm.com/instances/">BookWyrm</a></li>
            <li><a href="https://diaspora.fediverse.observer/list">diaspora*</a></li>
            <li><a class="recom" href="https://funkwhale.fediverse.observer/list">Funkwhale</a></li>
            <li><a href="https://friendica.fediverse.observer/list">Friendica</a></li>
            <li><a title="Also known as Identi.ca, Quitter and StatusNet" href="https://gnusocial.network/try/">GNU social</a></li>
            <li><a class="recom" href="https://hubzilla.fediverse.observer/list">Hubzilla</a></li>
            <li><a href="https://infosec.pub/instances">Lemmy</a></li>
            <li><a href="https://instances.social/">Mastodon</a></li>
            <li><a class="recom" href="https://micro.blog/">Micro.blog</a></li>
            <li><a class="recom" href="https://monocles.social/">monocles social</a></li>
            <li><a class="recom" href="https://instances.joinpeertube.org/">PeerTube</a></li>
            <li><a href="https://pixelfed.fediverse.observer/list">Pixelfed</a></li>
            <li><a class="recom" href="https://pleroma.social/">Pleroma</a></li>
            <li><a href="https://postmarks.glitch.me/">Postmarks</a></li>
            <li><a href="https://soapbox.pub/servers/">Soapbox</a></li>
            <li><a href="https://takahe.social/">Takahē</a></li>
          </ul>
        </div>
        <div class="category">
          <h3>Decentralized Services (Blockchain, DHT and XMPP)</h3>
          <ul>
            <li><a href="https://getaether.net/">Aether</a></li>
            <li><a class="recom" href="https://libervia.org/">Libervia</a></li>
            <li><a class="recom" href="https://movim.eu/">Movim</a></li>
            <li><a class="recom" href="https://plebbit.com/">Plebbit</a> (h-entry syndication)</li>
            <li><a href="https://scuttlebutt.nz/">Scuttlebutt</a></li>
          </ul>
        </div>
        <div class="category">
          <h3>Free Of Charge Services</h3>
          <ul>
            <li><a href="https://www.acast.com/">Acast</a></li>
            <li><a href="https://www.blogtalkradio.com/">Blog Talk Radio</a></li>
            <li><a class="recom" href="https://www.chatons.org/search/by-service?service_type_target_id=154">Chatons</a> (list of services)</li>
            <li><a href="https://castos.com/">Castos</a></li>
            <li><a href="https://feedpress.com/">FeedPress</a></li>
            <li><a href="https://www.forumotion.com/">FORUMOTION</a></li>
            <li><a class="recom" href="https://www.justjournal.com/">Just Journal</a></li>
            <li><a href="http://libsyn.com/">libsyn</a></li>
            <li><a class="recom" href="https://mov.im/">Mov.im</a></li>
            <li><a class="recom" href="https://neocities.org/">Neocities</a></li>
            <li><a class="recom" href="https://noblogs.org/">NoBlogs</a></li>
            <li><a href="https://podbean.com/">PodBean</a></li>
            <li><a href="https://podomatic.com/">Podomatic</a></li>
            <li><a href="https://rawvoice.com/">RawVoice</a></li>
            <li><a href="https://rss.com/">RSS.com</a></li>
            <li><a href="https://www.spreaker.com/">Spreaker</a></li>
            <li><a href="https://substack.com/">Substack</a></li>
            <li><a class="recom" href="https://tedomum.net/service/">TeDomum</a> (list of services)</li>
            <li><a class="recom" href="https://weblog.lol/">weblog.lol</a></li>
            <li><a href="https://www.typepad.com/">Typepad</a></li>
          </ul>
        </div>
        <div class="category">
          <h3>Prepaid Services</h3>
          <ul>
            <li><a href="https://www.cloudaccess.net/">CloudAccess</a></li>
            <li><a href="https://www.hetzner.com/">Hetzner</a></li>
            <li><a href="https://www.hostinger.co.uk/">Hostinger</a></li>
            <li><a href="https://masto.host/">Masto.host</a></li>
            <li><a class="recom" href="https://micro.blog/">Micro.blog</a></li>
            <li><a class="recom" href="https://monocles.eu/more/">monocles</a></li>
            <li><a class="recom" href="https://monocles.chat/">monocles chat</a></li>
            <li><a href="https://notado.app/">Notado</a></li>
            <li><a href="https://www.rochen.com/">Rochen</a></li>
            <li><a href="https://www.strato.de/">STRATO</a></li>
            <li><a href="https://www.typepad.com/">Typepad</a></li>
            <li><a class="recom" href="https://xrd.me/">XRD.ME</a></li>
            <li><a class="recom" href="https://zourit.net/">Zourit</a></li>
          </ul>
        </div>
        <div class="category">
          <h3>Self Hosted</h3>
          <p>Publishing platforms that support Atom Syndication are recommended and marked with 🔖.</p>
          <ul>
            <li><a href="https://forgejo.sny.sh/sun/Axiom">Axiom</a></li>
            <li><a href="https://backdropcms.org/">Backdrop CMS</a> (<a href="https://github.com/backdrop/backdrop">code</a>)</li>
            <li><a class="recom" href="https://barf.btxx.org/">barf</a> (<a href="https://git.btxx.org/barf">code</a>)</li>
            <li><a href="https://github.com/cfenollosa/bashblog">bashblog</a></li>
            <li><a href="https://justine.smithies.me.uk/blarg.html">blarg</a> (<a href="https://git.sr.ht/~justinesmithies/blarg">code</a>)</li>
            <li><a href="https://www.karl.berlin/blog.html">blog.sh</a> (<a href="https://github.com/karlb/karl.berlin/blob/master/blog.sh">code</a>)</li>
            <li><a class="recom" href="https://blogo.site/">Blogo</a> (<a href="https://github.com/pluja/blogo">code</a>)</li>
            <li><a class="recom" href="https://chyrplite.net/">Chyrp Lite</a> (<a href="https://github.com/xenocrat/chyrp-lite">code</a>)</li>
            <li><a href="https://www.concretecms.com/">Concrete CMS</a></li>
            <li><a href="https://dataswamp.org/~solene/tag-cl-yag.html">cl-yag</a> (<a href="git://bitreich.org/cl-yag">code</a>)</li>
            <!-- li><a href="https://www.dnnsoftware.com/community/download">DNN</a></li -->
            <li><a href="https://www.dokuwiki.org/dokuwiki">DokuWiki</a></li>
            <li><a href="https://www.drupal.org/">Drupal</a></li>
            <li><a class="recom" href="https://utcc.utoronto.ca/~cks/space/dwiki/DWiki">DWiki (Dinky Wiki)</a></li>
            <li><a href="https://www.11ty.dev/">Eleventy</a></li>
            <li><a href="https://github.com/llewelld/flagellum">Flagellum</a></li>
            <li><a href="https://formatforest.com/">FormatForest</a> (<a href="https://gitlab.com/nadimk/formatforest">code</a>)</li>
            <li><a class="recom" href="https://foswiki.org/">Foswiki</a></li>
            <li><a href="https://sourceforge.net/projects/gallery/">Gallery</a></li>
            <li><a href="https://www.gatsbyjs.com/">Gatsby</a> (<a href="https://github.com/gatsbyjs/gatsby">code</a>)</li>
            <li><a href="https://ghost.org/">Ghost</a> (<a href="https://github.com/TryGhost/Ghost">code</a>)</li>
            <li><a class="recom" href="https://getgrav.org/">Grav</a></li>
            <li><a href="https://github.com/infoforcefeed/greshunkel">Greshunkel</a></li>
            <li><a href="https://github.com/botherder/habu">Habu</a></li>
            <li><a class="recom" href="https://dthompson.us/projects/haunt.html">Haunt</a></li>
            <li><a href="https://gohugo.io/">Hugo</a></li>
            <li><a href="http://ikiwiki.info/">ikiwiki</a></li>
            <li><a class="recom" href="https://jekyllrb.com/">Jekyll</a></li>
            <li><a href="https://www.joomla.org/">Joomla</a></li>
            <li><a class="recom" href="https://www.justjournal.com/">Just Journal</a> (<a href="https://sourceforge.net/projects/justjournal/">code</a>)</li>
            <li><a href="https://gt.kalli.st/czar/kalli.st">kallist CMS</a></li>
            <li><a class="recom" href="https://libervia.org/">Libervia</a></li>
            <li><a href="https://squidfunk.github.io/mkdocs-material/">Material for MkDocs</a></li>
            <li><a href="http://moinmo.in/">MoinMoin</a></li>
            <li><a class="recom" href="https://movim.eu/">Movim</a></li>
            <li><a class="recom" href="https://getnikola.com/">Nikola</a></li>
            <li><a class="recom" href="http://octopress.org/">Octopress</a> (<a href="https://sourceforge.net/p/oscailt/code/HEAD/tree/">code</a>)</li>
            <li><a href="https://oddmuse.org/">Oddmuse</a> (<a href="https://github.com/kensanata/oddmuse">code</a>)</li>
            <li><a class="recom" href="http://www.indymedia.ie/oscailt/">Oscailt</a></li>
            <li><a href="https://pebble.sourceforge.net/">Pebble</a></li>
            <li><a class="recom" href="https://getpelican.com/">Pelican</a></li>
            <li><a href="http://phpwiki.demo.free.fr/">PhpWiki</a></li>
            <li><a href="https://picocms.org/">Pico</a></li>
            <li><a href="https://cblgh.org/plain/">plain</a> (<a href="https://github.com/cblgh/plain">code</a>)</li>
            <li><a href="https://www.pmwiki.org/">PmWiki</a> (see <a href="https://www.pmwiki.org/wiki/Cookbook/RSS">Cookbook/RSS</a>)</li>
            <li><a href="https://podcastgenerator.net/">Podcast Generator</a></li>
            <!-- li><a a href="https://processwire.com/">ProcessWire</a></li -->
            <li><a class="recom" href="https://getpublii.com/">Publii</a></li>
            <li><a href="https://pulkomandy.tk/_/_PulkoCMS/_About%20PulkoCMS">PulkoCMS</a></li>
            <li><a href="https://quarto.org/">Quarto</a> (<a href="https://github.com/quarto-dev/quarto-cli">code</a>)</li>
            <!-- li><a href="http://radiantcms.org/">Radiant CMS</a></li -->
            <li><a class="recom" href="https://git.xmpp-it.net/sch/Rivista">Rivista</a></li>
            <li><a href="https://s9y.org/">Serendipity</a></li>
            <li><a class="recom" href="https://soupault.app/">soupault</a> (<a href="https://github.com/PataphysicalSociety/soupault">code</a>)</li>
            <li><a href="https://gitlab.com/kevincox/statit">statit</a></li>
            <li><a href="https://github.com/PiotrZPL/staurolite">Staurolite</a></li>
            <li><a href="https://github.com/garbeam/staw">staw</a></li>
            <li><a class="recom" href="https://textpattern.com/">Textpattern CMS</a></li>
            <li><a href="https://github.com/TurnWheel/TWCMS">TW-CMS</a></li>
            <!-- li><a href="https://twiki.org/">TWiki</a></li -->
            <li><a href="https://typo3.org/">TYPO3</a></li>
            <li><a href="https://umbraco.com/">Umbraco</a> (<a href="https://github.com/umbraco/Umbraco-CMS">code</a>)</li>
            <li><a class="recom" href="https://webgen.gettalong.org/">webgen</a> (<a href="https://github.com/gettalong/webgen">code</a>)</li>
            <li><a href="http://werc.cat-v.org/">werc</a></li>
            <li><a class="recom" href="https://wordpress.org/">WordPress</a></li>
            <li><a class="recom" href="https://git.xmpp-it.net/sch/Rivista">XMPP Journal Publisher (XJP)</a></li>
            <li><a href="https://www.xwiki.org/">XWiki</a></li>
            <li><a href="https://github.com/jgm/yst">yst</a></li>
            <li><a href="https://www.getzola.org/">Zola</a></li>
          </ul>
        </div>
        <div class="category">
          <h3>Of Note</h3>
          <p>Decentralized services are <i>very and mostly</i> encouraged; Use one ActivityPub-based account to communicate with all services and platforms.</p>
          <p>Free of monetary charge services are generally <i>not</i> encouraged and are mostly usable as a backup medium.</p>
          <p>You are encouraged to host <b>your own</b> server connected to <a href="https://i2pd.readthedocs.io/en/latest/tutorials/http/#host-anonymous-website">the I2P network</a>.</p>
          <p>Whatever is your medium of choice to publish your podcast, best ways to make your files available are via BitTorrent, I2P and IPFS.</p>
          <p>* PeerTube has built-in BitTorrent support.</p>
        </div>
      </div>
    </div>
  </div>
  <span class="decor"></span>
  <div id="blog" class="segment">
    <h1>📢 Create Your Site, Blog And Even Both</h1>
    <h2>This Is The Creative Collective. Decentralize, Curate, Diverse.</h2>
    <p>Ignore social media, it has sucked up everything cool about the internet and made it absolutely terrible to those who are bound and manipulated by it.</p>
    <p>Join to the campaign <a href="https://100daystooffload.com/">100 Days To Offload</a>!</p>
    <p>Apply to the January 2023 endeavor <a href="https://bringback.blog/">Bring Back Blogs</a>!</p>
    <p>And read the <a href="https://sizeof.cat/post/dos-and-donts/">Dos and Don'ts of current times</a>.</p>
    <p>And if you don't already have a site, then <a href="https://videos.lukesmith.xyz/w/9aadaf2f-a8e7-4579-913d-b250fd1aaaa9">Get a Website Now!</a> (Don't be a Web Peasant!)</p>
    <h3>Articles</h3>
    <ul>
      <li><a href="https://sizeof.cat/post/dos-and-donts/">Dos and Don'ts of current times</a></li>
      <li><a href="https://jacobwsmith.xyz/stories/200812.html">How to Stop the Boring from being Boring</a></li>
      <li><a href="https://thoughts.melonking.net/guides/introduction-to-the-web-revival-1-what-is-the-web-revival">Intro to the Web Revival #1: What is the Web Revival?</a></li>
      <!-- li><a href="https://www.theblogstarter.com/">The Blog Starter - How To Start A Blog In 2023</a></li -->
    </ul>
    <h3>Campaigns</h3>
    <ul>
      <li><a href="https://100daystooffload.com/">100 Days To Offload</a></li>
      <li><a href="https://bringback.blog/">Bring Back Blogs! January 2023</a></li>
    </ul>
    <h3>Free Of Charge Services</h3>
    <ul>
      <li><a class="recom" href="https://www.chatons.org/search/by-service?service_type_target_id=154">Chatons</a> (list of services)</li>
      <li><a href="https://feedpress.com/">FeedPress</a></li>
      <li><a href="https://www.forumotion.com/">FORUMOTION</a></li>
      <li><a href="http://libsyn.com/">libsyn</a></li>
      <li><a class="recom" href="https://neocities.org/">Neocities</a></li>
      <li><a class="recom" href="https://noblogs.org/">NoBlogs</a></li>
      <li><a href="https://podbean.com/">PodBean</a></li>
      <li><a href="https://www.spreaker.com/">Spreaker</a></li>
      <li><a href="https://substack.com/">Substack</a></li>
      <li><a class="recom" href="https://tedomum.net/service/">TeDomum</a> (list of services)</li>
      <li><a href="https://www.typepad.com/">Typepad</a></li>
      <li><a class="recom" href="https://weblog.lol/">weblog.lol</a></li>
    </ul>
    <h3>Prepaid Services</h3>
    <ul>
      <li><a href="https://www.cloudaccess.net/">CloudAccess</a></li>
      <li><a href="https://www.hetzner.com/">Hetzner</a></li>
      <li><a href="https://www.hostinger.co.uk/">Hostinger</a></li>
      <li><a href="https://masto.host/">Masto.host</a></li>
      <li><a class="recom" href="https://micro.blog/">Micro.blog</a></li>
      <li><a class="recom" href="https://monocles.eu/more/">monocles</a></li>
      <li><a class="recom" href="https://monocles.chat/">monocles chat</a></li>
      <li><a href="https://www.rochen.com/">Rochen</a></li>
      <li><a href="https://www.strato.de/">STRATO</a></li>
      <li><a href="https://www.typepad.com/">Typepad</a></li>
      <li><a class="recom" href="https://xrd.me/">XRD.ME</a></li>
      <li><a class="recom" href="https://zourit.net/">Zourit</a></li>
    </ul>
    <h3>Software</h3>
    <p>With over a billion people and over hundred of trillions of posts, you can choose from a variety of CMS or community and forum management software systems with support for syndication.</p>
    <p class="background" title="This document shows you that 'free and open source software' are also subjected to a bad type of politics, yet it is recommended to choose open source forum software, just in case some feature is gone and you desire to bring it back.">We advise to choose open source forum software.  If you choose a proprietary software, please <i>do</i> make sure that you have a convenient way to import/export and backup all data.</p>
    <h4>Site Management</h4>
    <p>Publishing platforms that support Atom Syndication are recommended and marked with 🔖.</p>
    <ul>
      <li><a href="https://forgejo.sny.sh/sun/Axiom">Axiom</a></li>
      <li><a href="https://backdropcms.org/">Backdrop CMS</a> (<a href="https://github.com/backdrop/backdrop">code</a>)</li>
      <li><a class="recom" href="https://barf.btxx.org/">barf</a> (<a href="https://git.btxx.org/barf">code</a>)</li>
      <li><a href="https://github.com/cfenollosa/bashblog">bashblog</a></li>
      <li><a href="https://justine.smithies.me.uk/blarg.html">blarg</a> (<a href="https://git.sr.ht/~justinesmithies/blarg">code</a>)</li>
      <li><a href="https://www.karl.berlin/blog.html">blog.sh</a> (<a href="https://github.com/karlb/karl.berlin/blob/master/blog.sh">code</a>)</li>
      <li><a class="recom" href="https://blogo.site/">Blogo</a> (<a href="https://github.com/pluja/blogo">code</a>)</li>
      <li><a class="recom" href="https://chyrplite.net/">Chyrp Lite</a> (<a href="https://github.com/xenocrat/chyrp-lite">code</a>)</li>
      <li><a href="https://www.concretecms.com/">Concrete CMS</a></li>
      <li><a href="https://dataswamp.org/~solene/tag-cl-yag.html">cl-yag</a> (<a href="git://bitreich.org/cl-yag">code</a>)</li>
      <!-- li><a href="https://www.dnnsoftware.com/community/download">DNN</a></li -->
      <li><a href="https://www.dokuwiki.org/dokuwiki">DokuWiki</a></li>
      <li><a href="https://www.drupal.org/">Drupal</a></li>
      <li><a class="recom" href="https://utcc.utoronto.ca/~cks/space/dwiki/DWiki">DWiki (Dinky Wiki)</a></li>
      <li><a href="https://www.11ty.dev/">Eleventy</a></li>
      <li><a href="https://github.com/llewelld/flagellum">Flagellum</a></li>
      <li><a href="https://formatforest.com/">FormatForest</a> (<a href="https://gitlab.com/nadimk/formatforest">code</a>)</li>
      <li><a class="recom" href="https://foswiki.org/">Foswiki</a></li>
      <li><a href="https://sourceforge.net/projects/gallery/">Gallery</a></li>
      <li><a href="https://www.gatsbyjs.com/">Gatsby</a> (<a href="https://github.com/gatsbyjs/gatsby">code</a>)</li>
      <li><a href="https://ghost.org/">Ghost</a> (<a href="https://github.com/TryGhost/Ghost">code</a>)</li>
      <li><a class="recom" href="https://getgrav.org/">Grav</a></li>
      <li><a href="https://github.com/infoforcefeed/greshunkel">Greshunkel</a></li>
      <li><a href="https://github.com/botherder/habu">Habu</a></li>
      <li><a class="recom" href="https://dthompson.us/projects/haunt.html">Haunt</a></li>
      <li><a href="https://gohugo.io/">Hugo</a></li>
      <li><a href="http://ikiwiki.info/">ikiwiki</a></li>
      <li><a class="recom" href="https://jekyllrb.com/">Jekyll</a></li>
      <li><a href="https://www.joomla.org/">Joomla</a></li>
      <li><a class="recom" href="https://git.xmpp-it.net/sch/Rivista">Rivista</a></li>
      <li><a class="recom" href="https://www.justjournal.com/">Just Journal</a> (<a href="https://sourceforge.net/projects/justjournal/">code</a>)</li>
      <li><a href="https://gt.kalli.st/czar/kalli.st">kallist CMS</a></li>
      <li><a class="recom" href="https://libervia.org/">Libervia</a></li>
      <li><a href="https://squidfunk.github.io/mkdocs-material/">Material for MkDocs</a></li>
      <li><a href="http://moinmo.in/">MoinMoin</a></li>
      <li><a class="recom" href="https://movim.eu/">Movim</a></li>
      <li><a class="recom" href="https://getnikola.com/">Nikola</a></li>
      <li><a class="recom" href="http://octopress.org/">Octopress</a></li>
      <li><a href="https://oddmuse.org/">Oddmuse</a> (<a href="https://github.com/kensanata/oddmuse">code</a>)</li>
      <li><a class="recom" href="http://www.indymedia.ie/oscailt/">Oscailt</a> (<a href="https://sourceforge.net/p/oscailt/code/HEAD/tree/">code</a>)</li>
      <li><a href="https://pebble.sourceforge.net/">Pebble</a></li>
      <li><a class="recom" href="https://getpelican.com/">Pelican</a></li>
      <li><a href="http://phpwiki.demo.free.fr/">PhpWiki</a></li>
      <li><a href="https://picocms.org/">Pico</a></li>
      <li><a href="https://cblgh.org/plain/">plain</a> (<a href="https://github.com/cblgh/plain">code</a>)</li>
      <li><a href="https://www.pmwiki.org/">PmWiki</a> (see <a href="https://www.pmwiki.org/wiki/Cookbook/RSS">Cookbook/RSS</a>)</li>
      <li><a href="https://podcastgenerator.net/">Podcast Generator</a></li>
      <!-- li><a a href="https://processwire.com/">ProcessWire</a></li -->
      <li><a class="recom" href="https://getpublii.com/">Publii</a></li>
      <li><a href="https://pulkomandy.tk/_/_PulkoCMS/_About%20PulkoCMS">PulkoCMS</a></li>
      <li><a href="https://quarto.org/">Quarto</a> (<a href="https://github.com/quarto-dev/quarto-cli">code</a>)</li>
      <!-- li><a href="http://radiantcms.org/">Radiant CMS</a></li -->
      <li><a href="https://s9y.org/">Serendipity</a></li>
      <li><a class="recom" href="https://soupault.app/">soupault</a> (<a href="https://github.com/PataphysicalSociety/soupault">code</a>)</li>
      <li><a href="https://gitlab.com/kevincox/statit">statit</a></li>
      <li><a href="https://github.com/PiotrZPL/staurolite">Staurolite</a></li>
      <li><a href="https://github.com/garbeam/staw">staw</a></li>
      <li><a class="recom" href="https://textpattern.com/">Textpattern CMS</a></li>
      <li><a href="https://github.com/TurnWheel/TWCMS">TW-CMS</a></li>
      <!-- li><a href="https://twiki.org/">TWiki</a></li -->
      <li><a href="https://typo3.org/">TYPO3</a></li>
      <li><a href="https://umbraco.com/">Umbraco</a> (<a href="https://github.com/umbraco/Umbraco-CMS">code</a>)</li>
      <li><a class="recom" href="https://webgen.gettalong.org/">webgen</a> (<a href="https://github.com/gettalong/webgen">code</a>)</li>
      <li><a href="http://werc.cat-v.org/">werc</a></li>
      <li><a class="recom" href="https://wordpress.org/">WordPress</a></li>
      <li><a class="recom" href="https://git.xmpp-it.net/sch/Rivista">XMPP Journal Publisher (XJP)</a></li>
      <li><a href="https://www.xwiki.org/">XWiki</a></li>
      <li><a href="https://github.com/jgm/yst">yst</a></li>
      <li><a href="https://www.getzola.org/">Zola</a></li>
    </ul>
    <h4>Forum Management</h4>
    <ul>
      <li><a href="https://askbot.com/">Askbot</a> (<a href="https://github.com/ASKBOT/askbot-devel">code</a>)</li>
      <li><a href="https://git.2f30.org/bliper/log.html">bliper</a></li>
      <li><a href="https://cblgh.org/cerca/">Cerca</a></li>
      <li><a href="https://www.discourse.org/">Discourse</a></li>
      <li><a href="https://djangobb.org/">DjangoBB</a></li>
      <li><a class="recom" href="https://www.elkarte.net/">ElkArte</a></li>
      <li><a class="recom" href="https://fluxbb.org/">FluxBB</a></li>
      <li><a href="https://invisioncommunity.com/">Invision Community (IP.Board)</a></li>
      <li><a href="https://www.mediawiki.org/wiki/MediaWiki">MediaWiki</a></li>
      <li><a class="recom" href="https://mybb.com/">MyBB</a></li>
      <li><a href="https://mylittleforum.net/">my little forum</a></li>
      <li><a href="https://nodebb.org/">NodeBB</a></li>
      <li><a href="https://camendesign.com/nononsense_forum">NoNonsense Forum</a> (<a href="https://github.com/Kroc/NoNonsenseForum">code</a>)</li>
      <li><a href="https://www.phorum.org/">Phorum</a></li>
      <li><a class="recom" href="https://www.phpbb.com/">phpBB</a></li>
      <li><a href="https://proboards.com/">ProBoards</a></li>
      <li><a href="https://punbb.informer.com/">PunBB</a></li>
      <li><a class="recom" href="https://www.redmine.org/">Redmine</a></li>
      <!-- li><a href="http://textboard.i2p/">SchemeBBS</a></li -->
      <!-- li><a href="https://wakaba.c3.cx/shii/shiichan">Shiichan Anonymous BBS</a></li -->
      <li><a href="https://simplemachines.org/">Simple Machines Forum</a></li>
      <!-- li><a href="https://syndie.de/">Syndie</a></li -->
      <li><a href="https://www.vbulletin.com/">vBulletin</a></li>
      <li><a href="https://xenforo.com/">XenForo</a></li>
    </ul>
    <h3>Webrings</h3>
    <p>Introduction to <a href="https://brisray.com/web/webring-history.htm">Webring History</a>.</p>
    <p>We advise you to bookmark the following links.</p>
    <p>Don't worry, there is more than enough for anyone for reading of contents and sharing of media; yes, even more than then you will be able to consume on the so called "social" platforms.</p>
    <ul>
      <li><a href="https://1mb.club/">1MB Club</a></li>
      <li><a href="https://250kb.club/">250KB Club</a></li>
      <li><a href="https://512kb.club/">512KB Club</a></li>
      <li><a href="https://blowfish.page/users/">Blowfish</a></li>
      <li><a href="https://xn--sr8hvo.ws/">An IndieWeb Webring</a></li>
      <li><a href="https://ring.exozy.me/">exozyme</a></li>
      <li><a href="https://heaventree.xyz/">Heaven Tree</a></li>
      <li><a href="https://hotlinewebring.club/">Hotline Webring</a></li>
      <li><a href="https://czar.kalli.st/webring/">->k- czar's</a></li>
      <li><a href="https://neocities.org/browse">Neocities</a></li>
      <li><a href="https://nocss.club/">No CSS Club</a></li>
      <li><a href="https://nownownow.com/">/now page</a></li>
      <li><a href="https://webring.adilene.net/members.php">Vocaloid Webring</a></li>
      <li><a href="https://xhtml.club/">XHTML Club</a></li>
      <li><a href="https://webring.xxiivv.com/#rss">XXIIVV Webring</a></li>
    </ul>
    <p>Get into the Web Ring.</p>
    <span id="webring">🕸 💍</span>
  </div>
  <span class="decor"></span>
  <div id="searx" class="segment">
    <h1>👁️ Monitoring Online Presence And Facilitating SEO</h1>
    <h2>Power Tools That Advertisers Don't Want You To Use</h2>
    <div class="content">
      <p>Advertising and marketing agencies make an extensive use of syndication feeds to monitor information presented by search results and other trends.  Many of them use SearXNG to do this task.</p>
      <p>SearXNG and YaCy are private and decentralized engines that retrieve results from multiple sources, including commercial search engines, RSS feeds and also from shared peers using the DHT technology.</p>
      <p>Results are provided in both HTML and <b class="text-icon orange">RSS</b>, including CSV and JSON.</p>
      <p>While SearXNG retrieves results only from live search engines, YaCy provides results from both local database (i.e. bookmarks) and other YaCy peers, in addition to live search engines.</p>
      <h3>Marginalia</h3>
      <p>Marginalia Search a small independent do-it-yourself search engine for surprising but content-rich sites that never ask you to accept cookies or subscribe to newsletters.</p>
      <ul>
        <li><a href="https://search.marginalia.nu/">Homepage</a></li>
        <li><a href="https://git.marginalia.nu/">Source code</a></li>
      </ul>
      <h3>MetaGer</h3>
      <p>MetaGer has been free software under GNU AGPL v3 since August 16, 2016, so that our strict protection of your data and your privacy can be publicly verified and so that you as a programmer can help to make everything even better.</p>
      <ul>
        <li><a href="https://gitlab.metager.de/open-source/MetaGer">Homepage</a></li>
        <li><a href="https://metager.de/">Source code</a></li>
      </ul>
      <h3>SearXNG (RSS Supported)</h3>
      <p>SearXNG is a meta-search engine, aggregating the results of other search engines while not storing information about its clients.</p>
      <ul>
        <li><a href="https://searx.space/">Homepage</a></li>
        <li><a href="https://github.com/searxng/searxng">Source code</a></li>
      </ul>
      <h3>Wiby</h3>
      <p>Wiby is a search engine and the source code is now free as of July 8, 2022.</p>
      <ul>
        <li><a href="https://wiby.me/">Homepage</a></li>
        <li><a href="https://github.com/wibyweb/wiby">Source code</a></li>
      </ul>
      <h3>YaCy (P2P and RSS Supported)</h3>
      <p>Imagine if, rather than relying on the proprietary software of a large professional search engine operator, your search engine was run across many private devices, not under the control of any one company or individual. Well, that's what YaCy does!</p>
      <ul>
        <li><a href="https://yacy.net/">Homepage</a></li>
        <li><a href="https://github.com/yacy/yacy_search_server">Source code</a></li>
      </ul>
    </div>
  </div>
  <span class="decor"></span>
  <div id="services-feed" class="segment">
    <h1>🛎️ Your RSS Is Kindly Served, Sir!</h1>
    <h2>Because No One Should Nor Would Stop You From Being In Control Of Your Precious Time</h2>
    <div class="content">
      <p>Below are online services that extend the syndication experience by means of bookmarking and multimedia, and also enhance it by restoring access to news syndication feeds.</p>
      <!-- h3><a href="https://teddit.net/">teddit</a></h3>
      <p>Turn /r/ into syndication feeds. (<a href="https://github.com/libreddit/libreddit">source code</a>)</p -->
      <h3><a href="http://blogmarks.net/">BlogMarks</a></h3>
      <p>Welcome to the social bookmarking revolution. BlogMarks is a social bookmarking service, which was founded in late 2003.</p>
      <p>BlogMarks is a collaborative link management project based on sharing and key-word tagging. Build on a blog basis, BlogMarks is an open and free technology. Now, you can access your favorite URL's from any computer. And with BlogMarks, you share your favourite with other people, friends and family.</p>
      <p class="background">⚠️ Invitation only membership.</p>
      <p>Please refer to <a href="https://notado.app/">Notado</a> in case you don't know from where to get an invitation.</p>
      <h3><a href="https://drummer.land/">Drummer</a></h3>
      <p>Drummer is a multi-tab outliner that runs as a browser app and as a Mac desktop app.</p>
      <h3><a href="https://github.com/jonschoning/espial">Espial</a></h3>
      <p>Espial is an open-source, HTML-based bookmarking server with support for sharing feeds as RSS.</p>
      <h3><a href="https://feedcontrol.fivefilters.org/">Feed Control</a></h3>
      <p>Monitor feeds and HTML pages, filter content, receive alerts, expand partial feeds, and integrate with your app.</p>
      <h3><a href="https://www.fivefilters.org/feed-creator/">Feed Creator</a></h3>
      <p>Create feeds from HTML pages. Generate RSS and JSON feeds from a set of links or other HTML elements.</p>
      <h3><a href="https://feedland.org/">FeedLand</a></h3>
      <p>FeedLand is a place to share and discover feeds.</p>
      <h3><a href="https://feedmail.org/">FeedMail</a></h3>
      <p>FeedMail sends you updates from your favourite sites directly to your inbox.</p>
      <h3><a href="https://feedsin.space/">feedsin.space</a></h3>
      <p>This is a tool you can use to get RSS feeds into the fediverse. You can use it to create an account which will post a new entry any time there's a new entry in the feed.</p>
      <h3><a href="https://www.fivefilters.org/full-text-rss/">Full-Text RSS</a></h3>
      <p>Easy article extraction. Extract the full article content from an HTML page or a summary-only RSS feed.</p>
      <h3><a href="https://blog.miso.town/">HTML Blog to Atom</a></h3>
      <p>Do you have a blog.html page on your site? Or a section on your homepage where you list posts? Structure it the following way to make it an HTML Blog and let anyone <a href="https://blog.miso.town/blog-to-atom">subscribe to it with an atom feed</a>.</p>
      <h3><a href="https://journal.miso.town/">HTML Journal to Atom</a></h3>
      <p>Do you have a journal.html page on your site? Or a section on your homepage where you give updates? Structure it the following way to make it an HTML Journal and let anyone <a href="https://journal.miso.town/journal-to-atom">subscribe to it with an atom feed</a>.</p>
      <h3><a href="https://invidious.io/">Invidious</a></h3>
      <p>Turn video channels into Atom feeds. (<a href="https://gitea.invidious.io/iv-org/invidious">source code</a>)</p>
      <h3><a href="https://kill-the-newsletter.com/">Kill the Newsletter!</a></h3>
      <p>Convert email newsletters into syndication feeds. (<a href="https://github.com/leafac/kill-the-newsletter">source code</a>)</p>
      <h3><a href="https://lbry.vern.cc/">Librarian</a></h3>
      <p>Turn Odysee channels into RSS feeds. (<a href="https://codeberg.org/librarian/librarian">source code</a>)</p>
      <!-- h3><a href="https://libreddit.no-logs.com/">libreddit</a></h3>
      <p>Turn /r/ into syndication feeds. (<a href="https://github.com/libreddit/libreddit">source code</a>)</p -->
      <h3><a href="https://github.com/zedeus/nitter/wiki/Instances">Nitter</a></h3>
      <p>Turn tweets into RSS feeds. (<a href="https://github.com/zedeus/nitter">source code</a>)</p>
      <h3><a href="https://notado.app/">Notado</a></h3>
      <p>Content-first Bookmarking. Create smart feeds that are automatically populated by your tagged notes.</p>
      <h3><a href="https://openrss.org/">Open RSS</a></h3>
      <p>Open RSS is a nonprofit organization that provides free RSS feeds for sites and applications that don't already provide them, so RSS feeds can continue to be a reliable way for people to stay up-to-date with content anywhere on the internet.</p>
      <h3><a href="https://codeberg.org/ThePenguinDev/Proxigram/wiki/Instances">Proxigram</a></h3>
      <p>Turn stories into RSS feeds. (<a href="https://codeberg.org/ThePenguinDev/Proxigram">source code</a>)</p>
      <h3><a href="https://github.com/pablouser1/ProxiTok/wiki/Public-instances">ProxiTok</a></h3>
      <p>Turn videos into RSS feeds. (<a href="https://github.com/pablouser1/ProxiTok">source code</a>)</p>
      <h3><a href="https://rss.app/rss-feed">RSS.app</a></h3>
      <p>Create RSS Feeds from <i>almost</i> any page.</p>
      <h3><a href="https://rss-bridge.org/bridge01/">RSS Bridge</a></h3>
      <p>RSS-Bridge is free and open source software for generating Atom or RSS feeds from sites which don’t have one. It is written in PHP and intended to run on a server. (<a href="https://github.com/RSS-Bridge/rss-bridge">source code</a>)</p>
      <h3><a href="https://docs.rsshub.app/">RSSHub</a></h3>
      <p>RSSHub is an open source, easy to use, and extensible RSS feed generator. It's capable of generating RSS feeds from pretty much everything. (<a href="https://github.com/DIYgod/RSSHub">source code</a>)</p>
      <h3><a href="https://rsserpent-rev.github.io/RSSerpent/latest/">RSSerpent</a></h3>
      <p>RSSerpent is an open-source software that creates RSS feeds for websites without them. (<a href="https://github.com/RSSerpent-Rev/RSSerpent">source code</a>)</p>
      <h3><a href="https://recommend.shinobi.jp/">忍者画像RSS (旧:忍者レコメンド)</a></h3>
      <p>画像付きRSSブログパーツ【忍者画像RSS (旧:忍者レコメンド)】は、</p>
      <p>閲覧回数（PV）を上げ、忍者あんてなからのアクセスが</p>
      <p>期待できる画像付きのブログパーツです。</p>
    </div>
  </div>
  <span class="decor"></span>
  <div id="learn" class="segment">
  <h1>🗓 History They Don't Want You To Know About</h1>
  <h2>Learn More About Standards And Syndication Technology</h2>
  <div class="content">
    <p>This is a short history and reference guide to syndication feeds.</p>
    <p>It is an essential learning that will expose to you the technologies that are vigorously being suppressed and concealed from us for over 20 years.</p>
    <h3>2018: ActivityPub</h3>
    <p>The ActivityPub protocol is a decentralized social networking protocol based upon the [ActivityStreams] 2.0 data format. It provides a client to server functionality for creating, updating and deleting content, as well as a federated server to server API for delivering notifications and content. <a href="https://activitypub.rocks/">Continue reading…</a></p>
    <h3>2017: RSS-in-JSON</h3>
    <p>RSS-in-JSON feed format is simply an RSS 2.0 feed that uses JSON syntax in place of XML. <a href="https://github.com/scripting/Scripting-News/tree/master/rss-in-json">Continue reading…</a></p>
    <h3>2017: JSON Feed</h3>
    <p>The JSON Feed format is a pragmatic syndication format, like RSS and Atom, but with one big difference: it’s JSON instead of XML. <a href="https://www.jsonfeed.org/version/1.1/">Continue reading…</a></p>
    <h3>2008: Activity Streams</h3>
    <p>An extension to the Atom feed format to express what people are doing. The stream in ActivityStreams is a feed of related activities for a given person or social object.
 <a href="https://wiki.activitystrea.ms/w/page/1359261/FrontPage">Continue reading…</a></p>
    <h3>2006: h-entry and hAtom 0.1</h3>
    <p>h-entry is a simple, open format for episodic or datestamped content. h-entry is often used with content intended to be syndicated, e.g. blog posts. h-entry is one of several open microformat standards suitable for embedding data in HTML. <a href="http://microformats.org/wiki/h-entry">Continue reading…</a></p>
    <h3>2005: Atom Over XMPP</h3>
    <p>Presented to the public at the IETF 66 by Peter Saint-Andre of the Jabber Software Foundation, Atom Over XMPP allows to publish Atom Syndication feeds into PubSub (XEP-0060: Publish-Subscribe) nodes which has an additional advantage of forming Atom Syndication feeds into push notifications, which significantly saves bandwidth on all sides. Atom Over XMPP is extensively used by the XMPP platforms <a href="https://libervia.org/">Libervia</a> and <a href="https://movim.eu/">Movim</a> to store and share information <a href="https://datatracker.ietf.org/meeting/66/materials/slides-66-atompub-1.pdf">Continue reading…</a></p>
    <h3>2003: Atom and AtomPub</h3>
    <p>Atom is the name of an XML-based content and metadata syndication format, and an application-level protocol for publishing and editing resources belonging to periodically updated sites. <a href="https://web.archive.org/web/20120105062737if_/http://www.atomenabled.org:80/developers/syndication/#whatIsAtom">Continue reading…</a></p>
    <h3>2000: OPML</h3>
    <p>OPML is a text-based format designed to store and exchange outlines with attributes. It has been around since the early 2000s, and is widely used in the RSS world to exchange subscription lists. It is an established standard for interop among outliners. <a href="http://scripting.com/davenet/2000/09/24/opml10.html">Continue reading…</a></p>
    <h3>1999: RSS</h3>
    <p>RSS is a content syndication format. Its name is an acronym for Really Simple Syndication. RSS is a dialect of XML. <a href="https://www.rssboard.org/rss-specification#whatIsRss">Continue reading…</a></p>
    <h3>1998: XSL and XSLT</h3>
    <p>XSL (Extensible Stylesheet Language) is designed for use as part of XSLT, which is a stylesheet language for XML that has document manipulation capabilities beyond styling. <a href="http://xml.coverpages.org/xsl.html">Continue reading…</a></p>
  </div>
  </div>
  <span class="decor"></span>
  <div id="xslt" class="segment">
  <h1>🏆 About XSLT</h1>
  <h2>📃️ XSL (Extensible Stylesheet Language)</h2>
  <div class="content">
    <p>XSL is designed for use as part of XSLT, which is a stylesheet language for XML that has document manipulation capabilities beyond styling.</p>
    <ul>
     <li>Files follow the structure of XML syntax.</li>
     <li>Files are processed on client-side, thus can be embedded into HTML page.</li>
     <li>The more visitors a site gets, the more bandwidth the server would require.</li>
     <li>Because XSLT is processed on client-side, no further computer power would be required.</li>
     <li>Standard output types are HTML, PDF and XML.</li>
     <li>Cheap and simple to maintain.</li>
    </ul>
  </div>
  <h2>📜 In Comparison To JavaScript</h2>
  <div class="content">
    <p>JavaScript is a scripting language which in most cases is running inside browsers or servers and its main usage is to manipulate pages, it is used for generating interactive sites.</p>
    <ul>
     <li>JavaScript API makes it simple to steal personal data and information from visitors.</li>
     <li>Files can be processed on both client-side and server-side.</li>
     <li>JavaScript is insecure by design and dangerous to use.</li>
     <li>The more visitors a site gets, the more bandwidth the server would require.</li>
     <li>The more visitors a site gets, the more computer power the server would require, provided JavaScript also runs on the server.</li>
     <li>Dynamic JavaScript sites are prone to experience security issues.</li>
     <li>JavaScript is seriously abused. Much of the publicly available code, especially those in commonly used libraries, are very badly written. The code is abused to a level that the people who visit sites, suffer from it in terms of performance, longer time wait and shorter battery time span.</li>
     <li>Because the use of object prototypes is so poorly understood by most JavaScript developers, they abuse the language and write horrible code as a result.</li>
     <li>As a result of all of the above, JavaScript is very expenssive to maintain in an efficient fashion.</li>
     <li>Due to that issue and other issues with HTTP, a new project called Gemini has formed as a contemporary protocol to Gopher.</li>
    </ul>
  </div>
  <h2>🐘 In Comparison To PHP</h2>
  <div class="content">
    <p>PHP is a scripting language which in most cases is running on servers and its main usage is to process pages, it is also used for generating interactive sites.</p>
    <ul>
     <li>Files follow the structure of HTML syntax.</li>
     <li>Files are processed only on server-side, thus can not be embedded into HTML page.</li>
     <li>The more visitors a site gets, the more bandwidth the server would require.</li>
     <li>The more visitors a site gets, the more computer power the server would require.</li>
     <li>Expenssive and complex to maintain.</li>
    </ul>
  </div>
  </div>
  <span class="decor"></span>
  <div id="plea" class="segment">
    <h1>✒️ An Appeal From The Author</h1>
    <!-- h2>A Public Message Announcement</h2 -->
    <h2>Because even a Jew lawyer knows why syndication feeds are important!</h2>
    <!-- h2>Because even the people of Faroe Islands and Gabon know what syndication feeds are and how important they are!</h2 -->
    <div class="content">
      <p>Greetings,</p>
      <p>My name is Schimon Jehudah, I’m an Attorney at Law and Crypto Analyst, and author of StreamBurner News Reader (also “Newspaper” Userscript).</p>
      <p>For many years, the technology commonly referred to as "RSS" has been serving me and the companies I’ve been working with (namely, financial houses and law firms) in both corporate and individual life.</p>
      <p>Since its inception, advertising and media companies have been working together to eliminate this technology; mostly, by paying off software companies (namely, browser vendors) as well as sites to ignore, neglect and even remove support for this technology.</p>
      <p>This vital technology, which exists for over 20 years, is being oppressed for over a decade, particularly by advertising companies, news publishers, western governments and data mining sites (aka “social networks”) who want to turn more control of data flow to them and much less control to individuals, like you.</p>
      <p>I advise you to share this technology with your family, friends and any acquaintance of yours, and boycott news outlets that refuse to provide syndication feeds.</p>
      <p><b><i>I <u>don’t</u> ask you for financial support nor monetary donations;</i></b></p>
      <p><b><i>I only ask YOU to share this technology with people you know.</i></b></p>
      <p>Respectfully,</p>
      <p>Schimon</p>
    </div>
    <hr/>
    <div id="postscript">
      <h3>Postscript</h3>
      <div class="content">
        <p>This software was made by a professional corporate and criminal Lawyer who has been practicing the legal field for over a decade, and has no “formal” technical trainings nor technical qualifications, so-called, neither in CSS, ECMA (JavaScript), HTML nor XSLT technologies.</p>
        <p>Since a Lawyer can make this software from scratch in 28 days (4 hours each day), then ask yourselves “Why do browser vendors look for excuses to actively ignore this important technology?” (if not because of payoffs).</p>
      </div>
      <h3>Of Note</h3>
      <div class="content">
        <p>If your <a href="#shame" class="link">browser</a> does not ship with feed support pre-installed, then you are advise to <a href="#alternative" class="link">replace</a> your browser.</p>
        <p>StreamBurner project and source code can be found at <a href="https://gitgud.io/sjehuda/streamburner">GitGud.io</a> and Newspaper source code at <a href="https://greasyfork.org/en/scripts/465932-newspaper">Greasy Fork</a> and <a href="https://openuserjs.org/scripts/sjehuda/Newspaper">OpenUserJS</a>.</p>
      </div>
    </div>
  </div>
  <span class="decor"></span>
    <div id="matter" class="segment">
    <h1>Syndication <span class="text-icon orange">Feeds</span> Are Important</h1>
    <h2>Factors That Make Syndication Feeds Very And Mostly Important</h2>
    <h3>♿ Accessibility</h3>
    <h4>One Of The Main Arguments For Syndication Feeds Is Accessibility For The Blind And The Visually Impaired</h4>
    <p>With syndication feeds and particularly <span class="text-icon orange">Atom</span>, as a standard format, all may enjoy a consistent fashion of content delivery and consumption across multiple sites.</p>
    <p>And it includes the blind and the visually impaired, without having to be bound to specific apps or services that don't opperate in the same manner nor display contents in the same manner of similar services, which would always make it difficult and even impossible to communicate with, to those who are subjected to the need of different and special means of accessibility.</p>
    <p>Syndication feeds make everyone equally communicated and no one is left behind; yet ignoring, suppressing and even actively discouraging syndication feeds would only leave the blind and the visually impaired excommunicated.</p>
    <p>If accessibility is a human right, then syndication feeds must be so too.</p>
    <h3>😊 Mental Health</h3>
    <h4>Using Syndication Feeds Is Better For Your Mental Health</h4>
    <p>Studies show that the ways we consume content today—especially when on social media sites—can negatively impact our lives and be significantly detrimental to our mental health. It's been linked to increased anxiety, depression, sleep disruption, and anti-social behavior.</p>
    <p>And while syndication feeds don't eliminate these risks entirely, consuming news and social media content through syndication feeds, instead of through sites and apps directly, can combat some of these negative effects. <a href="https://openrss.org/blog/rss-feeds-may-be-better-for-your-mental-health">Continue reading…</a></p>
    <p><a href="https://stallman.org/facebook.html">More about cons of social media.</a></p>
    <h3>🧠 Free Your Mind</h3>
    <h4>Because With Syndication Feeds You Are Not Easily Manipulated Nor Distracted</h4>
    <p>Since syndication feeds are structured formats (and Atom being the standard format for syndication feeds), you are completely in control of the data you consume, without being subjected to distractions, targeted advertising and manipulations of sorts.</p>
    <p>You are also in control of the appearance and fashion that content is being delivered to you, unlike dynamic pages.</p>
    <p>And if you don't like certain content you see, all you need to do is disable or delete the source feed from which that content resulted from. That's it!</p>
    <h3>📶 Bandwidth Efficient</h3>
    <h4>Feeds Mean Getting Data And Getting It Fast</h4>
    <p>Feeds is basically an XML based text file that weight less than 10KB on average, meaning that scanning 1000 feeds would only cost you 10MB.</p>
    <p>Read more about how to make syndication feeds even more efficient over HTTP at <a href="https://www.ctrl.blog/entry/feed-caching.html">Ctrl.blog</a> (See <a href="https://datatracker.ietf.org/meeting/66/materials/slides-66-atompub-1.pdf">Atom Over XMPP</a> for communicating over XMPP).</p>
    <h3>🪲 We Are Not Bugs</h3>
    <h4>Commercial Content Publishers Hate Syndication Feeds Because They Can't Engage In User Tracking With It</h4>
    <p>Syndication feeds are just text with some bits attached, such as MP3 files for podcasts. There's no JavaScript or any of the fancy stuff for tracking you, just an IP address. And if you go through an aggregator there isn't even that.</p>
    <p>They absolutely hate that. They'd much prefer if you used their sites or apps, where they can study you like a bug. (<a href="https://farside.link/redlib/r/apple/comments/4xx1gv/apple_news_no_longer_supports_rss_feeds/d6jo3g9/#c">source</a>)</p>
    <h3>🫵 You And Your Power</h3>
    <h4>If You Want To, You Have The Power To Make Any Difference You Want</h4>
    <p>You are advised not to participate in the miserable and unfortunate charade of publishers and browser vendors to excommunicate blind people, visually impaired people and people with other disabilities to whom syndication feeds are either their only or most useful fashion to get news and updates.</p>
    <p>Take into your attention that some of the uses of syndication feeds for the disabled are merely for the sake of their lives (e.g. Emergency S.O.S. Unit).</p>
    <p>When we cut our syndication feeds from them, we might cut our their lives, literally.</p>
    <p>Join our endeavor to restore and promote syndication feeds.</p>
  </div>
  <span class="decor"></span>
  <div id="shame" class="segment">
    <h1>🏢️ Meet The Mind Subverters</h1>
    <!-- h1>👎 Hall of Shame</h1 -->
    <h2>Discover Who Are Those Whom Want To Suppress Syndication Feeds And The Technology Behind It</h2>
    <p>Below is a list of brands of products and services with userbase of over 100K, and who used to provide access to syndication feeds in the past.</p>
    <p>The companies responsible for the following brands, pretend to be competitors when they are really cooperating and working together against progress, against people, against free flow of information, and even against their own clients.</p>
    <p>
        <h3>#1 Mozilla</h3>
        <h4>Playing the role of the selected (i.e. controlled) opposition of the internet since 1998</h4>
        <p>Mozilla is a brand unofficially owned and controlled by Google Inc. In other words, Mozilla is Google's plaything and marketing toy. It always has been and it always will be, as long as it pays the rent.</p>
      <ul>
        <li><a href="https://openrss.org/blog/browsers-should-bring-back-the-rss-button">Browsers removed the RSS Button and they should bring it back</a> (May 30, 2023)</li>
        <li><a href="https://techdows.com/2018/10/mozilla-removes-rss-live-bookmarks-support-from-firefox-64.html">Mozilla removes RSS feed and Live Bookmarks support from Firefox 64</a> (October 12, 2018)</li>
        <li><a href="https://www.zdnet.com/article/end-nears-for-rss-firefox-64-to-drop-built-in-support-for-rss-atom-feeds-says-mozilla/">Firefox 64 to drop built-in support for RSS, Atom feeds, says Mozilla</a> (October 15, 2018)</li>
        <li><a href="https://www.bleepingcomputer.com/news/software/mozilla-to-remove-support-for-built-in-feed-reader-from-firefox/">Mozilla to Remove Support for Built-In Feed Reader From Firefox</a> (July 26, 2018)</li>
        <li><a href="https://www.ghacks.net/2018/07/25/mozilla-plans-to-remove-rss-feed-reader-and-live-bookmarks-support-from-firefox/">Mozilla plans to remove RSS feed reader and Live Bookmarks support from Firefox</a> (July 25, 2018)</li>
        <li><a href="https://camendesign.com/blog/rss_is_dying">RSS Is Dying, and You Should Be Very Worried</a> (January 3, 2011)</li>
      </ul>
    </p>
    <p>
        <h3>#2 Google</h3>
        <h4>Be As I Preach, Not As I Am</h4>
        <p>Google once had <a href="https://www.chromium.org/user-experience/feed-subscriptions/">a built-in RSS button</a> in the Google Chrome browser for desktop and in the source code of Chromium, the browser from which it's based.</p>
        <p>However, the company has since removed the feature from the browser and no reason was given for its removal.</p>
      <ul>
        <li><a href="https://www.jwz.org/xscreensaver/google.html">XScreenSaver: Google Store Privacy Policy</a> (Unlike Google,...)</li>
        <li><a href="https://www.jwz.org/blog/2024/06/your-personal-information-is-very-important-to-us/">"Your personal information is very important to us."</a> (June 8, 2024)</li>
        <li><a href="https://openrss.org/blog/browsers-should-bring-back-the-rss-button">Browsers removed the RSS Button and they should bring it back</a> (May 30, 2023)</li>
        <li><a href="https://www.theverge.com/2021/10/8/22716813/google-chrome-follow-button-rss-reader">Google Reader is still defunct, but now you can ‘follow’ RSS feeds in Chrome on Android</a> (October 8, 2021)</li>
        <li><a href="https://web.archive.org/web/20201108022203/https://support.google.com/googleplay/android-developer/answer/10177647">Developer Program Policy (To Silently Limit And Ban RSS Apps Using Falsified Premises)</a> (October 21, 2020)</li>
      </ul>
    </p>
    <p>
        <h3>#3 Apple</h3>
        <!-- h3>Shiny Products With No Meaningful Functionality</h3 -->
        <h4>Nonfunctional Shiny Products</h4>
        <p>Apple's Safari browser once showed a feed "Reader" button in the address bar for any page that had a feed available. Clicking that button opened the feed in your chosen feed reader application or Safari by default.</p>
        <p>On July 2012, the feature disappeared with no explanation from Apple on why it was removed. And despite <a href="https://archive.ph/ZYfP5">many complaints and requests to bring it back</a>, Apple refuses to restore it.</p>
      <ul>
        <li><a href="https://openrss.org/blog/browsers-should-bring-back-the-rss-button">Browsers removed the RSS Button and they should bring it back</a> (May 30, 2023)</li>
        <li><a href="https://mjtsai.com/blog/2019/12/26/apple-news-no-longer-supports-rss/">Apple News No Longer Supports RSS</a> (December 26, 2019)</li>
        <li><a href="https://www.imore.com/what-happened-rss-subscriptions-safari-ios-11">What happened to RSS subscriptions on Safari on iPhone?</a> (September 8, 2018)</li>
        <li><a href="https://farside.link/redlib/r/apple/comments/4xx1gv/apple_news_no_longer_supports_rss_feeds/">Apple News no longer supports RSS feeds</a> (August 16, 2016)</li>
        <li><a href="https://www.macobserver.com/tmo/article/apples_safari_6_rss_blunder">Apple’s Safari 6 RSS Blunder</a> (August 8, 2012)</li>
      </ul>
    </p>
    <p>
        <h3>#4 Microsoft</h3>
        <h4>We Are Just Good At Marketing</h4>
        <p>Microsoft's Internet Explorer (now called Edge) once had a feed subscribe button that displayed prominently when visiting a site that had a feed.</p>
        <p>After clicking the RSS button, it even showed you a helpful page allowing you to subscribe and manage the feed, all without leaving the browser.</p>
        <p>Over time, the button got removed without warning.</p>
      <ul>
        <li><a href="https://openrss.org/blog/browsers-should-bring-back-the-rss-button">Browsers removed the RSS Button and they should bring it back</a> (May 30, 2023)</li>
        <li><a href="https://www.bleepingcomputer.com/news/microsoft/microsoft-adds-new-rss-feed-for-security-update-notifications/">Microsoft adds new RSS feed for security update notifications</a> (October 12, 2022)</li>
      </ul>
    </p>
    <h3>🎞️ Live Bookmarks Is A Smart Feature</h3>
    <h4>They aren’t saying RSS is dead, they’re just actively removing support for it</h4>
    <p>Seems to be a way to ensure that usage keeps on decreasing.</p>
    <p>Live bookmarks is a smart feature. It allows you to see a whole range of sites and articles at a glance. I use it heavily.</p>
    <p>This is a continued phony “progress” in browsers. (<a href="https://techdows.com/2018/10/mozilla-removes-rss-live-bookmarks-support-from-firefox-64.html#comment-171769">source</a>)</p>
    <h3>🪲 We Are Not Bugs</h3>
    <h4>Commercial Content Publishers Hate RSS Because They Can't Engage In User Tracking With It</h4>
    <p>RSS feeds are just text with some bits attached, such as MP3 files for podcasts. There's no JavaScript or any of the fancy stuff for tracking you, just an IP address. And if you go through an aggregator there isn't even that.</p>
    <p>They absolutely hate that. They'd much prefer if you used their sites or apps, where they can study you like a bug. (<a href="https://farside.link/redlib/r/apple/comments/4xx1gv/apple_news_no_longer_supports_rss_feeds/d6jo3g9/#c">source</a>)</p>
    <span class="decor"></span>
    <h3>🏛️ Cartelization</h3>
    <h4>Does This Reminiscing Price Fixing To You?</h4>
    <p>If you already figured it would be worth to call to an Antitrust Division or Competition Commission, that could have be a good idea, if the government wasn't involved.</p>
    <p>In case you have wondered… Yes, this is a coordinated effort of corporations, intelligence agencies, publishing platforms and governments to suppress RSS.</p>
    <span class="decor"></span>
    <h3>🎭 Bad Criminals Go To Jail, Good Criminals Go To Parliament</h3>
    <h4>The Government Is A Problem, Not A Solution.</h4>
    <p>History shows that governments and unions are always confounded to fail as people with great wealth and special interest will eventually find their way into public offices, be it by bribing, lobbying or actually sending puppets of their own to take a sit.</p>
    <span class="decor"></span>
    <h3>🚫 Boycott</h3>
    <h4>The Only Solution Is Boycott</h4>
    <i>"The economic boycott is our means of self-defense." --Samuel Untermyer</i>
    <p>As a Jew, I can confidently state that boycott has been proven to be a successful, albeit ignoble, practice mean which has been adopted extensively by Jews and Zionists since the 19th century and has proven to be effective; I advise you to do the same.</p>
    <p>Boycott all platforms and corporations that refuse or fail to provide a proper and easy access to syndication feeds.</p>
    <h3>〽️ Alternatives</h3>
    <h4>There Are Always Quality Alternatives</h4>
    <p>Please refer to <a href="#alternative" class="link">alternative browsers</a>.</p>
    <!-- p>There are always quality alternatives.</p -->
  </div>
  <span class="decor"></span>
  <div id="mozilla" class="segment">
    <h1><span class="lizard">🦎</span> Red Lizard Assault On Syndication Feeds And Followed Spasms On XSLT Technologies</h1>
    <h2>Because Playing The Controlled Opposition Role Can Never Be Ridiculous More Than Enough</h2>
    <p>Not for nothing it was one of the first pioneers to adopt syndication feeds and the first one to drop it.</p>
    <p>This is a story about a multibillion organization that has made a joke out of itself by deliberately plotting and conniving against a graphical component as small as 16x16 pixels.</p>
    <span class="decor"></span>
    <h3>Syndication Feeds</h3>
    <h4>Upcoming Changes As A Public Affair</h4>
    <p>During 2010, the company refers itself by the brand "Mozilla Foundation" (the company) has made a public display (i.e. phony public suggestion and mindstorm, so called) that proposed an idiotic and impossible notion that any individual is eligible to participate in proposing changes to its products, such as "Firefox" version 3.</p>
    <p>To make that public display convincing, the company has made a "heatmap" page that displayed a new UI of "Firefox" against colorful numbers and figures, in order to make people to believe that the company is honest and "transparent" so called.</p>
    <p>That public heatmap show and display took place for less than just a month. That's it!</p>
    <p>It is important to note that the heatmap had first accounted for 7% - 15% of activity for the feed button and a week afterwords, it accounted for only 3% - 5% and then the heatmap results have been suddenly froze.</p>
    <p>It is very likely that the heatmap was frozen because the statistics, albeit probably forged, were convenient to the company.</p>
    <p>Finally, the company has replaced the feed button by a feed menu item, and whilst:</p>
    <ul>
      <li>The button included a visual and active indicator and took 2 - 3 clicks to get into syndication feeds;</li>
      <li>The new menu item had no automated indication, which requires to manually open the Bookmarks menu to check whether or not a feed is available;</li>
    </ul>
      <p>This task took 3 - 4 clicks and further mouse cursor move to get into syndication feeds;</p>
      <p>The menu item has made syndication feeds unemployable because, unlike the feed button which provided a visual indicator for auto-discovered feeds, people had to actively check whether or not a feed is available, which they would find out only after opening the Bookmarks menu;</p>
      <p class="cyan">This change has distorted the desired functionality for automation.</p>
      <p>This change has made people to allocate the <a href="https://www.rssboard.org/rss-autodiscovery">feed auto-discovery task</a> to desktop Feed Readers, which not all people in the future be familiar with because they would be lesser familiar with the Feed icon due to it concealment.</p>
    <p>Whether you are a software engineer or not, this is simple to understand that this is not an improvement in UI. It is the complete opposite of improvement.</p>
    <span class="decor"></span>
    <h4>Complete Removal Of Syndication Feeds</h4>
    <p>On December 2018, the company has stated that the built-in feed reader was removed from a software browser branded as "Firefox" due to security concerns which were never proven. The statement is as follows:</p>
    <p class="quote">"After reviewing the usage data and technical maintenance requirements for these features and taking into account alternative Atom/RSS feed readers already available to you, we have realized that these features have an outsized maintenance and security impact relative to their usage. Removing the feed reader and Live Bookmarks allows us to focus on features that make a greater impact." (<a href="https://support.mozilla.org/en-US/kb/feed-reader-replacements-firefox" rel="noreferrer">source</a>)</p>
    <p>At the same moment, the company introduced a new built-in element called "Pocket" which connects to a centralized data mining platform referred to by the same name and is publicly presented as a news and content aggregating service; in reality, it is a centralized closed-source platform, not supporting interoperability, privacy unfriendly, and is subjected to potential massive data leaks which are both a privacy and a security concern.</p>
    <span class="decor"></span>
    <h4>Heatmap And Karma: Hitting At 3% And Getting 3% In Return</h4>
    <!-- p class="cyan">This is a story about a man who was deliberately hitting at 3% and the lord has returned 3%.</p -->
    <p>In the "Firefox Main Window Heatmap" so called, "Based on over 117,000 Windows 7 and Vista Test Pilot submissions from 7 days in July 2010" Mozilla has determined that the RSS (i.e. feed) button has less than 3% of use.</p>
    <p>The following is an excerpt from the heatmap:</p>
    <ul>
      <li>RSS</li>
      <li>Used by 3% of beta users, with an average of 0.05 clicks per user.</li>
      <li>Adv. 5% Int. 4% Beg. 3%</li>
    </ul>
    <p>It means nothing and constitutes no indication whatsoever, and this heatmap is biased from start to finish.</p>
    <p>Here are some reasons:</p>
    <ol>
      <li>This given data may be arbitrarily forged.</li>
      <li>Why was the earlier heatmap with 7% - 15% was ignored and overridden?</li>
      <li> Was this postpone intentional and deliberate in order to make feeds to look lesser popular?</li>
      <li>In what manner Advanced (Adv.) and Intermediate (Int.) users were counted, because most of them usually opt-out from data sharing of all kinds, even in "beta" releases.</li>
      <li>How can one determine who is to be regarded as Advanced (Adv.), Intermediate (Int.) or Beginner (Beg.)?</li>
      <li>Why Linux and other UNIX-based systems, which have the most Advanced (Adv.) and Intermediate (Int.) users, were excluded?</li>
      <li>Why were "beta users" a premier indicator, let alone Beginners (Beg.), especially when RSS was not amongst the new features that would require testing by "beta" testers?</li>
      <li>The heatmap includes number of (finger) clicks, but it doesn't include number of eye gazes, which is also an indicator.</li>
      <li>Eyes and vision, albeit unmeasurable, are also part of the matter of UX.</li>
      <li>
        <p>The 3% indication might also mean that most people, like the author of this RSS software, <i>do</i> make an extensive use of syndication feeds, but they don't need to click that button over and over, because:</p>
        <ul>
          <li>The visual indicator (feature) for the persence of RSS is just as important in and on itself.</li>
          <li>
            <p>"Click once, and get lifetime updates." That is the main point of syndication feeds!</p>
            <p>Once you are subscribed to a syndication feed with a feed reader that would <i>automatically</i> notify you for changes and new items, then you obviously don't need to press that icon again, because automation is what syndication feeds were made for.</p>
            <p>In other words, by the nature of syndication feeds, it is not meant to be clicked oftentimes.</p>
            <p>Hence equally comparison the RSS button against other components and ruthlessly setting the rate to 3% out of 100% just like other components (e.g. back and forward buttons) make no sense.</p>
            <p>The fact that a tiny screw in an airplane isn't used at all times or at least at the same rate as a chair or a wheel, does not mean that the screw isn't important for the airplane to operate as expected and to provide a best flying experience.</p>
          </li>
        </ul>
      </li>
    </ol>
    <p class="cyan">The purpose of the RSS icon is to <b>reduce</b> the amount of clicks by solely using the visual appearance of it. Therefore this "test" was rigged and misleading by misusing an argument which does not belong to the subject matter!</p>
    <p class="cyan">The percentage representation of the aforementioned icon, which size may vary between 16x16 to 24x24 pixels, is between 0.83% to 1.25% on a screen resolution of 1920 pixels.</p>
    <p class="cyan">The icon is indeed small and indeed also useful; then why raising an argument to remove it?</p>
    <p>Only a decade later, after this corporate-sponsored mischief, the market share of Firefox went further down to 3%.</p>
    <p>By now, the people of the aforementioned company should know that everything is at the hand of God!</p>
    <p class="quote">And said, Naked came I out of my mother's womb, and naked shall I return thither: <b>the Lord gave, and the Lord hath taken away;</b> blessed be the name of the Lord. -- Job 1:21 (King James Version)</p>
    <!-- p>The Karma. Oh, the Karma!</p -->
    <span class="decor"></span>
    <h3>XSLT</h3>
    <h4>Sabotaging A Standard Software Library</h4>
    <p>While figuring out how to build a syndication feed renderer (XML to HTML) addon into more browsers, an attorney at law has referred to the XSLT technology to find out that the process was not only easier than JavaScript but was also more secure and private.</p>
    <p>Compared to the PHP programming language and framework which typically work on the server-side, XSLT is exclusive to client-side, which means that all actions committed by XSLT are enclosed to the client machine, unlike PHP which actions are absolutely exposed to server.</p>
    <p>After the company has removed support for Atom/RSS, the attorney has referred to the Userscript technology in order to facilitate transition accross multiple browsers.</p>
    <p>While he continued programming a viable alternative for the long-term, he found out that the built-in Javascript programming library called <b>XSLTProcessor</b> works differently in the company's software, all in complete contradiction to the public documentation provided by the company.</p>
    <p>In other words, he discovered that <b>XSLTProcessor</b>, which is also useful for the rendering of Syndication Feeds, is deliberately malformed and would specifically fail with processing XSLT data on Syndication Feeds such as Atom, RDF and RSS file types.</p>
    <p>The findings are available at <a href="https://openuserjs.org/garage/Why_my_script_doesnt_work_with_Firefox#comment-1810ec600fe">openuserjs.org</a>.</p>
    <span class="decor"></span>
    <h3>More references about this brand</h3>
    <ul>
      <li><a href="https://diggy.club/articles/mozilla.xhtml">Mozilla - Devil Incarnate</a>, <b>you should read this</b>.</li>
      <li><a href="https://www.jwz.org/blog/2024/06/mozillas-original-sin/">Mozilla's Original Sin</a> (June 22, 2024)</li>
      <li><a href="https://www.jwz.org/blog/2024/06/mozilla-is-an-advertising-company-now/">Mozilla is an advertising company now</a> (June 20, 2024)</li>
      <li><a href="https://hacktivis.me/articles/firefox-begone">Firefox begone</a> (February 9, 2024)</li>
      <li><a href="https://sizeof.cat/post/firefox-telemetry-disabled-yet/">Firefox telemetry disabled, yet telemetry sent</a> (June 24, 2023)</li>
      <li><a href="https://www.jwz.org/blog/2020/09/this-is-a-pretty-dire-assessment-of-mozilla/">This is a pretty dire assessment of Mozilla</a> (September 23, 2020)</li>
      <li><a href="https://calpaterson.com/mozilla.html">Firefox usage is down 85% despite Mozilla's top exec pay going up 400%</a> (September 22, 2020)</li>
      <li><a href="https://www.jwz.org/blog/2016/10/they-live-and-the-secret-history-of-the-mozilla-logo/">They Live and the secret history of the Mozilla logo</a> (October 28, 2016)</li>
      <li><a href="https://hacktivis.me/articles/Mozilla%20is%20Broken">Mozilla is Broken</a> (November 11, 2015)</li>
    </ul>
  </div>
  <span class="decor"></span>
  <div id="advertising" class="segment">
    <!-- h1>🚨 From Advertising To Totalitarianism</h1 -->
    <!-- h1>🛜 RSS As An Autonomous Publishing Platform</h1 -->
    <h1>Syndication <span class="text-icon orange">Feeds</span> As Autonomous Publishing Platforms</h1>
    <h2>From Free Speech To Total Surveillance Promoted By Western Governments, And By The Advertisment And Censorship Industries</h2>
    <p>Learn how the contemporary advertisement industry stifles our freedoms and self-eliminates itself by embodying an amalgamation of everything that is worst in advertising and in societies of unwell consumption.</p>
    <p>Herein are arguments against the advertisement industry and the end result to where it tries to (mis)lead us.</p>
    <p class="quote">Advertisements and marketing jobs do not coexist in totalitarianism, so when the advertisement industry fights against syndication feeds, it fights for its own demise.</p>
    <h3>Preface</h3>
    <p>The advertisement industry promotes user tracking, and illegal and unethical spying instruments which are applied extensively into newer and useless standards such as HTML5. These newer standards are significantly simple to exploit against and target of individuals which make the internet more dangerous than ever before.</p>
    <p>The advertisement industry doesn't like Atom and RSS (henceforth "Syndication Feeds") because these are standards that are not subjected to the vast tracking instruments that are applied today in HTML conjoined with JavaScript; furthermore, Syndication Feeds are also lesser susceptible to targeted mind manipulation.</p>
    <h3>The Mischievous Story Of Mozilla</h3>
    <p>In 2009, the worldwide market share of the brand Mozilla has reached to 30%; and 80% of its annual revenue relied merely on promoting a specific search engine by determining it as a default search engine in its products.</p>
    <p>In 2016, the worldwide market share of Mozilla has dropped below 10%; and its annual revenue couldn't be the same by doing the same.</p>
    <p>In 2021, in a desperate move, Mozilla has foolishly partnered with advertising companies, very likely to provide advertisers with people's data and monitoring browser activity of people, which resulted in an annual revenue which exceeded $450 million dollars.</p>
    <p>In 2022, as a result of a yet another shenanigan of Mozilla, its worldwide market share went further below 3%.</p>
    <p>Mozilla is a good lesson for the world to see that there's no such thing as a benevolent multi-billion or multi-million organization that really wants to promote free telecommunication.</p>
    <p>The brand Mozilla can't be trusted.</p>
    <h3>The False And Miserable Argument Perpetrated By Publishers And The Advertisement Industry</h3>
    <p>In the recent five decades, publishers and the advertisement industry strive to convey a false narrative about the alleged mutuality and reciprocation of contents and advertisements, which basically says that "without advertisements there would be no incentive to create content" for the public to enjoy.</p>
    <p>There are many fundamental problems with this statement, and we will nullify this statement in three parts.</p>
    <ol>
      <li>The content of the big publishing houses is shamefully, disgracefully, dishonorably and indecently of very low quality.</li>
      <li>
        <p>When applying advertisements as an integrated part of a revenue model of a content production business so to speak, there is a conflict of interest between generating quality content to generating revenue;</p>
        <p>Which means that sooner or later a content producer will inevitably publish content that is either aberrational, defective, deficient, false, faulty, flawed, inadequate, wanting or even the lack thereof, which turns the content producer to a so called (i.e. false) content producer.</p>
      </li>
      <li>The conflict of interest extends to the censorship of contents that all or some advertisers don't want to be published (i.e. this is the the <i>lack</i> of content as written above).</li>
    </ol>
    <h3>Saying That Content Depends On Revenue Is Like Saying That Speech Depends On Revenue</h3>
    <p>It's as if you wouldn't be able to say hello to your parent or mate unless you will generate revenue by doing so or display an advertisement while doing so.</p>
    <p>To make this argument concise and successful, I will present the most obvious examples that would prove that content production is reciprocating with speech and ideology, not revenue.</p>
    <ol>
      <li>If you desire to publish anything, you will do it with or without advertisements.</li>
      <li>
        <p>Assuming you now live in a dystopian and hostile world as described in books like 1984, Brave New World and Fahrenheit 451, and you want to bring change by delivering and producing contents that would make this change that you so desire…</p>
        <p>Would you really have avertisements or revenue generating scheme in mind? Of course you would not! Rather, you will look for any possible mean available to you to make this possible, with or without advertisements or revenue.</p>
      </li>
    </ol>
    <p>To prove this point, below is a list of links to sites which the author (a Jewish Attorney) isn't approving of nor is opposing to, but is definitely supportive of you to freely exercise your speech and express your opinions or views however unpopular they might be.</p>
    <p>The sites herein do prove that content production doesn't rely on advertisements nor has anyhing to do with revenue.</p>
    <ul>
      <li><a href="https://annas-archive.org/">Anna’s Archive</a></li>
      <li><a href="https://copy-me.org/feed/">Copy-Me</a></li>
      <li><a href="https://howbadismybatch.com/">How Bad is my Batch ?</a></li>
      <li><a href="http://kimmoa.se/">Kimmoa</a></li>
      <li><a href="https://kopimi.com/kopimi/">Kopimi</a></li>
      <li><a href="https://www.metapedia.org/">Metapedia</a></li>
      <li><a href="http://scripting.com/">Scripting News</a></li>
      <li><a href="https://www.stormfront.org/forum/">Stormfront</a></li>
      <li><a href="http://zundelsite.org/">The Zundelsite</a></li>
      <li><a href="http://www.vanguardnewsnetwork.com/">Vanguard News Network</a></li>
      <li><a href="http://www.wakeupkiwi.com/">Wake Up New Zealand</a></li>
      <li><a href="http://whale.to/">WHALE</a></li>
    </ul>
    <p>The Zundelsite site is one of the most mirrored sites in history with hundreds of genuine copies from all over the world, and it was served freely <i>without</i> a single corporate advertisement.</p>
    <p class="cyan">Ask yourself again, do we really need advertisements and jumping banners in order to enjoy the internet?</p>
    <p>No. Of course, not!</p>
    <h3>Free Speech Is At Peril But It Really Is About Total Control</h3>
    <p>Supported by the advertisement industry, some organizations who are part of the censorship industry, have the audacity to claim authority and to actually <i>label</i> entities and sites—freely and without legal consequences—with terms such as "hate speech", so to speak.</p>
    <p>Be it true or false, this is nothing more than a miserable way to deny the idea of <b>Internet for Speech</b>, and a truly free internet which is clean from advertisements and tracking.</p>
    <p>Those who dare to label others with outlandish terms like "hate speech" or "white supremacist" etc., are danger to humanity, society and especially to Jewish people, like myself, in particular, because they use people of my kind to promote bad ideas, to say the least.</p>
    <p>If Mr. Alex Linder of Vanguard News Network didn't exist, governments, and other entities who hate your freedom of expression, have sufficient resources to create an Alex Linder of their own that would function as a pawn in their game to point their fingers at, and consequently look up for fake and prefabricated excuses to legitimize baseless censorship, in addition to perverting the internet with advertisements and tracking instruments.</p>
    <p>Hate it or like it, in this day and age, providing you are interested in saving and protecting your freedoms, people like Alex Linder are your best trusted friends, not enemies.</p>
    <h3>Advertising. Censorship. Tracking.</h3>
    <p>It isn't really about speech, speech is a false pretext, it's about tracking and monitoring people, all in the sake of creating an anti-privacy and anti-freedom world; a world as depicted in the book 1984.</p>
    <p>Censoring and speaking out against ideology sites, especially those which don't rely on advertisements, helps to strengthen the nonsensical and senseless notion that content publishing relies on revenue, which is clearly not the case in the sites presented above.</p>
    <p>Do not fall the narrative of "hate speech" or other similar misleading ideas to suppress freedom of expression; it's a conniving plot that intends for you to participate in, and—without realizing—enforce censorship against yourselves by yourselves, in the end.</p>
    <p class="cyan">And it all ties directly to the deliberate attempts to suppress the syndication feed technology.</p>
    <p>And last, but not least… Greed always strikes against oneself.</p>
    <p>Advertisements and marketing jobs do not coexist in totalitarianism, so when the advertisement industry fights against syndication feeds, it fights for its own demise.</p>
    <h3>Relevant Resources Concerning The Discussion Matter</h3>
    <ul>
      <li><a href="https://jacobwsmith.xyz/stories/ad_block.html">The Ethics of Ad Blocking</a></li>
      <li><a href="https://kopimi.com/kopimi/">The History of Kopimism</a> (April 21, 2023)</li>
      <li><a href="https://reclaimthenet.org/the-thousands-of-ways-advertisers-target-your-family">The Secret Ways Advertisers Target Your Family, Including Based On Your Mood or Personality</a> (June 27, 2023)</li>
      <li><a href="https://www.historicly.net/p/saddam-husseins-letter-to-an-american">Saddam Hussein's Letter to an American</a> (March 16, 2019)</li>
      <li><a href="https://mashable.com/article/facebook-ad-targeting-by-mood">Ads will target your emotions, unless you are using Syndication Feeds</a> (May 2, 2017)</li>
      <li><a href="https://warpspire.com/posts/ad-supported">Ad Supported</a> (September 17, 2015)</li>
      <li><a href="https://blog.mathieui.net/they-dont-want-my-money.html">They Don’t Want My Money</a> (July 20, 2013)</li>
      <li><a href="https://newsome.org/2011/01/04/why-big-media-wants-to-kill-rss-and-why-we-shouldnt-let-it/">Why Big Media Wants to Kill RSS, and Why We Shouldn't Let It</a> (January 4, 2011)</li>
    </ul>
  </div>
  <span class="decor"></span>
  <div id="proof" class="segment">
    <!-- h1><span class="text-icon orange">RSS</span> Is Relevant</h1 -->
    <h1>Syndication <span class="text-icon orange">Feeds</span> Are Very Popular</h1>
    <!-- h2>From Farmers To Statisticians - We All Need RSS</h2 -->
    <!-- h2>The Good, The Bad And The Ugly - From Farmers To Statisticians - Everyone Use RSS</h2 -->
    <h2>"One of the most popular feature requests we’ve been getting for our browser has been to add an RSS reader." —<a href="https://www.opera.com/features/news-reader">opera.com</a></h2>
    <p>Below are resources that indicate of the popularity and high demand of syndication feeds.</p>
    <h3>📈 Indications From Various of Cases</h3>
    <ul>
      <li><a href="https://trends.builtwith.com/feeds/traffic/Entire-Internet">RSS is the most popular Feed technology on the Entire Internet</a> (June 18, 2023)</li>
      <li>F-Droid: Over 50 free and open source mobile apps for <a href="https://search.f-droid.org/?q=Feed%20Reader" title="~15">Feed Reader</a>, <a href="https://search.f-droid.org/?q=Podcast" title="~18">Podcast</a> <a href="https://search.f-droid.org/?q=RSS" title="~48">and RSS</a> (June 18, 2023)</li>
      <li><a href="https://www.androidpolice.com/2021/04/13/google-podcasts-hits-100-million-installs-on-android-proving-people-might-care-about-rss-after-all/">Podcasts App hits 100 million installs on Android, proving people care about RSS</a> (April 13, 2021)</li>
      <li><a href="https://www.wired.com/story/rss-readers-feedly-inoreader-old-reader/">It's Time for an RSS Revival</a> (March 30, 2018)</li>
    </ul>
    <h3>💼 Enterprises &amp; Organizations Using Syndication Feeds</h3>
    <p>If you don't deploy syndication feeds in your site, be it a journal, a store or even a foundation, then you're very much behind.</p>
    <h4>Companies, Enterprises and Shops</h4>
    <p>From prestige enterprises to enterprises with over a million of subscribers, here are some enterprises that utilize the syndication feed technology.</p>
    <a href="https://www.96boards.org/feed.xml">96Boards</a>
    <a href="https://aerospike.com/feed/">Aerospike</a>
    <a href="https://www.archos.com/en/feed/">ARCHOS</a>
    <a href="https://www.bulsatcom.bg/feed/">Bulsatcom Telecom</a>
    <a href="https://www.cheapshark.com/api/1.0/deals?output=rss&amp;title=">CheapShark</a> (per product/title)
    <a href="https://git.zx2c4.com/cgit/atom/?h=master">cgit</a>
    <a href="https://codeberg.org/">Codeberg</a>
    <a href="https://www.consolidated.com/DesktopModules/DnnForge%20-%20NewsArticles/Rss.aspx?TabID=1877&amp;ModuleID=5685&amp;MaxCount=25">Consolidated Communications</a>
    <a href="https://www.cubebik.com/feed/">CubeBik</a>
    <a href="https://en.blog.nic.cz/feed/">CZ.NIC</a>
    <a href="https://www.daihatsu.com/rss.xml">DAIHATSU</a>
    <a href="https://www.debian.org/News/news">debian Linux</a>
    <a href="https://pod.diaspora.software/public/hq.atom">diaspora* HQ</a>
    <a href="https://distrowatch.com/news/dw.xml">DistroWatch</a>
    <a href="https://www.diva.exchange/en/feed/atom/">DIVA.EXCHANGE</a>
    <a href="https://cdn.dnalounge.com/backstage/log/feed/">DNA Lounge</a>
    <a href="https://www.dnalounge.com/calendar/dnalounge.rss">DNA Pizza</a>
    <a href="https://www.edgedb.com/rss.xml">EdgeDB</a>
    <a href="https://www.edrlab.org/feed/">EDRLab</a>
    <a href="https://www.etsy.com/">Etsy Shop</a> (per brand/store)
    <a href="https://www.firestorm.ch/feed/">FireStorm ISP</a>
    <a href="https://gab.com/">Gab</a> (per channel)
    <a href="https://about.gitea.com/index.xml">Gitea</a>
    <a href="https://about.gitlab.com/atom.xml">GitLab</a>
    <a href="https://blog.hubspot.com/website/rss.xml">HubSpot</a>
    <a href="https://www.idc.com/about/rss">IDC Corporate</a>
    <a href="https://www.indiegogo.com/">Indiegogo</a> (per project)
    <a href="https://www.khadas.com/blog-feed.xml">Khadas</a>
    <a href="https://www.kickstarter.com/">Kickstarter</a> (per project)
    <a href="https://kinsta.com/feed/">Kinsta</a>
    <a href="https://www.loc.gov/rss/">Library of Congress</a>
    <a href="https://lukesmith.xyz/lindy.xml">LindyPress.net Books Publication</a>
    <a href="https://mailchimp.com/help/troubleshooting-rss-in-campaigns/">Mailchimp</a>
    <a href="https://blog.joinmastodon.org/index.xml">Mastodon</a>
    <a href="https://joinmobilizon.org/en/news/feed.xml">Mobilizon</a>
    <a href="https://www.moviepilot.de/rss/moviepilot-standard">Moviepilot</a>
    <a href="https://mullvad.net/blog/feed/atom/">Mullvad</a>
    <a href="https://www.newgrounds.com/wiki/help-information/rss">Newgrounds</a>
    <a href="https://oktv.se/sv/a.rss">OKTV</a>
    <a href="https://www.olympus-global.com/rss/index.xml">OLYMPUS</a>
    <a href="https://www.opensubtitles.com/">OpenSubtitles</a> (per film)
    <a href="https://joinpeertube.org/rss-en.xml">PeerTube</a>
    <a href="https://www.procolix.com/feed/atom/">ProcoliX</a>
    <a href="https://sourceforge.net/blog/feed/atom/">SourceForge</a>
    <a href="https://sourcehut.org/blog/index.xml">sourcehut</a>
    <a href="https://stackexchange.com/feeds/questions">Stack Exchange</a>
    <a href="https://stackoverflow.com/feeds">Stack Overflow</a>
    <a href="https://www.supremecourt.gov/">Supreme Court of the United States</a>
    <a href="https://tailscale.com/blog/index.xml">Tailscale</a>
    <a href="https://tpb.party/rss">The Pirate Bay</a>
    <a href="https://www.timetecinc.com/feed/">Timetecinc</a>
    <a href="https://tutanota.com/blog/feed.xml">Tutanota</a>
    <a href="https://www.usembassy.gov/feed/">USEmbassy.gov</a> (Replace "<span title="www is ווו (Hebrew) which translates to 666.">www</span>" by country code name for a specific Embassy)
    <a href="https://vimeo.com/">Vimeo</a> (per channel)
    <a href="https://www.xinuos.com/feed/atom/">Xinuos</a>
    <a href="https://zapier.com/blog/feeds/latest/">Zapier</a>
    <a href="https://www.zendesk.com/public/assets/sitemaps/en/feed.xml">Zendesk</a>
    <a href="https://blog.zorin.com/index.xml">Zorin</a>
    <h4>Content and Forum Management Systems</h4>
    <p>With over a billion people and over hundred of trillions of posts, you can choose from a variety of CMS or community and forum management software systems with support for syndication.</p>
    <p class="background" title="This document shows you that 'free and open source software' are also subjected to a bad type of politics, yet it is recommended to choose open source forum software, just in case some feature is gone and you desire to bring it back.">We advise to choose open source forum software.  If you choose a proprietary software, please <i>do</i> make sure that you have a convenient way to import/export and backup all data.</p>
    <ul>
      <li><a href="https://askbot.com/">Askbot</a></li>
      <li><a href="https://www.discourse.org/">Discourse</a></li>
      <li><a href="https://djangobb.org/">DjangoBB</a></li>
      <li><a class="recom" href="https://www.elkarte.net/">ElkArte</a></li>
      <li><a class="recom" href="https://fluxbb.org/">FluxBB</a></li>
      <li><a href="https://invisioncommunity.com/">Invision Community (IP.Board)</a></li>
      <li><a href="https://www.mediawiki.org/wiki/MediaWiki">MediaWiki</a></li>
      <li><a class="recom" href="https://mybb.com/">MyBB</a></li>
      <li><a href="https://mylittleforum.net/">my little forum</a></li>
      <li><a href="https://nodebb.org/">NodeBB</a></li>
      <li><a href="https://camendesign.com/nononsense_forum">NoNonsense Forum</a></li>
      <li><a href="https://www.phorum.org/">Phorum</a></li>
      <li><a class="recom" href="https://www.phpbb.com/">phpBB</a></li>
      <li><a href="https://proboards.com/">ProBoards</a></li>
      <li><a href="https://punbb.informer.com/">PunBB</a></li>
      <li><a class="recom" href="https://www.redmine.org/">Redmine</a></li>
      <!-- li><a href="http://textboard.i2p/">SchemeBBS</a></li -->
      <!-- li><a href="https://wakaba.c3.cx/shii/shiichan">Shiichan Anonymous BBS</a></li -->
      <li><a href="https://simplemachines.org/">Simple Machines Forum</a></li>
      <!-- li><a href="https://syndie.de/">Syndie</a></li -->
      <li><a href="https://www.vbulletin.com/">vBulletin</a></li>
      <li><a href="https://xenforo.com/">XenForo</a></li>
    </ul>
    <h4>Foundations and Organizations</h4>
    <a href="http://cafe.nfshost.com/?feed=atom">Canadian Association for Free Expression</a>
    <a href="https://canine.org/feed/atom/">Canine Companions</a>
    <a href="https://www.ccc.de/de/rss/updates.xml">Chaos Computer Club</a> (Internationally recognized, highly accredited and respectful organization from Germany)
    <a href="https://static.fsf.org/fsforg/rss/news.xml">Free Software Foundation</a>
    <a href="https://freebsdfoundation.org/feed/atom/">FreeBSD Foundation</a>
    <a href="https://freedomboxfoundation.org/news/archive/index.atom">FreedomBox Foundation</a>
    <a href="https://planet.gnu.org/rss20.xml">GNU</a>
    <a href="https://www.linaro.org/feed.xml">Linaro</a>
    <a href="https://nlnet.nl/feed.atom">NLnet Foundation</a>
    <a href="https://perc.org/feed/atom/">PERC</a>
    <a href="https://prototypefund.de/feed/atom/">Prototype Fund</a>
    <a href="https://foundation.rust-lang.org/feed/feed.xml">Rust Foundation</a>
    <a href="https://www.sovereigntechfund.de/feed.rss">Sovereign Tech Fund</a>
    <a href="https://sfconservancy.org/feeds/omnibus/">The Software Freedom Conservancy</a>
    <h4>Governments and Legislatures</h4>
    <h5>🇧🇿 Belize</h5>
    <ul>
      <li><a href="https://www.nationalassembly.gov.bz/feed/atom/">National Assembly of Belize</a></li>
    </ul>
    <h5>🇧🇴 Bolivia</h5>
    <ul>
      <li><a href="https://diputados.gob.bo/feed/atom/">Chamber of Deputies</a></li>
      <li><a href="https://web.senado.gob.bo/rss.xml">Chamber of Senators</a></li>
    </ul>
    <h5>🇨🇺 Cuba</h5>
    <ul>
      <li><a href="https://www.parlamentocubano.gob.cu/index.php/rss.xml">National Assembly of People's Power - Asamblea Nacional del Poder Popular</a></li>
    </ul>
    <h5>🇩🇴 Dominican Republic</h5>
    <ul>
      <li><a href="https://www.senadord.gob.do/feed/atom/">Senate - Senado de la República Dominicana</a></li>
    </ul>
    <h5>🇪🇪 Estonia</h5>
    <ul>
      <li><a href="https://www.valitsus.ee/en/rss-feeds/rss.xml">Eesti Vabariigi Valitsus</a></li>
      <li><a href="https://www.riigikogu.ee/telli-rss/">Riigikogu</a></li>
    </ul>
    <h5>🇫🇯 Fiji</h5>
    <ul>
      <li><a href="http://www.fiji.gov.fj/Media-Center/Speeches.aspx?rss=news">Fiji Government</a></li>
    </ul>
    <h5>🇩🇪 Germany</h5>
    <ul>
      <li><a href="https://www.bundesrat.de/DE/service-navi/rss/rss-node.html">German Federal Council - Bundesrat</a></li>
      <li><a href="https://www.bundestag.de/static/appdata/includes/rss/aktuellethemen.rss">German Parliament - Bundestages</a></li>
      <u>Ministries</u>
      <li><a href="https://www.bmbf.de/bmbf/de/service/aktuelle-nachrichten-im-rss-newsfeed.html">Federal Ministry of Education and Research (BMBF)</a></li>
      <li><a href="https://prototypefund.de/feed/atom/">Prototype Fund</a></li>
    </ul>
    <h5>🇭🇰 Hong Kong</h5>
    <ul>
      <li><a href="https://www.fso.gov.hk/rss/fsblog_rss_e.xml">Financial Secretary</a></li>
      <li><a href="https://www.gov.hk/en/about/rsshelp.htm">GovHK</a></li>
      <li><a href="https://www.elegislation.gov.hk/verified-chapters!en.rss.xml">Hong Kong e-Legislation</a></li>
    </ul>
    <h5>🇮🇸 Iceland</h5>
    <span>Icelandic Parliament</span>
    <ul>
      <li><a href="https://www.althingi.is/rss.xml">Alþingi</a></li>
      <li><a href="https://www.althingi.is/um-althingi/skrifstofa-althingis/jafnlaunavottun/rss.xml">Alþingi - Jafnlaunavottun</a></li>
    </ul>
    <h5>🏴󠁵󠁳󠁩󠁤󠁿 Idaho (USA)</h5>
    <ul>
      <li><a href="https://legislature.idaho.gov/feed/atom/">Idaho State Legislature</a></li>
    </ul>
    <h5>🇮🇷 Iran</h5>
    <ul>
      <li><a href="https://en.parliran.ir/eng/en/allrss">Islamic Parliament of IRAN</a></li>
      <li><a href="https://www.president.ir/rss">President of Iran</a></li>
    </ul>
    <h5>🇮🇪 Ireland</h5>
    <span>Houses of the Oireachtas</span>
    <ul>
      <li><a href="https://www.oireachtas.ie/en/rss/dail-schedule.xml">Dail Schedule</a></li>
      <li><a href="https://www.oireachtas.ie/en/rss/press-releases.xml">Press Releases</a></li>
      <li><a href="https://www.oireachtas.ie/en/rss/committee-schedule.xml">Committee Schedule</a></li>
      <li><a href="https://www.oireachtas.ie/en/rss/seanad-schedule.xml">Seanad Schedule</a></li>
    </ul>
    <h5>🇮🇲 Isle of Man</h5>
    <ul>
      <li><a href="https://www.gov.im/news/RssNews">Isle of Man Government News</a></li>
    </ul>
    <h5>🇯🇴 Jordan</h5>
    <ul>
      <li><a href="http://senate.jo/ar/rss.xml">Jordanian Senate - مجلس الأعيان</a></li>
      <li><a href="https://representatives.jo/AR/Pages/خدمة_RSS">Jordanian Parliament - مجلس النواب الأردني</a></li>
    </ul>
    <h5>🇱🇺 Luxembourg</h5>
    <ul>
      <li><a href="https://www.chd.lu/en/podcast">Chamber of Deputies</a></li>
      <li><a href="https://gouvernement.lu/en/actualites/toutes_actualites.rss">Gouvernement</a></li>
    </ul>
    <h5>🇲🇹 Malta</h5>
    <ul>
      <li><a href="https://www.parlament.mt/en/rss/?t=calendar">Parliamentary Calendar</a></li>
    </ul>
    <h5>🇳🇱 Netherlands</h5>
    <ul>
      <li><a href="https://www.government.nl/rss">Government of the Netherlands</a></li>
      <li><a href="https://www.rijksoverheid.nl/rss">Rijksoverheid.nl</a></li>
    </ul>
    <h5>🇳🇴 Norway</h5>
    <ul>
      <li><a href="https://www.stortinget.no/no/Stottemeny/RSS/">Parliament of Norway</a></li>
    </ul>
    <h5>🇵🇭 Philippines</h5>
    <ul>
      <li><a href="https://parliament.bangsamoro.gov.ph/feed/atom/">Bangsamoro Parliament</a></li>
      <li><a href="https://econgress.gov.ph/feed/atom/">Congress of the Philippines</a></li>
    </ul>
    <h5>🇸🇷 Suriname</h5>
    <ul>
      <li><a href="https://dna.sr/rss-feed/">National Assembly - De Nationale Assemblee</a></li>
    </ul>
    <h5>🇨🇭 Switzerland</h5>
    <ul>
      <li><a href="https://www.admin.ch/gov/de/start/dokumentation/medienmitteilungen/rss-feeds.html">Swiss Federal Council - Der Bundesrat</a></li>
    </ul>
    <h5>🇸🇾 Syria</h5>
    <ul>
      <li><a href="http://parliament.gov.sy/arabic/index.php?node=17">The People's Assembly of Syria - مجلس الشعب السوري</a></li>
    </ul>
    <h5>🇹🇹 Trinidad and Tobago</h5>
    <ul>
      <li><a href="https://www.ttparliament.org/feed/atom/">Parliament of the Republic</a></li>
    </ul>
    <h5>🏴󠁵󠁳󠁵󠁴󠁿 Utah (USA)</h5>
    <ul>
      <li><a href="https://www.utah.gov/whatsnew/rss.xml">Utah.gov News Provider</a></li>
    </ul>
    <h4>Political Movements</h4>
    <p class="background">Be warry of the parties you support, some might be controlled-oppositions...</p>
    <h5>🇦🇱 Albania</h5>
    <ul>
      <li><a href="https://www.ballikombetar.info/feed/atom/">Zani i Arbërit</a></li>
    </ul>
    <h5>🏴󠁵󠁳󠁡󠁫󠁿 Alaska</h5>
    <ul>
      <li><a href="https://alaskanindependence.party/feed/atom/">Alaskan Independence Party</a></li>
    </ul>
    <h5>🇦🇲 Armenia</h5>
    <ul>
      <li><a href="http://www.hhk.am/rss/?l=en">Republican Party of Armenia</a></li>
      <li><a href="http://www.hhk.am/rss/?l=hy">Հայաստանի Հանրապետական կուսակցություն</a></li>
      <li><a href="http://www.hhk.am/rss/?l=ru">Республиканская партия Армении</a></li>
    </ul>
    <h5>🇦🇺 Australia</h5>
    <ul>
      <li><a href="https://pirateparty.org.au/feed/atom/">Pirate Party Australia</a></li>
    </ul>
    <h5>🇦🇹 Austria</h5>
    <ul>
      <li><a href="https://piratenpartei.at/feed/atom/">Piratenpartei Österreichs</a></li>
    </ul>
    <h5>🏴󠁧󠁥󠁡󠁢󠁿 Abkhazia</h5>
    <ul>
      <li><a href="http://rpp-ea.org/index.php?format=feed&amp;type=atom">РПП - Единая Абхазия - United Abkhazia</a></li>
    </ul>
    <h5>🇨🇾 Cyprus</h5>
    <ul>
      <li><a href="http://www.piratepartycyprus.com/rss.php">Pirate Party Cyprus</a></li>
    </ul>
    <h5>🇨🇿 Czech</h5>
    <ul>
      <li><a href="https://www.pirati.cz/feeds/atom/">Česká pirátská strana</a></li>
      <li><a href="https://svycarska-demokracie.cz/feed/">Švýcarská demokracie</a></li>
    </ul>
    <h5>🇩🇰 Denmark</h5>
    <ul>
      <li><a href="https://www.nordfront.dk/feed/atom/">Nordfront</a></li>
    </ul>
    <h5>🇫🇴 Faroe Islands</h5>
    <ul>
      <li><a href="https://folkaflokkurin.fo/feed/atom/">Fólkaflokkurin</a></li>
    </ul>
    <h5>🇫🇮 Finland</h5>
    <ul>
      <li><a href="https://www.vastarinta.com/feed/atom/">Kansallinen Vastarinta | Radikalisoituvan Suomen uutiset</a></li>
      <li><a href="https://www.kd.fi/feed/atom/">Kristillisdemokraatit</a></li>
      <li><a href="https://sinimustaliike.fi/feed/atom/">Sinimusta Liike</a></li>
      <li><a href="https://www.skepuolue.fi/feed/atom/">Suomen Kansa Ensin r.p.</a></li>
    </ul>
    <h5>🇬🇦 Gabon</h5>
    <ul>
      <li><a href="https://www.pdg-gabon.com/feed">Parti Démocratique Gabonais</a></li>
    </ul>
    <h5>🇩🇪 Germany</h5>
    <ul>
      <li><a href="https://www.afd.de/feed/">Alternative für Deutschland</a></li>
      <li><a href="https://buendnis-c.de/feed/atom/">Bündnis C - Christen für Deutschland</a></li>
      <li><a href="http://deutsche-partei-dp.de/?feed=atom">Deutsche Partei</a></li>
      <li><a href="https://www.fdp.de/rss.xml">FDP - Freie Demokratische Partei</a></li>
      <li><a href="http://www.we-love-liberty.org/feed/">German Freedom Party</a></li>
      <li><a href="https://der-dritte-weg.info/feed/">Nationale Partei – DER III. WEG</a></li>
      <li><a href="https://parteidervernunft.de/feed/atom/">Partei der Vernunft</a></li>
      <li><a href="https://www.piratenpartei.de/feed/atom/">Piratenpartei Deutschland</a></li>
    </ul>
    <h5>🇬🇷 Greece</h5>
    <ul>
      <li><a href="https://www.pirateparty.gr/feed/atom/">Κόμμα Πειρατών Ελλάδας – Pirate party of Greece</a></li>
      <li><a href="https://xrisiavgi.com/feed/atom/">ΧΡΥΣΗ ΑΥΓΗ - Golden Dawn</a></li>
    </ul>
    <h5>🇭🇹 Haiti</h5>
    <ul>
      <li><a href="http://www.oplhaiti.org/feed/atom/">Oganizasyon Pèp k ap Lite</a></li>
      <li><a href="http://phtk.ht/feed/">Parti Haïtien Tèt Kale (PHTK)</a></li>
    </ul>
    <h5>🇰🇿 Kazakhstan</h5>
    <ul>
      <li><a href="http://www.pirateparty.kz/feed/">Pirate Party of Kazakhstan</a></li>
    </ul>
    <h5>🇮🇪 Ireland</h5>
    <ul>
      <li><a href="https://www.finegael.ie/feed/atom">Fine Gael</a></li>
      <li><a href="https://libertyrepublic.ie/index.php/feed/atom/">Liberty Republic</a></li>
      <li><a href="https://www.niconservatives.com/events/feed">NI Conservatives - Previous Events</a></li>
      <li><a href="https://www.irishfreedom.ie/feed/atom/">The Irish Freedom Party</a></li>
      <li><a href="https://nationalparty.ie/feed/atom/">The National Party - AN PÁIRTÍ NÁISIÚNTA</a></li>
    </ul>
    <h5>🇮🇹 Italy</h5>
    <ul>
      <li><a href="https://www.partito-pirata.it/feed/atom/">Partito Pirata Italiano</a></li>
    </ul>
    <h5>🇱🇻 Latvia</h5>
    <ul>
      <li><a href="https://nacionalaapvieniba.lv/feed/atom/">Nacionālā Apvienība</a></li>
    </ul>
    <h5>🇱🇹 Lithuania</h5>
    <ul>
      <li><a href="https://susivienijimas.lt/feed/atom/">Nacionalinis susivienijimas</a></li>
      <li><a href="https://piratupartija.lt/feed/atom/">Piratų Partija</a></li>
    </ul>
    <h5>🇱🇺 Luxembourg</h5>
    <ul>
      <li><a href="https://adr.lu/feed/">adr Webseite</a></li>
      <li><a href="https://piraten.lu/feed/atom/">PIRATEN</a></li>
      <li><a href="https://piraten.lu/en/feed/atom/">PIRATEN (en)</a></li>
      <li><a href="https://piraten.lu/fr/feed/atom/">PIRATES (fr)</a></li>
      <li><a href="https://piraten.lu/pt-pt/feed/atom/">PIRATEN (pt)</a></li>
      <li><a href="https://www.pid4you.lu/blog-feed.xml">Partei fir integral Demokratie</a></li>
    </ul>
    <h5>🏴󠁵󠁳󠁭󠁡󠁿 Massachusetts</h5>
    <ul>
      <li><a href="https://masspirates.org/blog/feed/atom/">Massachusetts Pirate Party</a></li>
    </ul>
    <h5>🇲🇽 Mexico</h5>
    <ul>
      <li><a href="https://relial.org/feed/atom/">Relial Red Liberal de América Latina</a></li>
    </ul>
    <h5>🇳🇱 Netherlands</h5>
    <ul>
      <li><a href="https://piratenpartij.nl/feed/atom/">Piratenpartij</a></li>
    </ul>
    <h5>🏴󠁵󠁳󠁮󠁹󠁿 New York</h5>
    <ul>
      <li><a href="https://www.cpnys.org/feed/atom/">Conservative Party of New York State (CPNYS)</a></li>
      <li><a href="https://nysrighttolife.org/feed/atom/">NYS Right to Life</a></li>
    </ul>
    <h5>🇳🇿 New Zealand</h5>
    <ul>
      <li><a href="http://pirateparty.org.nz/feed/">The Pirate Party of New Zealand</a></li>
    </ul>
    <h5>🇲🇰 North Macedonia</h5>
    <ul>
      <li><a href="https://vmro-dpmne.org.mk/feed/atom">ВМРО-ДПМНЕ</a></li>
    </ul>
    <h5>🇳🇴 Norway</h5>
    <ul>
      <li><a href="https://www.frihetskamp.net/feed/atom/">Den nordiske Motstandsbevegelsen</a></li>
      <li><a href="https://www.motstandsbevegelsen.info/feed/atom/">Den nordiske Motstandsbevegelsen</a></li>
      <li><a href="https://nordicresistancemovement.org/feed/atom/">Nordic Resistance Movement | The National Socialist Front Line</a></li>
    </ul>
    <h5>🇵🇰 Pakistan</h5>
    <ul>
      <li><a href="https://www.pnbest.my/blog-feed.xml">Perikatan Nasional</a></li>
    </ul>
    <h5>🇵🇱 Poland</h5>
    <ul>
      <li><a href="https://konfederacja.pl/feed/atom/">Konfederacja</a></li>
      <li><a href="https://polskapartiapiratow.pl/feed/atom/">Polska Partia Piratów</a></li>
      <li><a href="https://suwerennapolska.pl/feed/atom/">Suwerenna Polska</a></li>
    </ul>
    <h5>🇵🇹 Portugal</h5>
    <ul>
      <li><a href="http://www.partidoergue-te.pt/feed/atom/">Ergue-te!</a></li>
    </ul>
    <h5>🇷🇴 Romania</h5>
    <ul>
      <li><a href="https://www.partidulpirat.ro/feed/atom/">Partidul Pirat Romania</a></li>
      <li><a href="https://partidulromaniamare.ro/feed/">Partidul România Mare</a></li>
      <li><a href="https://partidulromaniamare.com/feed/">Partidul Romania Mare – Spania</a></li>
    </ul>
    <h5>🇷🇺 Russia</h5>
    <ul>
      <li><a href="https://pirate-party.ru/feed/">Пиратская партия России | PPRU</a></li>
      <li><a href="https://zapravdu.org/feed/atom/">ЗА ПРАВДУ</a></li>
      <li><a href="http://xn--80aaag6azbdefu3lf.xn--p1ai/atom/">Политическая партия "Гражданская Платформа"</a></li>
      <li><a href="https://cprf.ru/feed/atom/">Communist Party of the Russian Federation</a></li>
      <li><a href="https://kprf.ru/export/rss/first.xml">КПРФ.ру - Главные новости</a></li>
      <li><a href="http://komros.org/feed/atom/">КОММУНИСТЫ РОССИИ Официальный сайт</a></li>
      <li><a href="http://patriot-rus.ru/rss/rss_news.xml">Патриоты России. Новости</a></li>
      <li><a href="https://partyadela.ru/feed/atom/">Партия Дела</a></li>
    </ul>
    <h5>🇸🇮 Slovenia</h5>
    <ul>
      <li><a href="https://piratskastranka.si/rss/">Pirati</a></li>
    </ul>
    <h5>🇪🇸 Spain</h5>
    <ul>
      <li><a href="https://alianzanacional.net/feed/atom/">Alianza Nacional</a></li>
    </ul>
    <h5>🇸🇪 Sweden</h5>
    <ul>
      <li><a href="https://nordfront.se/feed/atom/">Nordfront</a></li>
      <li><a href="https://nordurvigi.se/feed/atom/">Norræna Mótstöðuhreyfingin</a></li>
      <li><a href="https://piratpartiet.se/feed/atom/">Piratpartiet</a></li>
    </ul>
    <h5>🇨🇭 Switzerland</h5>
    <ul>
      <li><a href="https://die-mitte.ch/feed/atom/">Christian Democratic People's Party of Switzerland</a></li>
      <li><a href="https://www.edu-schweiz.ch/feed/atom/">EDU Schweiz</a></li>
      <li><a href="https://lega-dei-ticinesi.ch/feed/atom/">Lega dei Ticinesi</a></li>
      <li><a href="https://mcge.ch/feed/atom/">MCGE - Mouvement Citoyens Genevois</a></li>
      <li><a href="https://www.piratenpartei.ch/feed/atom/">Piratenpartei Schweiz</a></li>
      <li><a href="https://www.svp.ch/feed/atom/">SVP Schweiz - Schweizerische Volkspartei SVP</a></li>
    </ul>
    <h5>🇺🇦 Ukraine</h5>
    <ul>
      <li><a href="https://azov.org.ua/feed/">Бригада спеціального призначення АЗОВ</a></li>
    </ul>
    <h5>🇬🇧 United Kingdom</h5>
    <ul>
      <li><a href="https://cpaparty.net/feed/atom/">Christian Peoples Alliance</a></li>
      <li><a href="https://www.cityhallconservatives.com/blog-feed.xml">City Hall Conservatives</a></li>
      <li><a href="https://heritageparty.org/feed/atom/">Heritage Party</a></li>
      <li><a href="http://natfront.info/feed/atom/">National Front</a></li>
      <li><a href="https://pirateparty.org.uk/feed.xml">Pirate Party UK</a></li>
      <li><a href="https://www.thebrexitparty.org/feed/atom/">The Brexit Party</a></li>
      <li><a href="https://bnp.org.uk/feed/atom/">The British National Party (BNP)</a></li>
      <li><a href="http://libertarian.co.uk/feed/atom/">The Libertarian Alliance</a></li>
      <li><a href="https://ukchristianparty.org/feed/atom/">UK Christian Party</a></li>
    </ul>
    <h5>🇺🇸 United States of America</h5>
    <ul>
      <li><a href="https://campaignforliberty.org/feed/atom">Campaign for Liberty</a></li>
      <li><a href="https://constitutionparty.com/feed/atom/">Constitution Party</a></li>
      <li><a href="https://www.natall.com/feed/atom/">National Alliance</a></li>
      <li><a href="https://www.prohibitionparty.org/blog-feed.xml">Prohibition Party</a></li>
      <li><a href="https://reformparty.org/feed/atom/">Reform Party National Committee</a></li>
      <li><a href="https://therightstuff.biz/feed/atom">The Right Stuff</a></li>
      <li><a href="https://uspirates.org/feed/atom/">United States Pirate Party</a></li>
    </ul>
    <h5>🏴󠁧󠁢󠁷󠁬󠁳󠁿 Wales</h5>
    <ul>
      <li><a href="https://www.conservatives.wales/events/feed">The Welsh Conservative Party - Previous Events</a></li>
    </ul>
    <h4>Legal</h4>
    <ul>
      <li><a href="https://www.daihatsu.com/rss.xml">DAIHATSU</a> (Recovering)</li>
      <li><a href="https://www.elegislation.gov.hk/verified-chapters!en.rss.xml">Hong Kong e-Legislation</a></li>
      <li><a href="https://www.madofftrustee.com/rss.php">Madoff Trustee</a></li>
    </ul>
    <h4>Major Publications</h4>
    <a href="http://feeds.arstechnica.com/arstechnica/index">Ars Technica</a>
    <a href="https://www.blacklistednews.com/rss.php">BlackListed News</a>
    <a href="https://www.breitbart.com/feed">Breitbart</a>
    <a href="https://www.ft.lk/rss">Daily FT</a>
    <a href="https://www.dailytelegraph.com.au/help-rss">Daily Telegraph</a>
    <a href="https://www.spiegel.de/dienste/besser-surfen-auf-spiegel-online-so-funktioniert-rss-a-1040321.html">DER SPIEGEL</a>
      <!-- a href="https://corporate.dw.com/de/rss/s-9773">Deutsche Welle</a -->
    <a href="https://dw.com/rss">Deutsche Welle</a>
    <a href="https://www.filmdienst.de/rss">Filmdienst Magazin</a>
    <a href="https://www.gawker.com/rss">Gawker</a>
    <a href="https://news.ycombinator.com/rss">Hacker News</a>
    <a href="https://www.hindustantimes.com/rss">Hindustan Times</a>
    <a href="https://www.ksl.com/rss/news">KSL News</a>
    <a href="https://www.lemonde.fr/actualite-medias/article/2019/08/12/les-flux-rss-du-monde-fr_5498778_3236.html">Le Monde</a>
    <a href="https://www.linux-magazine.com/rss/feed/lmi_news">Linux Magazine</a>
    <a href="https://www.malaymail.com/rss">Malay Mail</a>
    <a href="https://www.news.com.au/help/rss-feeds">news.com.au</a>
    <a href="https://newatlas.com/rss">New Atlas</a>
    <a href="https://newsblenda.com/feed/">Newsblenda</a>
    <a href="https://api.ntd.com/feed">NTD Television</a>
    <a href="https://oraclebroadcasting.com/">Oracle Broadcasting Network</a>
    <a href="https://www.pcmag.com/feeds/rss/latest">PCMag.com</a>
    <a href="https://www.pcworld.com/feed">PCWorld</a>
    <a href="https://www.phoronix.com/rss.php">Phoronix</a>
    <a href="https://www.prnewswire.com/rss/">PR Newswire</a>
    <a href="https://www.presstv.ir/rss.xml">Press TV</a>
    <a href="https://www.smithsonianmag.com/rss/">Smithsonian Magazine</a>
    <a href="https://rss.slashdot.org/Slashdot/slashdotMain">Slashdot</a>
    <a href="https://substack.com/">Substack</a>
    <a href="https://www.tehrantimes.com/rss-help">Tehran Times</a>
    <a href="https://www.sltrib.com/rss/">The Salt Lake Tribune</a>
    <a href="https://www.theverge.com/rss/index.xml">The Verge</a>
    <a href="https://thewest.com.au/rss-feeds">The West Australian</a>
    <a href="https://torrentfreak.com/feed/">TorrentFreak</a>
    <a href="https://variety.com/feed/">Variety</a>
    <a href="https://vdare.com/generalfeed">VDARE</a>
    <a href="https://en.yna.co.kr/channel/index">Yonhap News Agency</a>
    <a href="https://www.ziffdavis.com/feed">Ziff Davis</a>
    <h4>Propaganda and PsyOp sites Sponsored by Intelligence Agencies</h4>
    <h5>Intelligence and foreign controlled disinformation publications</h5>
    <p>The following agent publications below pretend to be news outlets, when in fact, these are funded and controlled either by internal or foreign intelligence or military agencies, and their purpose is to instil fear, disrupt and subvert your mind with bogus information, not otherwise.</p>
    <p>You might as well want to refer them as Corporate Lame-Ass Propaganda (CLAP) as written at <a href="https://www.reallibertymedia.com/about-rlm/">RLM</a>.</p>
    <ul>
      <!-- TODO Find that article titled "Why the news will never get (or be) better" with a comic of a news anchor in studio saying "You're all goin to die" -->
      <li><a href="https://farside.link/teddit/r/comics/comments/y21feb/the_news">The News</a> (Comic)</li>
      <!-- li><a href="https://farside.link/teddit/pics/w:null_p52ifybn1dt91.png">The News</a> (Comic)</li -->
      <li><a href="https://www.informationliberation.com/?id=23538">64% - Internet News Audience Critical of Press</a></li>
      <li><a href="https://jacobwsmith.xyz/stories/dont_watch_the_news.html">Don't watch the news</a></li>
      <li><a href="https://icyphox.sh/blog/dont-news/">You don't need news</a></li>
      <!-- li><a href="https://www.theguardian.com/media/2013/apr/12/news-is-bad-rolf-dobelli">News is bad for you – and giving up reading it will make you happier</a></li -->
      <li><a href="https://web.archive.org/web/20220930204955if_/https://tomfasano.net/posts/private-networking.html">Computer Networking and It's Future</a></li>
    </ul>
    <p>The fact that these compromised publications (so called) make use of syndication feeds, realizes the obvious importance of the syndication feed technology.</p>
    <p class="background">The resources below are listed for realization purposes only, and we further advise you <i>not</i> to subscribe to any of these harmful publications.</p>
    <div>
      <a href="https://www.aljazeera.com/xml/rss/all.xml">Al Jazeera</a>
      <a href="http://feeds.bbci.co.uk/news/rss.xml">BBC</a>
      <a href="https://www1.cbn.com/app_feeds/rss/news/rss.php?section=world">CBN</a>
      <a href="https://www.cbsnews.com/latest/rss/main">CBS</a>
      <a href="https://www.cnbc.com/rss-feeds/">CNBC</a>
      <a href="https://edition.cnn.com/services/rss/">CNN</a>
      <a href="https://www.dcnewsnow.com/feed/atom/">DC News Now</a>
      <a href="https://www.foxnews.com/story/foxnews-com-rss-feeds">FOX</a>
      <a href="https://gizmodo.com/rss">Gizmodo</a>
      <a href="https://news.google.com/rss">Google News</a>
      <a href="https://www.hindustantimes.com/rss">Hindustan Times</a>
      <a href="https://www.infowars.com/rss.xml">Infowars</a>
      <a href="https://www.nasa.gov/rss-feeds/" title="SA(T)AN">NASA</a>
      <a href="https://feeds.npr.org/1001/rss.xml">NPR</a>
      <a href="https://www.rollingstone.com/feed/">Rolling Stone</a>
      <a href="https://www.rt.com/rss/">RT (Russia Today)</a>
      <a href="https://scitechdaily.com/feed/">SciTechDaily</a>
      <a href="https://news.sky.com/info/rss">SKY</a>
      <a href="https://theathletic.com/feeds/rss/news/">The Athletic</a>
      <a href="https://feeds.thedailybeast.com/rss/articles">The Daily Beast</a>
      <a href="https://www.dailymail.co.uk/home/rssMenu.html">The Daily Mail Online</a>
      <a href="https://www.dailywire.com/feeds/rss.xml">The Daily Wire</a>
      <a href="https://www.theguardian.com/uk/rss">The Guardian</a>
      <a href="https://www.nytimes.com/rss">The New York Times</a>
      <a href="https://www.newyorker.com/about/feeds?verso=true">The New Yorker</a>
      <a href="https://www.wsj.com/news/rss-news-and-feeds">The Wall Street Journal</a>
      <a href="https://www.washingtonpost.com/rss">The Washington Post</a>
      <a href="https://www.state.gov/feed/">U.S. Department of State</a>
      <a href="https://variety.com/feed/">Variety</a>
      <a href="https://www.mediawiki.org/wiki/MediaWiki">Wikimedia Foundation</a>
      <a href="https://news.yahoo.com/rss/">Yahoo News</a>
      <p>P.S. <a href="https://www.metapedia.org/">Wikipedia</a> is really a publication medium of <a href="https://www.fivefilters.org/2023/glenn-greenwald-on-wikipedia-bias/">biased propaganda</a>. You are advised to read and get your information from <a href="https://www.metapedia.org/">Metapedia</a> which actually has factual information.</p>
    </div>
    <h3>📑 Conclusion</h3>
    <!-- h4>Don't be left behind. Use RSS.</h4 -->
    <!-- p>Don't be left behind. Use RSS.</p -->
    <p>If you don't make use of syndication feeds yet, then you definitely need to start using it now.</p>
    <p>Do not be left behind. Use Syndication Feeds <i>Today!</i></p>
    <!-- p>And if you don't already have a site, then <a href="https://videos.lukesmith.xyz/w/9aadaf2f-a8e7-4579-913d-b250fd1aaaa9"><u>Get a Website Now!</u> <b>Don't be a Web Peasant!</b></a></p -->
    <!-- p>You might also want to read the <a href="https://sizeof.cat/post/dos-and-donts/">Dos and Don'ts of current times</a>.</p -->
    <!-- p><i>Use RSS Today!</i></p -->
  </div>
  <span class="decor"></span>
  <div id="alternative" class="segment">
    <h1>🖥️ Alternative Vendors</h1>
    <!-- h2>You And Your Friends Deserve To Have Access To RSS.</h2 -->
    <h2>You And Your Friends Deserve To Have A First-Class RSS Experience Baked In To Your Browser So Well Your Grandmother Could Use It —<a href="https://camendesign.com/blog/rss_is_dying">Kroc</a></h2>
    <p>Below are browsers with built-in support for syndication feeds, and as such are worthy of the name Browser.</p>
    <h3>💼️ <a href="https://gmi.skyjake.fi/lagrange/">Lagrange</a></h3>
    <h3>Browser For People Who Talk Business... Securely.</h3>
    <!-- h3>Browser For People Who Talk <sup>Secured</sup> Business.</h3 -->
    <p>Lagrange is a GUI client for browsing Geminispace. It offers modern conveniences familiar from browsers, such as smooth scrolling, inline image viewing, multiple tabs, visual themes, Unicode fonts, bookmarks, history, and page outlines.</p>
    <p>Like Gemini, Lagrange has been designed with minimalism in mind. It depends on a small number of essential libraries. It is written in C and uses SDL for hardware-accelerated graphics. OpenSSL is used for secure communications.</p>
    <p>Lagrange supports <b>Gemini and Atom</b> feed subscriptions. Atom feeds are automatically translated to the Gemini feed format so they can be viewed and subscribed to like a normal 'text/gemini' page.</p>
    <h3>🦅 <a href="https://falkon.org/">Falkon</a></h3>
    <h3>Lightweight multiplatform browser.</h3>
    <!-- p>Falkon (previously QupZilla) is a modern browser based on WebKit core and Qt Framework. WebKit guarante fast browsing and Qt availability on all major platforms.</p -->
    <p>Falkon is a KDE browser using QtWebEngine rendering engine, previously known as QupZilla. It aims to be a lightweight browser available through all major platforms. This project has been originally started only for educational purposes. But from its start, Falkon has grown into a feature-rich browser.</p>
    <p>Falkon has all standard functions you expect from a browser. It includes bookmarks, history (both also in sidebar) and tabs. Above that, it has by default enabled blocking ads with a built-in AdBlock plugin.</p>
    <h3>History</h3>
    <p>The very first version of QupZilla has been released in December 2010 and it was written in Python with PyQt4 bindings. After a few versions, QupZilla has been completely rewritten in C++ with the Qt Framework. First public release was 1.0.0-b4.</p>
    <p>Until version 2.0, QupZilla was using QtWebKit. QtWebKit is now deprecated and new versions are using QtWebEngine.</p>
    <p>Since version 3.0, QupZilla is no longer developed and new version are released with Falkon name as a KDE project.</p>
    <h3>🐦 <a href="https://ladybird.org/">Ladybird</a></h3>
    <h3>A New Cross Platform Browser Project.</h3>
    <p>The Ladybird browser came to life on July 4th; it was originally a headless mode of LibWeb (previously LibHTML) and is also featuring a Qt GUI for the LibWeb browser engine. Ladybird was intended to be a debugging tool for people to remain in Linux while working on LibWeb if they wanted to. Two months later, Ladybird has became a browser in its own right.</p>
    <p>At this point, we might as well tweak the scope from “browser engine for SerenityOS” to “cross-platform browser engine” and build something that many more people could potentially have use for some day. :^)</p>
    <h3>🦎 <a href="http://kmeleonbrowser.org/">K-Meleon</a></h3>
    <h3>The Browser You Control.</h3>
    <p>K-Meleon is a lightweight, customizable, open-source browser. It's designed for Microsoft Windows (Win32) operating systems.</p>
    <p>K-Meleon can use the secure Goanna engine based on Mozilla's Gecko layout engine or Gecko itself. Support for legacy operating systems, low RAM usage, a macro language to customize the browser, and privacy-respecting defaults are among K-Meleon's unique features.</p>
    <p>K-Meleon can run also on Windows 2000, Windows XP and <a href="https://reactos.org/">ReactOS</a>.</p>
    <h3>🦦 <a href="https://otter-browser.org/">Otter Browser</a></h3>
    <h3>Controlled By The User, Not Vice Versa.</h3>
    <p>Otter Browser aims to recreate the best aspects of the classic Opera (12.x) UI using Qt5.</p>
    <p>Otter Browser aims to recreate the best aspects of Opera 12 and to revive its spirit. We are focused on providing the powerful features "power users" want while keeping the browser fast and lightweight.</p>
    <p>We also learned from history and decided to release the browser under the GNU GPL v3.</p>
    <h3>🌕 <a href="https://www.palemoon.org/">Pale Moon</a></h3>
    <H3>Your Browser, Your Way.</H3>
    <p>Pale Moon is an Open Source, Goanna-based browser, focusing on efficiency and customization.</p>
    <p>Pale Moon offers you a browsing experience in a browser completely built from its own, independently developed source that has been forked off from Firefox/Mozilla code a number of years ago, with carefully selected features and optimizations to improve the browser's stability and user experience, while offering full customization and a growing collection of extensions and themes to make the browser truly your own.</p>
    <h3>🦁 <a href="https://brave.com/brave-today-rss/">Brave</a></h3>
    <h3>Secure, Fast, And Private Browser.</h3>
    <p>Brave is on a mission to protect your privacy online. We make a suite of internet privacy tools—including our browser and search engine—that shield you from the ads, trackers, and other creepy stuff trying to follow you across the internet.</p>
    <p>Brave News, the privacy-preserving news reader integrated into the Brave browser, now features syndication feeds.</p>
    <h3><span class="red-color">𝐎</span> <a href="https://www.opera.com/features/news-reader">Opera</a></h3>
    <h3>Faster, Safer, Smarter.</h3>
    <p>Experience faster, distraction-free browsing with Ad blocking, and browse privately. Smoothly sync your data and send files between Opera on Mac, Windows, Linux, iOS, Android, and Chromebook.</p>
    <p><i>One of the most popular feature requests we’ve been getting for our browser has been to add an RSS reader.</i></p>
    <p>Your feedback matters a lot to us when we’re planning our roadmap. As such, Opera’s news reader now supports RSS feeds, too!</p>
    <p class="background">⚠️ Opera is a proprietary freeware.</p>
    <h3><span class="orange-color">𝓥</span> <a href="https://vivaldi.com/features/feed-reader/">Vivaldi</a></h3>
    <h3>Powerful. Personal. Private.</h3>
    <p>Get unrivaled customization options and built-in browser features for better performance, productivity, and privacy.</p>
    <p>Vivaldi Feed Reader helps you build a private news feed based on your interests, not what you do online.</p>
    <p class="background">⚠️ Vivaldi is a proprietary freeware.</p>
  </div>
  <span class="decor"></span>
  <div id="even" class="segment">
    <h1><span class="redice">🧊</span> Even <i>"They"</i> Have Syndication Feeds</h1>
    <h2>Then Why Should Not You Too?</h2>
    <p>This is a list of sources who are infamous by government regulated media (<span title="Corporate Lame-Ass Propaganda">CLAP</span>), which does not mean that these sources are necessarily bad; it only means that some governments hate them, which is fine, because most people hate most of the political imposters (i.e. politicians) either, so that makes it all even.</p>
    <p>Call them <span title="Are they?">silly</span>; call them <span title="It seems that they are pretty large!">small</span>; call them <span title="Are they?">stupid</span>; call them <span title="Is being racist a bad thing?">racists</span>; call them <span title="Are they?">incompetent</span>; call them <span title="Are they?">extremists</span>; even call them <span title="Are they?">dangerous</span>, <span title="Are they?">terrorists</span> and <span title="Are they?">saboteurs</span>; call them <a href="https://web.archive.org/web/20100105052412if_/http://www.newworldorderreport.com/Articles/tabid/266/ID/980/33-Conspiracy-Theories-That-Turned-Out-To-Be-True-What-Every-Person-Should-Know.aspx" title="33 Conspiracy Theories That Turned Out To Be True, What Every Person Should Know...">conspiracy</a> <a href="https://www.blacklistednews.com/article/83721/5-crazy-conspiracy-theories-that-actually-turned-out-to-be.html" title="5 “CRAZY” CONSPIRACY THEORIES THAT ACTUALLY TURNED OUT TO BE TRUE">theorists</a>; call them <span title="Are they?">bad</span>!</p>
    <p>You can call them anything you want, and yet, they are indeed wiser when it regards to be easy to reach.</p>
    <h3>Asia</h3>
    <ul>
      <li><a href="https://www.addameer.org/rss.xml">Addameer</a>, an organization from Ramallah, Palestine</li>
      <li><a href="https://www.aljazeera.com/xml/rss/all.xml">Al Jazeera</a>, a major publication from Doha, Qatar</li>
      <li><a href="https://ericdubay.wordpress.com/feed/atom/">EricDubay.com</a>, a major publication of Mr. Eric Dubay from Thailand</li>
      <li><a href="https://www.pnbest.my/blog-feed.xml">Perikatan Nasional</a>, a political party from Pakistan</li>
      <li><a href="https://www.presstv.ir/rss.xml">Press TV</a>, a major publication from Iran</li>
    </ul>
    <h3>Europe</h3>
    <ul>
      <li><a href="https://www.afd.de/feed/">Alternative für Deutschland</a>, a political party from Germany</li>
      <li><a href="https://alianzanacional.net/feed/atom/">Alianza Nacional</a>, a political party from Spain</li>
      <li><a href="https://arktos.com/feed/atom/">Arktos Media</a>, a major publication of Mr. Daniel Friberg from Budapest</li>
      <li><a href="https://www.frihetskamp.net/feed/atom/">Den nordiske Motstandsbevegelsen</a> and <a href="https://www.motstandsbevegelsen.info/feed/atom/">Den nordiske Motstandsbevegelsen</a>, a political party from Norway</li>
      <li><a href="https://www.vastarinta.com/feed/atom/">Kansallinen Vastarinta</a>, a political party from Finland</li>
      <li><a href="http://libertarian.co.uk/feed/atom/">Libertarian Alliance</a>, a political party from UK</li>
      <li><a href="https://susivienijimas.lt/feed/atom/">Nacionalinis susivienijimas</a>, a political party from Lithuania</li>
      <li><a href="https://nacionalaapvieniba.lv/feed/atom/">Nacionālā Apvienība</a>, a political party from Latvia</li>
      <li><a href="http://natfront.info/feed/atom/">National Front</a>, a political party from UK</li>
      <li><a href="https://www.nordfront.dk/feed/atom/">Nordfront</a>, a political party from Denmark</li>
      <li><a href="https://nordfront.se/feed/atom/">Nordfront</a> and <a href="https://nordurvigi.se/feed/atom/">Norræna Mótstöðuhreyfingin</a>, a political party from Sweden</li>
      <li><a href="https://nordicresistancemovement.org/feed/atom/">Nordic Resistance Movement</a>, a political party from Norway</li>
      <li><a href="https://piraten.lu/feed/atom/">PIRATEN</a>, a political party from Luxembourg</li>
      <li><a href="https://piratpartiet.se/feed/atom/">Piratpartiet</a>, a political party from Sweden</li>
      <li><a href="https://redice.tv/rss/red-ice-radio">Red Ice Radio</a>, a major publication of activist and journalist Mr. Henrik Palmgren from Post Falls, Idaho and Sweden (there are even more <a href="https://redice.tv/rss" class="not-an-xml">syndication feeds</a>)</li>
      <li><a href="https://nationalparty.ie/feed/atom/">AN PÁIRTÍ NÁISIÚNTA</a>, a political party from Ireland</li>
      <li><a href="https://xrisiavgi.com/feed/atom/">ΧΡΥΣΗ ΑΥΓΗ</a>, a political party from Greece</li>
    </ul>
    <h3>North America</h3>
    <ul>
      <li><a href="https://bdscoalition.ca/feed/atom/">BDS Coalition</a>, a political movement from Canada</li>
      <li><a href="https://bdsmovement.net/rss-feed.xml">BDS Movement</a>, a political movement</li>
      <li><a href="https://www.blacklistednews.com/rss.php">BlackListed News</a>, a major publication of Mr. Doug Owen from Round Rock, Texas</li>
      <li><a href="http://cafe.nfshost.com/?feed=atom">CAFE</a> (Canadian Association for Free Expression), a popular organization from Canada</li>
      <li><a href="https://campaignforliberty.org/feed/atom">Campaign for Liberty</a>, a political movement of Mr. Dr. Ron Paul from Haymarket, Prince William County, Virginia</li>
      <li><a href="https://codoh.com/feed/atom/">Committee for Open Debate on the Holocaust</a>, a popular organization from Healdsburg, California</li>
      <li><a href="https://davidduke.com/feed/atom/">DavidDuke.com</a>, a personal publication of a former Louisiana politician Mr. Dr. David Duke from Louisiana</li>
      <li><a href="https://drrimatruthreports.com/feed/atom/">Dr. Rima Truth Reports</a> and <a href="http://www.opensourcetruth.com/feed/atom/">Open Source Truth</a>, major publications of Mrs. Dr. Rima E. Laibow, M.D. from Newton, New Jersey</li>
      <li><a href="https://fakeologist.com/feed/atom/">Fakeologist</a>, a major publication and popular podcast of Mr. Ab Irato from Canada</li>
      <li><a href="https://freedomain.com/feed/atom/">Freedomain – The no. 1 philosophy show online</a>, a popular podcast of Mr. Stefan Molyneux from Canada</li>
      <li><a href="https://grrrgraphics.com/feed/atom/">GrrrGraphics</a>, a major satiric publication of a cartoonist Mr. Ben Garrison from San Angelo, Texas</li>
      <li><a href="https://www.johnderbyshire.com/feed.xml">JohnDerbyshire.com</a>, a popular podcast of Mr. John Derbyshire from Pennsylvania</li>
      <li><a href="http://larkenrose.com/?format=feed&amp;type=atom">LarkenRose.com</a>, a personal publication of the author of the Most Dangerous Superstition Mr. Larken Rose</li>
      <li><a href="https://www.lewrockwell.com/feed/atom/">LewRockwell.com</a>, a major publication of Mr. Lew Rockwell from Auburn, Alabama</li>
      <li><a href="https://loomered.com/feed/atom/">Loomered</a>, a major publication of Mrs. Laura Loomer from Tucson, Arizona</li>
      <li>Ludwig von <a href="https://mises.org/rss.xml">Mises Institute</a>, for Austrian Economics, a major publication and a well renowned institution of Mr. Lew Rockwell from Auburn, Alabama</li>
      <li><a href="http://grizzom.blogspot.com/feeds/posts/default">Mami's Shit</a>, a popular and communal publication operated by Zapoper</li>
      <li><a href="https://www.jack-donovan.com/sowilo/feed/atom/">Masculine Philosophy</a>, a major publication of Mr. Jack Donovan from Pennsylvania</li>
      <li><a href="https://www.mintpressnews.com/feed/atom/">MintPress News</a>, a major publication which includes the <a href="https://www.mintpressnews.com/category/podcasts/feed/atom/">MintCast</a> podcast of "Behind The Headlines" from Minneapolis, Minnesota</li>
      <li><a href="https://nationalvanguard.org/feed/atom/">National Vanguard</a>, a major publication from Mountain City, Tennessee</li>
      <li><a href="http://oraclebroadcasting.com/" class="not-an-xml">Oracle Broadcasting Network</a>, a major radio station and a popular podcast of Mr. Lee Rogers from Texas (<a href="http://www.oraclebroadcasting.com/rss_recent.php">Oracle Broadcasting Network</a> has been inactive since 2013)</li>
      <li><a href="https://redice.tv/rss/radio-3fourteen">Radio 3Fourteen</a>, a popular podcast of activist and journalist Mrs. Lana Lokteff from Post Falls, Idaho</li>
      <li><a href="https://www.realjewnews.com/?feed=atom">Real Jew News</a>, a major publication and a popular podcast of "Street Evangelist" Brother Nathanael Kapner from Priest River, Idaho</li>
      <li><a href="https://www.reallibertymedia.com/feed/atom/">Real Liberty Media</a>, a major radio station and a popular podcast of Mr. Hal Anthony and Mr. Grimnir Freeman (R.I.P.) from Texas</li>
      <li><a href="https://redice.tv/rss/red-ice-radio">Red Ice Radio</a>, a major publication of activist and journalist Mr. Henrik Palmgren from Post Falls, Idaho and Sweden (there are even more <a href="https://redice.tv/rss" class="not-an-xml">syndication feeds</a>)</li>
      <li><a href="https://www.renegadebroadcasting.com/feed/atom/">Renegade Broadcasting</a>, a major radio station of Mr. Kyle Hunt from Deltona, Florida</li>
      <li><a href="https://stewpeters.com/feed/atom/">StewPeters.com</a> a major publication, a popular podcast, and a popular video production of Mr. Stew Peters</li>
      <li><a href="https://www.natall.com/feed/atom/">The National Alliance</a>, a political party from Mill Point, West Virginia</li>
      <li><a href="https://theconsciousresistance.com/feed/atom/">The Conscious Resistance Network</a>, of activist and journalist Mr Derrick Broze from Texas</li>
      <li><a href="https://truthandjusticeforgermans.com/feed/atom/">Truth and Justice for Germans Society</a>, a campaign site which provides hostorical reviews and exposes faults against the German people and their allies, after World War II</li>
      <li><a href="https://truthstreammedia.com/feed/atom/">Truthstream Media</a>, a major publication and a popular video production of Mr. Aaron Dykes and Mrs. Melissa Dykes from Texas</li>
      <li><a href="http://www.vanguardnewsnetwork.com/feed/atom/">Vanguard News Network</a>, a major publication of Mr. Alex Linder from Pittsburgh, Pennsylvania</li>
      <li><a href="https://vdare.com/generalfeed">VDARE</a>, a major publication of Mr. Peter Brimelow from Virginia</li>
    </ul>
    <p>Download all the above subscriptions as an <span class="cursor-pointer" id="opml-selection-even-they"><u>OPML Outline</u></span> file which can be imported into other feed readers.</p>
    <p>Truth be told is, that only a fool would not want to deploy syndication feeds.</p>
    <hr/>
    <p class="background">As a Jew, I have postponed this article for too much long... and I think it is time to finally "break the ice", in the hope for my own fellow Jews to cease from crippling the internet.</p>
    <p>P.S. Even the NSDAP advocators (commonly known as Nazi Party, whatever "Nazi" means; or Neo-Nazis, whatever "Neo" means) also deploy syndication feeds to reach to their audience.</p>
    <p>Are you angry at me; or should I be angry at you?</p>
  </div>
  <span class="decor"></span>
  <div id="reason" class="segment">
    <header>
      <h1>💭 Another Reason Why Feeds Won't Die</h1>
      <h2>Source: <a href="https://envs.net/~lucidiot/rsrsss/feed.xml">RSRSSS</a></h2>
      <p>
        <time>Sun, 21 Jan 2024 21:16:10 +0100</time>
      </p>
    </header>
    <div class="unescape">
      <p>I will occasionally hear about the neverending debate on whether or not RSS and Atom feeds are dead, or are dying, or will die. This debate has been ongoing ever since the mere concept of feeds started showing up online. The most common arguments nowadays are that nobody uses RSS feeds anymore now that Google Reader has shut down and that everyone just uses social media. But as I have shown a few times in this feed, feeds are far from about to die. Sure, maybe Google Reader shutting down has made feeds less visible, or may have caused a small dip in the number of subscribers to some feeds. Sure, maybe social media makes people care about feeds less, but that's because they just don't care at all about the content of said feeds and don't need tools to handle that content, it's not a technical issue or something that obsoletes feeds.</p>
      <p>But here's an argument that I don't remember ever seeing in this constant bickering: the fact that there are technologies out there that rely on feeds. Moving those away from feeds would be very costly. Here are a few use cases that I found while going down different rabbit holes.</p>

      <h3>Podcasts</h3>
      <p>Podcasts are still very much popular. While most people nowadays will be listening to podcasts through some streaming services like Spotify, iTunes, or podcast-specific platforms, podcasts started out just as <code>&lt;enclosure&gt;</code> tags within RSS feeds, and that's how those platforms fetch them.</p>
      <p>Spotify imports podcasts from RSS feeds and have <a href="https://providersupport.spotify.com/article/podcast-delivery-specification-1-9" rel="noreferrer">a specification</a> for how they parse them. They also <a href="https://support.spotify.com/us/podcasters/article/your-rss-feed/" rel="noreferrer">provide a feed</a> if you are hosting your podcast on Spotify directly, so that you can share it elsewhere. All podcast hosting platforms provide feeds.</p>
      <p>iTunes <a href="https://podcasters.apple.com/support/823-podcast-requirements" rel="noreferrer">relies on feeds</a>. They have <a href="https://help.apple.com/itc/podcasts_connect/#/itcb54353390" rel="noreferrer">their own XML namespace</a>, which is likely to be found on pretty much every podcast feed as that became a <em>de facto</em> standard namespace for podcasts before the <a href="https://podcastnamespace.org/" rel="noreferrer">podcast namespace</a> showed up.</p>
      <p>Google Podcasts <a href="https://support.google.com/podcast-publishers/answer/9889544?hl=en" rel="noreferrer" href-data="https://support.google.com/podcast-publishers/answer/9889544?hl=en">feeds on feeds</a>, and also allows subscribing to an RSS feed directly without it having to be submitted to Google.</p>

      <h3>News</h3>
      <p>Obviously, a large amount of feeds are dedicated to news. Every single news site out there has an RSS or Atom feed hidden somewhere. Most of them will be sharing a link to it, either with an RSS icon somewhere on the page or with <a href="https://www.rssboard.org/rss-autodiscovery" rel="noreferrer">RSS Autodiscovery</a>, but even if they don't, they still do have a feed. They have to have a feed in order to survive.</p>
      <p>How can I say that so confidently? Well, because <a href="https://support.google.com/news/publisher-center/answer/9545414" rel="noreferrer">Google News feeds on feeds</a>, <a href="https://helpcenter.microsoftstart.com/kb/articles/43-onboarding-a-new-feed-with-fmt" rel="noreferrer">Microsoft Start and MSN.com feed on feeds</a>, <a href="https://support.google.com/faqs/answer/9396344" rel="noreferrer">Google Assistant feeds on feeds</a>, <a href="https://about.flipboard.com/rss-guidelines/" rel="noreferrer">Flipboard feeds on feeds</a>, and just about any other news aggregator uses feeds.</p>
      <p>It's the standard way to aggregate news articles, and a lot of people will start with a news aggregator to get their news, particularly Google News. It has so much weight on how news are accessed from that setting <code>news.google.com</code> as your referrer on HTTP requests can unlock paywalls and that <a href="https://en.wikipedia.org/wiki/Google_News#Compensation_for_disseminating_access_to_news" rel="noreferrer">various laws have been drafted</a> to make Google News pay news publishers.</p>

      <h3>Ads</h3>
      <p>Google has leaned rather heavily on RSS, including for ads. For example, I randomly found <a href="https://support.google.com/admanager/answer/7501017" rel="noreferrer">this sample feed</a> for an ad tech called Dynamic Ad Insertion, which sounds like it is how <del>soulless people</del> marketers can insert ads into livestreams and VOD. <a href="https://support.google.com/merchants/answer/160589" rel="noreferrer">Google Shopping also feeds on feeds</a>. Those feeds can be <a href="https://github.com/w3c/feedvalidator/blob/ff89646c3f6869058dfcf5a3cf9b6ead49bbe42d/testcases/gbase/rss2/vehicles2.xml" rel="noreferrer">really detailed</a> because of <a href="https://web.archive.org/web/20080915080232/http://base.google.com/base/attribute_list.html" rel="noreferrer">Google Base</a>, yet another product they killed. <a href="https://support.google.com/docs/answer/3093337" rel="noreferrer">Google Docs supports feeds</a>. They probably are in other places, but since Google's ads are incredibly obfuscated, I don't even want to try and dig deeper into their unhelpful help to find more examples.</p>
      <p>Google Base's legacy is also found at other companies: Facebook lets advertisers send them a list of products as <a href="https://developers.facebook.com/docs/marketing-api/catalog/reference#example-atom-xml-feed-commerce" rel="noreferrer">RSS and Atom feeds with Google Base attributes</a>.</p>

      <h3><abbr title="Geographic Information Systems">GIS</abbr></h3>
      <p>Real-time information that includes geolocations can be quite important, both in the public and private sectors. Waze for Cities <a href="https://support.google.com/waze/partners/answer/13458165" rel="noreferrer">exports data as GeoRSS</a>. A lot of GIS software will support GeoRSS imports. And the <abbr title="Geography Markup Language">GML</abbr> and <abbr title="Keyhole Markup Language">KML</abbr> formats supports automatic updates. KML, the format behind Google Earth's data, is supported by the <a href="https://validator.w3.org/feed/" rel="noreferrer">W3C Feed Validation Service</a> for a reason.</p>

      <h3>Overcomplicated enterprise apps</h3>
      <p>Probably the only reason why <a href="https://learn.microsoft.com/en-us/dotnet/api/system.servicemodel.syndication.syndicationfeed" rel="noreferrer">the .NET Framework has a feed parser</a> is because of <a href="https://learn.microsoft.com/EN-US/dotnet/framework/wcf/feature-details/wcf-syndication" rel="noreferrer">feed support in <abbr title="Windows Communication Foundation">WCF</abbr>.</a> <abbr title="Windows Communication Foundation">WCF</abbr> aims to represent business processes that mix a whole bunch of other apps together, like how hiring someone will require HR approval on some particular app, then payroll needs to be notified, security issues a badge, etc. You draw the diagrams of the processes in Visual Studio, implement every step as a bunch of .NET code that probably calls out to other apps, and then have a WCF server somewhere to handle that stuff.</p>
      <p>IBM has <a href="https://www.ibm.com/docs/en/baw/23.x?topic=format-interface-atom-feed" rel="noreferrer">an equivalent support in Business Automation Workflow</a>.</p>
      <p>Oracle HCM <a href="https://docs.oracle.com/en/cloud/saas/human-resources/23d/farws/Working_with_Atom.html" rel="noreferrer">provides Atom feeds</a> so that other apps can be notified of changes on more HR stuff.</p>
      <p>Corporate applications are probably among the slowest-moving software out there, so it's very unlikely that those will drop their support for feeds any time soon.</p>

      <h3><abbr title="Too long; didn't read">TL;DR</abbr>: Money</h3>
      <p>Those few examples are far from an exhaustive list and they just show some of the things I have stumbled upon, but they are enough to prove that behind RSS and Atom feeds, there is <em>money</em>. And if a technology has been made necessary to make a profit somewhere, then changing it will be too risky and maintaining it becomes essential to capitalists. Even if the general public completely stops using feeds, they will still be out there somewhere, and thus tools, software libraries will still be out there to support them, and nothing will stop anyone from still using feeds.</p>
    </div>
  </div>
  <span class="decor"></span>
  <div id="support" class="segment">
    <h1>🧐 Taking Action</h1>
    <h2>The Things You Can Do To Promote Syndication Feeds</h2>
    <p>This is a mission which we deserve and should be most honored to take.</p>
    <ul>
      <li>Promote <a href="https://www.rfc-editor.org/rfc/rfc4287">The Atom syndication Format</a>, <a href="https://geminiprotocol.net/">Project Gemini</a>, <a href="https://joinjabber.org/">Jabber</a> (aka XMPP) and BitTorrent in order to get us out from the HTML5 calamity to a better telecommunication system.</li>
      <li>Start <a href="https://videos.lukesmith.xyz/w/9aadaf2f-a8e7-4579-913d-b250fd1aaaa9">your own site</a> and don't forget to add syndication feeds.</li>
      <li>Talk with your friends about the benefits of syndication feeds. That would be a good table talk.</li>
      <li>Use a feed reader. (See list of software in pages <a href="#software" class="link">software</a> and <a href="#alternative" class="link">browsers</a>)</li>
      <li>Teach other people to use feed readers. Blog about feed readers. And about other open telecommunication technologies and apps.</li>
      <li>Write a blog instead of posting to “social networks”. (You can always re-post to those places if you want to extend your reach.) <a href="https://www.justjournal.com/">Just Journal</a>, <a href="https://micro.blog/">Micro.blog</a> and <a href="https://monocles.social/">monocles.social</a> are good places to get going, and these are not the only ones.</li>
      <li>Petition <a href="http://unicode.org/pending/proposals.html">unicode.org</a> and promote the initiative for the <a href="https://github.com/vhf/unicode-syndication-proposal">Proposal to Include Syndication Symbol</a>.</li>
      <li>Donate to charities that promote literacy.</li>
      <li>Tell other people about cool blogs and feeds you’ve found.</li>
      <li>Support independent podcast apps and desktop software.</li>
      <li>Support indie developers. Even though software like Falkon, Newspaper, postmarketOS etc. are free, software are most definitely not free to make, and it costs time and effort to keep improving them. It’s worth it.</li>
      <li>Report bugs and make feature requests on our Issues tracker. We also need testers, writers, and, especially, people who are willing to talk things over. Most of software development is just making decisions, and we appreciate all the help we can get!</li>
      <li>And if you don't already have a site, then <a href="https://videos.lukesmith.xyz/w/9aadaf2f-a8e7-4579-913d-b250fd1aaaa9">Get a Website Now!</a> (Don't be a Web Peasant!)</li>
    </ul>
  </div>
  <span class="decor"></span>
  <div id="resources" class="segment">
    <h1>📚 Useful Resources</h1>
    <h3>Related Resources And Campaigns</h3>
    <h4>The Links Below Are Not Associated With RSS Task Force</h4>
    <ul>
      <li><a href="https://aboutfeeds.com/">About Feeds</a></li>
      <li><a href="https://datatracker.ietf.org/meeting/66/materials/slides-66-atompub-1.pdf">Atom Over XMPP</a></li>
      <li><a href="https://100daystooffload.com/">100 Days To Offload</a></li>
      <li><a href="https://bringback.blog/">Bring Back Blogs! January 2023</a></li>
      <li><a href="https://www.ctrl.blog/topic/syndication-feeds.html">Ctrl.blog</a></li>
      <li><a href="https://feedpress.com/">FeedPress</a></li>
      <li><a href="https://rss.feedspot.com/">FeedSpot RSS Database</a></li>
      <li><a href="https://www.fivefilters.org/">FiveFilters</a></li>
      <li><a href="https://follow.it/intro">follow.it</a></li>
      <li><a href="https://www.netvibes.com/">Netvibes</a></li>
      <li><a href="https://openrss.org/blog">Open RSS Blog</a></li>
      <li><a href="http://rss-sync.github.io/Open-Reader-API/">Open Reader API</a></li>
      <li><a href="https://www.repeatserver.com/">RepeatServer</a></li>
      <li><a href="https://www.rssing.com/about.php">RSSing</a></li>
      <li><a href="http://rss-sync.github.io/Open-Reader-API/rssconsensus/">The RSS Consensus</a></li>
    </ul>
    <span class="decor"></span>
    <h3>Useful Projects</h3>
    <h4>Projects You Might Find Useful</h4>
    <ul>
      <li><a href="https://xml.apache.org/cocoon/">Apache Cocoon</a></li>
      <li><a href="https://feedparser.readthedocs.io/">feedparser</a></li>
      <li><a href="http://xmlsoft.org/">libxml2</a></li>
      <li><a href="https://libxmlplusplus.sourceforge.net/">libxml++</a></li>
      <li><a href="https://lxml.de/">lxml</a></li>
      <li><a href="https://openuserjs.org/scripts/sjehuda/Newspaper">Newspaper</a></li>
      <li><a href="https://sourceforge.net/projects/rss-builder/">RSS Builder</a></li>
      <li><a href="https://www.saxonica.com/">Saxonica</a></li>
      <li><a href="https://gitgud.io/sjehuda/streamburner">StreamBurner</a></li>
      <li><a href="https://github.com/DesignLiquido/xslt-processor">XSLT-processor</a></li>
    </ul>
    <span class="decor"></span>
    <h3>Articles And Videos About Open Telecommunication And Syndication Feeds</h3>
    <h4>Good Reads About Syndication Feeds</h4>
    <ul>
      <li><a href="https://jacobwsmith.xyz/guides/rss_guide.html">How to Use RSS</a></li>
      <li><a href="https://openrss.org/rss-feeds">RSS Feeds. What? Why? How?</a></li>
      <li><a href="https://jacobwsmith.xyz/stories/200609.html">The Past is the Future: Why I Love RSS</a></li>
      <li><a href="https://www.rss-specifications.com/everything-rss.htm">What Are RSS Feeds?</a></li>
      <li><a href="https://web.archive.org/web/20060103051403if_/http://home.hetnet.nl/mr_2/43/bsoft/rssbuilder/">Becoming an RSS News Feed publisher</a></li>
      <li><a href="https://danielmiessler.com/p/its-time-to-get-back-into-rss/">It’s Time to Get Back Into RSS</a></li>
      <li><a href="https://danielmiessler.com/p/atom-rss-why-we-should-just-call-them-feeds-instead-of-rss-feeds/">Atom and RSS: Why We Should Just Call Them “Feeds” Instead of “RSS” Feeds</a></li>
      <li><a href="https://andrewstiefel.com/style-atom-xsl/">How To Style An Atom Feed With XSLT</a> (April 7, 2024)</li>
      <li><a href="https://thecozy.cat/blog/what-is-an-rss-feed-and-how-do-i-make-one-rss-for-newbies/">What is an RSS feed and how do I make one? | RSS for Newbies</a> (August 5, 2023)</li>
      <li><a href="https://www.wired.com/story/podcasts-speech-thought-history-enlightenment/">Podcasts Could Unleash a New Age of Enlightenment</a> (June 16, 2023)</li>
      <li><a href="https://openrss.org/blog/browsers-should-bring-back-the-rss-button">Browsers removed the RSS Button and they should bring it back</a> (May 30, 2023)</li>
      <li><a href="https://www.brycewray.com/posts/2022/12/why-have-both-rss-json-feeds/">Why have both RSS and JSON feeds?</a> (December 9, 2022)</li>
      <li><a href="https://thoughts.melonking.net/guides/rss-guide-how-to-get-started-using-rss">RSS Guide - How to get started using RSS</a> (December 6, 2022)</li>
      <li><a href="https://videos.lukesmith.xyz/w/cqEPGroWNwUDH4AAYp2f7t">How we can reach Normies with RSS</a> (September 14, 2021)</li>
      <li><a href="https://natclark.com/tutorials/xslt-style-rss-feed/">Styling an RSS Feed With XSLT</a> (September 3, 2021)</li>
      <li><a href="https://jacobwsmith.xyz/stories/rss_content.html">How to make your content viewable in an RSS feed</a> (April 24, 2021)</li>
      <li><a href="Styling an RSS/Atom feed with XSL">How to style RSS feed</a> (April 17, 2021)</li>
      <li><a href="https://jacobwsmith.xyz/stories/fixed_rss.html">Finally figured out how to make my RSS feed convenient</a> (April 23, 2021)</li>
      <li><a href="https://jacobwsmith.xyz/stories/two_useful_websites.html">Two useful websites</a> (March 17, 2021)</li>
      <li><a href="https://news.ycombinator.com/item?id=26169162">Why Atom instead of RSS?</a> (February 17, 2021)</li>
      <li><a href="https://zapier.com/blog/how-to-use-rss-feeds/">How to use RSS feeds to boost your productivity</a> (January 13, 2021)</li>
      <li><a href="https://danielmiessler.com/p/how-i-organize-my-rss-feeds-2021-edition/">How I Organize my RSS Feeds, 2021 Edition</a></li>
      <li><a href="https://www.techadvisor.com/article/741233/what-is-an-rss-feed.html">What is an RSS feed?</a> (September 15, 2020)</li>
      <li><a href="https://videos.lukesmith.xyz/w/pmSAZAvWpVVXz42KqG4H4d">Uh, What are RSS feeds? NEWSBOAT</a> (July 16, 2020)</li>
      <li><a href="https://videos.lukesmith.xyz/w/bvvsuywyf7B6E21pva3m5c">Virgin Social Media vs. Chad RSS (UNCENSORED!)</a> (June 30, 2020)</li>
      <li><a href="https://copyblogger.com/what-the-heck-is-rss/">What the Heck is RSS? And why should I care?</a> (May 26, 2020)</li>
      <li><a href="https://lepture.com/en/2019/rss-style-with-xsl">How to style RSS feed</a> (December 21, 2019)</li>
      <li><a href="https://www.wired.com/story/rss-readers-feedly-inoreader-old-reader/">It's Time for an RSS Revival</a> (March 30, 2018)</li>
      <li><a href="https://www.jwz.org/blog/2013/07/this-week-in-rss-apocalypse/">This Week in RSS Apocalypse</a> (July 5, 2013)</li>
      <li><a href="https://camendesign.com/rss_a_reply">RSS: A Reply</a> (January 14, 2011)</li>
      <li><a href="http://scripting.com/stories/2011/01/08/youCanGetAnythingYouWant.html#p4214">You can get anything you want...</a> (January 8, 2011)</li>
      <li><a href="https://www.spiegel.de/netzwelt/web/streit-um-internet-nutzung-komfort-schlaegt-freiheit-a-737748.html">Streit um Internet-Nutzung: Komfort schlägt Freiheit - DER SPIEGEL</a> (January 7, 2011)</li>
      <li><a href="https://web.archive.org/web/20110108063442/http://buddycloud.com/cms/content/we-are-aol-days-social-networking">We are in the AOL days of Social Networking</a> (January 6, 2011)</li>
      <li><a href="http://scripting.com/stories/2011/01/05/upcomingTheMinimalBlogging.html">Upcoming: The minimal blogging tool</a> (January 5, 2011)</li>
      <li><a href="https://techcrunch.com/2011/01/03/techcrunch-twitter-facebook-rss/">Content Publishing Platforms Really Are Killing RSS</a> (January 4, 2011)</li>
      <li><a href="http://scripting.com/stories/2011/01/04/whatIMeanByTheOpenWeb.html#p4111">What I mean by "the open internet"</a> (January 4, 2011)</li>
      <li><a href="https://newsome.org/2011/01/04/why-big-media-wants-to-kill-rss-and-why-we-shouldnt-let-it/">Why Big Media Wants to Kill RSS, and Why We Shouldn't Let It</a> (January 4, 2011)</li>
      <li><a href="https://camendesign.com/blog/rss_is_dying">RSS Is Dying, and You Should Be Very Worried</a> (January 3, 2011)</li>
      <li><a href="http://scripting.com/stories/2011/01/03/rebootingRssRevisited.html">Rebooting RSS, revisited</a> (January 3, 2011)</li>
      <li><a href="http://scripting.com/stories/2010/09/27/howToUseOpenStandards.html">How to use open formats</a> (September 27, 2010)</li>
      <li><a href="http://scripting.com/stories/2010/09/24/whyUseRss.html">Why use RSS?</a> (September 24, 2010)</li>
      <li><a href="http://scripting.com/stories/2010/09/13/howToRebootRss.html">How to reboot RSS</a> (September 13, 2010)</li>
      <li><a href="http://scripting.com/stories/2010/07/21/howToDoOpenDevelopentWorkR.html">How to do open development work, Rules 1 &amp; 2</a> (July 21, 2010)</li>
      <li><a href="http://scripting.com/stories/2010/09/22/rebootingRssInterlude.html">Rebooting RSS, interlude</a> (September 22, 2010)</li>
      <!-- li><a href="http://scripting.com/stories/2010/09/20/rebootingRssShortNamesForF.html">Rebooting RSS, short names for feeds</a> (September 20, 2010)</li -->
      <li><a href="http://scripting.com/stories/2010/09/18/rebootingRssTwoKeyPoints.html">Rebooting RSS, pulling it together</a> (September 18, 2010)</li>
      <li><a href="http://scripting.com/stories/2010/09/18/yesVirginiaThereAreTwoWays.html">Yes, Virginia, there are two ways to read RSS</a> (September 18, 2010)</li>
      <li><a href="http://scripting.com/stories/2010/09/16/theArchitectureOfRss.html">The Architecture of RSS</a> (September 16, 2010)</li>
      <li><a href="https://web.archive.org/web/20050416134332if_/http://www.emediawire.com/releases/2005/1/emw200210.htm">RSS Rapidly Becoming the Next Standard in Commercial Internet-Publishing and Online Information Distribution</a> (January 24, 2005)</li>
      <li><a href="https://www.xml.com/pub/a/2002/12/18/dive-into-xml.html">What Is RSS</a> (December 18, 2002)</li>
      <li><a href="https://web.archive.org/web/20030210215820if_/http://www.oreillynet.com/cs/user/view/wlg/2426">Last-minute business RSS</a> (December 14, 2002)</li>
      <li><a href="https://fishbowl.pastiche.org/2002/10/21/http_conditional_get_for_rss_hackers">HTTP Conditional Get for RSS Hackers</a> (October 21, 2002)</li>
    </ul>
    <span class="decor"></span>
    <h3>Upcoming Projects</h3>
    <h4>I need some help here…</h4>
    <ul>
      <li>Restoring <a href="https://web.archive.org/web/20011025203909if_/http://www.syndic8.com:80/">Syndic8</a>. See also: <a href="https://feedland.org/">FeedLand</a>.</li>
      <li>Delivering Syndic8 by DHT (using BitTorrent or IPFS etc.) and adding API for Feed Readers.</li>
    </ul>
  </div>
  <span class="decor"></span>
  <div id="xmpp" class="segment">
    <h1>💡️ XMPP: The universal messaging standard</h1>
    <h2>Tried and tested. Independent. Privacy-focused.</h2>
    <p>XMPP is the open standard for messaging and presence.</p>
    <p>Not only XMPP is a decentralized, private, secure and robust messaging platform, but it is also a platform to communicate and transfer anything digital, from sharing files to HTML pages and much more.</p>
    <li>
      <a href="https://www.ietf.org/archive/id/draft-saintandre-atompub-notify-07.html">Atomsub</a>
      <p>Transporting Atom Notifications over the Publish-Subscribe Extension to the Extensible Messaging and Presence Protocol (XMPP) (May 08, 2008)</p>
    </li>
    <li>
      <a href="https://datatracker.ietf.org/meeting/66/materials/slides-66-atompub-1.pdf">Atom Over XMPP</a>
      <p>A Presentation about Atom Over XMPP and how it relates to PubSub.</p>
    </li>
    <li>
      <a href="https://datatracker.ietf.org/doc/draft-saintandre-atompub-notify/">Atomsub</a>
      <p>Transporting Atom Notifications over the Publish-Subscribe Extension to the Extensible Messaging and Presence Protocol (XMPP)</p>
    </li>
    <li>
      <a href="https://xmpp.org/extensions/xep-0472.html">XEP-0472: Pubsub Social Feed</a>
      <p>This specification defines a way of publishing social content over XMPP.</p>
    </li>
    <li>
      <a href="https://xmpp.org/extensions/xep-0277.html">XEP-0277: Microblogging over XMPP</a>
      <p>This specification defines a method for microblogging over XMPP.</p>
    </li>
    <li>
      <a href="https://movim.eu/">Movim</a>
      <p>Responsive HTML-based cross-platform XMPP client.</p>
    </li>
    <li>
      <a href="https://xmpp.org/">XMPP</a>
      <p>Get to know XMPP for ideal communication experience.</p>
    </li>
    <li>
      <a href="https://joinjabber.org/">Join Jabber</a>
      <p>The inclusive place of the Jabber network.</p>
    </li>
    <li>
      <a href="https://join.movim.eu/">Join Movim</a>
      <p>The social platform shaped for your community …and that federates with the others.</p>
    </li>
  </div>
  <span class="decor"></span>
  <div id="force" class="segment">
    <h1>👨‍✈️ Welcome Aboard</h1>
    <h2>We Are RSS Task Force</h2>
    <p>We are glad you have made it here.</p>
    <p>We are a unified, undefined and united group of people of all creeds and races from all over the world.</p>
    <p>We originally formed the RSS Task Force in order to maintain, serve and improve data flow to and from small and medium enterprises, and since 2021 we have expanded our cause towards all entities of all types and sorts, including individuals with disabilities.</p>
    <p>Albeit the RSS Task Force is using "RSS" for reference, we recommend you to utilize The Atom Syndication Format for publishing syndication feeds.</p>
    <p>The RSS Task Force was founded in 2018.</p>
  </div>
  <span class="decor"></span>
  <div id="disclaimer" class="segment">
    <h1>🧑‍⚖️ Disclaimer</h1>
    <h2>As If I Have A Choice</h2>
    <h3>Anthony Novak</h3>
    <p>After the unfortunate conclusion of Anthony Novak v. City of Parma, this project is legally coerced to advise that any content made here is within the frames of parody or works of fiction. The posts are not real reflections of the true beliefs held by any member of the team. We are not responsible for nor are we able to control how you react to this content.</p>
    <ul>
      <li><a href="https://www.supremecourt.gov/search.aspx?filename=/docket/DocketFiles/html/Public/22-293.html">Anthony Novak, Petitioner v. City of Parma, Ohio, et al.</a></li>
      <li><a href="https://law.justia.com/cases/federal/appellate-courts/ca6/21-3290/21-3290-2022-04-29.html">Novak v. City of Parma, Ohio, No. 21-3290</a> (6th Cir. 2022)</li>
      <li><a href="https://ij.org/case/novak-v-parma/">Ohio Man Arrested and Prosecuted for a Joke Appeals to Supreme Court</a></li>
    </ul>
    <h3>Technicality</h3>
    <p>Some of the contents presented here, in part, are merely in the frame of <i>external</i> analyses of the last couple of decades in the realm of the internet and the brands that were once great (i.e. major) in the internet.</p>
    <p>Nothing in this document may be given as a fact, and everything must be taken at face-value and as a satiric content in nature for entertainment purposes only.</p>
    <p>Fact checking, if is a concern, must be done each to oneself.</p>
    <p>We advise you to do your own.</p>
    <p>God Bless!</p>
  </div>
  <span class="decor"></span>
  <div id="memory" class="segment">
    <h1>🎖️ In Memory Of Mr. Anderson</h1>
    <h2>Rest In Peace</h2>
    <!-- h2>🌤️ Rest In Peace</h2 -->
    <p><a href="https://www.findagrave.com/memorial/143601007/alex-james-anderson">Alex James Anderson</a> (1992-2015) was a good friend of mine, albeit we have never met in person.</p>
    <p>Alex is the one who has encouraged and petitioned me to continue and improve an older syndication project called StreamBurner.</p>
    <p>Without Alex, StreamBurner and this project would not exist in their current forms.</p>
    <span id="personal">
    <p>Alex,</p>
    <p>it is sad for me to have you taken from this world so soon, and it is sad for me that you are no longer with us.</p>
    <p>I am wishing you and your family the best.</p>
    <p>In the hope to seeing you in the next world,</p>
    <p>Schimon</p>
    </span>
  </div>
  <div id="buttons">
    <button class="back-to-menu">Menu</button>
    <button class="return-to-feed">Return</button>
  </div>
</div>`,
  helpGecko = `
<div id="open-in-browser" class="segment">
  <h1>🧩 Open in Browser (Rule Set)</h1>
  <div class="content">
    <ol>
      <li><a href="https://addons.mozilla.org/firefox/addon/open-in-browser/">Install</a> Open in Browser;</li>
      <li>Open preferences of Open in Browser;</li>
      <li>Click Import.</li>
      <li>Import the following <span class="cursor-pointer" id="open-in-browser-rules"><u>set of rules</u></span>.</li>
    </ol>
  </div>
</div>
<div id="gecko" class="segment">
  <h1>⚙️ Enable JSON-based Feeds</h1>
  <div class="content">
    <ol>
      <li>Navigate to <b>about:config</b>;</li>
      <li>Set <b>devtools.jsonview.enabled</b> to <b>false</b>.</li>
    </ol>
  </div>
</div>`,
// Arbitrary rule doesn't work
// document.contentType text/xml
// Test pages: TPFC and Fastly Blog
  ruleSetOpenInBrowser = `
{
  "mime-mappings": {
    "application/atom+xml": "1text/plain",
    "application/rss+xml": "1text/plain",
    "application/rdf+xml": "1text/plain",
    "application/feed+json": "1text/plain",
    "application/x-atom+xml": "1text/plain",
    "application/x-rss+xml": "1text/plain",
    "application/x-rdf+xml": "1text/plain",
    "application/xml": "1text/plain",
    "text/xml": "1text/plain"
  },
  "sniffed-mime-mappings": {
    "application/atom+xml": "1text/plain",
    "application/rss+xml": "1text/plain",
    "application/rdf+xml": "1text/plain",
    "application/feed+json": "1text/plain",
    "application/x-atom+xml": "1text/plain",
    "application/x-rss+xml": "1text/plain",
    "application/x-rdf+xml": "1text/plain",
    "application/xml": "1text/plain",
    "text/xml": "1text/plain"
  },
  "text-nosniff": false,
  "octet-sniff-mime": true,
  "override-download-type": false
}`,
  helpHeaderEditor = `
<div id="header-editor" class="segment">
  <h1>🧩 <b>Header Editor (Rule Set)</h1>
  <div class="content">
  <ol>
    <li><a id="header-editor-install">Install</a> Header Editor;</li>
    <li>Click on button Header Editor;</li>
    <li>Manage > Export and Import > Import;</li>
    <li>Import the following <span class="cursor-pointer" id="header-editor-rules"><u>set of rules</u></span>.</li>
  </ol>
  </div>
</div>
</div>`,
  ruleSetHeaderEditor = `
{
  "request": [],
  "sendHeader": [],
  "receiveHeader": [
    {
      "enable": true,
      "name": "Set Content Type Plain Text",
      "ruleType": "modifyReceiveHeader",
      "matchType": "all",
      "pattern": "",
      "exclude": "",
      "group": "Streamburner",
      "isFunction": false,
      "action": {
        "name": "content-type",
        "value": "text/plain"
      },
      "code": ""
    }
  ],
  "receiveBody": []
}`,
  htmlBar = `
<div id="links-bar">
  <span id="buttons-action">
    <a id="subscribe" class="subscribe-link" title="Subscribe to get the latest updates and news">Follow</a>
    <!-- a class="cursor-pointer" id="service" title="Subscribe online">Handler</a -->
    <!-- a id="service" title="Subscribe online" href="https://www.subtome.com/#/subscribe?feeds=${location.href}">SubToMe</a -->
    <a class="homepage-link" title="Visit homepage" href="javascript:location.href = location.protocol + '//' + location.hostname">Home</a>
    <!-- span class="cursor-help" id="about-support" title="Learn how you can support">Support</span -->
    <span id="buttons-control">
      <span id="previous" title="Previous item (Ctrl + Shift + Key Up)">❰</span>
      <span id="next" title="Next item (Ctrl + Shift + Key Down)">❱</span>
      <span id="mode" title="Dark mode">💡</span>
      <span id="decrease" title="Decrease text size">- 𝐚</span>
      <span id="increase" title="Increase text size">+ 𝐀</span>
      <span id="direction" title="Change text direction">𝐓</span>
      <span id="about-settings" title="Newspaper settings">⚙️</span>
      <!-- span id="about-help" title="Learn about syndication feed and how you can help">⁝⁝⁝⁝⁝</span -->
    </span>
  </span>
</div>`,
  htmlEmpty = `
<div class="notice no-entry" id="empty-feed">
  <h3>This news feed is empty</h3>
  <p>You are advised to contact the site administrators, and ask them to maintain standard “Atom Syndication 1.0” feeds.</p>
  <!-- div>You might want to address them to <a href="https://aboutfeeds.com">aboutfeeds.com</a>.</div -->
  <p>Below is a contact link with possible emails; Use it only in case there is no contact address and nor form is available on this site.</p>
  <!-- span class="decor"></span -->
</div>`,
  htmlError = `
<div class="notice no-entry" id="empty-feed">
  <h3>This XML news feed is not-well-formed</h3>
  <p>You are advised to contact the site administrators, and ask them to fix this feed.</p>
  <p>Below is a contact link with possible emails; Use it only in case there is no contact address and nor form is available on this site.</p>
  <!-- span class="decor"></span -->
</div>`,
    cssFileBar = `
#top-navigation-button {
  display: flex; }

#links-bar {
  margin: auto;
  outline: .1em solid;
  width: 100%;
  /* max-width: 70%; */
  direction: ltr;
  text-align: center;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  color: WhiteSmoke;
  background: #555; /* #eee */
  white-space: nowrap;
  overflow: scroll;
  scrollbar-width: none; /* Gecko */
  -ms-overflow-style: none;  /* Edge */
  z-index: 1;
  /* border-radius: unset; */
  /* border-bottom: unset; */
  /* max-height: 44.5px; */ /* TODO FIXME links-bar */ }

#links-bar::-webkit-scrollbar {  /* Falkon and Otter */
  display: none; }

#buttons-control,
#buttons-action a {
  color: WhiteSmoke;
  /* font-style: italic; */
  font-family: system-ui;
  /* NOTE Shouldn't this be max-width? */
  /* min-width: 100px; */
  margin: 6px; }

/*
#buttons-action {
  float: left; }

#buttons-control {
  float: right; }
*/

#buttons-control span {;
  min-width: 5%; }

#buttons-action #subscribe,
#buttons-control {
  /* border-left-style: unset; */
  border-right-style: solid;
  border-radius: 0.5em;
  color: #555;
  background: WhiteSmoke;
  font-weight: bold; }`,
    cssFileLTR = `
#webring {
  background: floralwhite;
  border-radius: 9px;
  user-select: none;
  padding: 2px; }

html, body {
  padding: 0;
  margin: 0;
  overflow-x: hidden; }

body {
  background: WhiteSmoke;
  color: #333;
  hyphens: auto;
  /* font-family: serif; */ }

/*
a {
  color: WhiteSmoke; }
*/

#feed a.dark {
  color: WhiteSmoke; }

#feed a {
  color: #333; }

#feed {
  /*
  width: 98%;
  margin: auto;
  position: relative;
  overflow-x: hidden;
  */
  margin: 0 -1em 1em -1em;
  margin-bottom: 1em;
  padding: 1em 1em 0 1em; }

#feed a {
  display: inline-block; }

#feed h3.title > a {
  display: block;
  padding-top: 1.5em;}

.entry p {
  margin-right: 10px;
  margin-left: 10px;
  padding-right: 10px;
  padding-left: 10px; }

#logo {
  display: inline-block;
  float: left;
  overflow: hidden;
  position: relative;
  height: 60px;
  width: 60px;
  margin-right: 9;
  padding-top: 12; }

#logo > a > img {
  margin: auto;
  max-width: 100%;
  position: absolute;
  width: 5em;
  bottom: 0;
  right: 0;
  left: 0;
  top: 0; }

#title { /* TODO tag </title-page> */
  border-bottom: 1px solid;
  width: 90%;
  margin: auto;
  font-variant: small-caps;
  text-align: center;
  font-weight: bold;
  font-size: 3em;
  overflow: hidden;
  -webkit-line-clamp: 2; }

#title .empty:before {
  font-variant: small-caps;
  content: 'Streamburner News Dashboard';
  text-align: center; }

#subtitle {
  /* border-top: 1px solid; */
  width: 90%;
  margin: auto;
  overflow: hidden;
  -webkit-line-clamp: 2;
  white-space: wrap; /* FIXME Invalid Value */
  text-align: center;
  font-variant: all-small-caps;
  font-weight: normal;
  font-size: 1.5em; }

.container {
  display: flex; }

#links-bar {
  font-family: system-ui;
  /* cursor: default; */
  display: block;
  margin: auto;
  margin-bottom: 1em;
  margin-top: 1em;
  width: 96%;
  text-align: center;
  direction: ltr;
  /* font-size: 90%; */
  /* border-radius: 2em; */
  /* border-bottom: solid; */ }

#buttons-action *,
#buttons-control {
  text-decoration: none;
  /* font-size: 70%; */
  outline: none;
  /* min-width: 12%; */
  padding: 6px;
  /* font-family: system-ui; */
  white-space: nowrap;
  /* margin: 20px; */
  margin: 6px; }

#buttons-action *:hover,
#buttons-control:hover {
  opacity: 0.9; }

#subscribe,
#buttons-control {
  font-weight: 900;
  cursor: pointer;
  background: lavender; /* honeydew */
  color: #333;
  border-color: grey;
  border-left-style: solid;
  border-radius: 0.5em; /* 2em 40% */
  /*
  border-top-left-radius: 2em;
  border-bottom-left-radius: 2em;
  */
  /* min-width: 12%; */ }

#buttons-control {
  cursor: default;
  border-left-style: unset;
  border-right-style: solid; }

#buttons-control span {
  outline: none;
  /* min-width: unset; */
  display: inline-block;
  margin-right: 5px;
  /* margin-left: 5px; */
  padding-right: 5px;
  padding-left: 5px; }

/* character ❱

#buttons-control #next {
  transform: rotate(90deg); }

#buttons-control #previous {
  transform: rotate(-90deg);
  margin-left: unset; }
*/

/*
#buttons-control #next:after,
#buttons-control #previous:after {
  content: '';
  border: solid;
  padding: 5px;
  border-width: 1px 0 0 1px;
  position: absolute; }

#buttons-control #next:after {
  transform: rotate(-135deg); }

#buttons-control #previous:after {
  transform: rotate(45deg); }
*/

#buttons-control #mode {
  filter: saturate(7); }

.cursor-pointer {
  cursor: pointer; }

.cursor-help {
  cursor: help; }

#toc {
  margin-left: 5%;
  margin-right: 5%;
  padding: 5px; }

#toc:before {
  content: 'List of entries'; }

#toc > a,
#toc:before {
  content: 'List of entries';
  /* font-size: 76%; */
  font-weight: bold; }

#toc li:first-child,
#toc > a {
  margin-top: 1em; }

#toc a {
  /* font-size: 66%; */
  display: block;
  outline: none;
  padding: 5px 0;
  margin-left: 1%;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  text-decoration: none;
  /* display: list-item; */ }

#toc a:hover {
  /* overflow: unset; */
  white-space: unset; /* break-spaces */
  text-decoration: underline; }

#toc a:visited {
  text-decoration: line-through; }

/*
#toc a:first-child {
  margin-top: 1em; }

#toc a:hover {
  text-decoration: underline; }

#toc a:visited {
  text-decoration: line-through; }
*/

.expand {
  cursor: pointer; }

.expand:hover {
  text-decoration: underline; }

.about-newspaper { /* overlay */
  font-family: system-ui;
  font-style: initial;
  position: fixed;
  display: none;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  color: WhiteSmoke;
  background-color: #555;
  /* background-color: #ffff9b; */
  z-index: 2;
  overflow-y: auto;
  text-align: left; /* justify */
  direction: ltr;
  padding: 5%;
  line-height: 1.8;
  font-size: 110%;
  cursor: unset; }

.about-newspaper div {
  margin-bottom: 1em; }

.about-newspaper a,
.about-newspaper span, {
  color: WhiteSmoke; }

.feed-url,
.feed-category,
.category a,
.subcategory a {
  text-decoration: none; }

.category a:hover,
.subcategory a:hover {
  text-decoration: underline; }

/*
a:hover {
  text-decoration: underline !important; }
*/

.about-newspaper a {
  color: WhiteSmoke;
}

.about-newspaper #buttons-custom {
  margin: auto;
  margin-top: 1em;
  outline: .1em solid;
  /* outline-color: #333; */
  text-align: center;
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  background: WhiteSmoke;
  color: #333;
  display: block;
  font-size: smaller;
  direction: ltr; }

.about-newspaper #buttons-custom > span {
  outline: none;
  min-width: 12%;
  padding: 6px;
  margin: 6px;
  /* font-family: system-ui; */ }

.quote {
  margin: auto;
  max-width: 500px; }

#feed-quote,
.about-newspaper .quote {
  text-align: center; /* right */
  font-size: 85%;
  font-style: italic; }

#feed-quote {
  font-size: 85%;
  margin-bottom: 35px; }

#feed-quote:after {
  content: '· · • · ·'; }

.about-newspaper .text-icon {
  font-weight: bold;
  border-radius: 11px;
  padding-top: 3px;
  padding-bottom: 3px;
  padding-right: 5px;
  padding-left: 5px; }

.about-newspaper .orange {
  background: darkorange; }

.about-newspaper #torrents {
  outline: none; }

.about-newspaper #services > a:after,
.category > a:after,
.subcategory > a:after {
  content: ', '; }

.about-newspaper #services > a:last-child:after,
.category > a:last-child:after,
.subcategory > a:last-child:after {
  content: '.'; }

.about-newspaper #filter {
  /* margin-right: auto;
  margin-left: auto; */
  margin-top: 25px; }

.about-newspaper .filter {
  font-weight: bold;
  outline: none;
  border-bottom: 2px solid WhiteSmoke;
  background: WhiteSmoke;
  color: #555;
  border-radius: 5%;
  /* border-bottom-right-radius: unset; */
  /* border-bottom-left-radius: unset; */
  margin-right: 15px;
  padding: 5px;
  width: 10%;
  cursor: pointer; }

.about-newspaper .center {
  text-align: center; }

.about-newspaper .background {
  background: #666;
  border-radius: 1em;
  padding: 5px; }

.about-newspaper .hide {
  display: none; }

.about-newspaper .grey {
  background: inherit;
  color: inherit; }

/*
.about-newspaper .recom {
  filter: drop-shadow(2px 4px 6px pink); }
*/

#software .recom:before {
  font-size: 80%;
  content: '🔖 '; }

#blog .recom:after,
#services-publish .recom:after {
  font-size: 80%;
  content: '🔖 '; }

.about-newspaper .category > div:first-child {
  font-size: 110%;
  font-weight: bold;
  margin-top: 25px; }

.about-newspaper .subcategory > div {
  font-weight: bold;
  /* text-decoration: underline; */ }

.about-newspaper .subcategory > div:before {
  content: '* '; }

.about-newspaper #postscript + div p {
  font-style: italic; }

/*
#feeds > div.content a:link {
  text-decoration: none; }
*/

#services-feed a {
  text-decoration: none; }

#feeds > div.content .category a:before,
#services-feed a:before {
  font-size: 80%;
  content: '🏷️ '; } /* 🧧 🔗 */

#articles {
  justify-content: space-between;
  max-width: 90%;
  margin: 0 auto;
  padding: 10px 0; }

#articles > * {
  margin: .5em;
  white-space: normal;
  vertical-align: top;
  margin-bottom: 50px; }

#articles * {
  /* max-width: -webkit-fill-available; */
  max-width: 100%; }

.entry {
   /*border-bottom: inset;
  border-bottom: groove; */
  margin-left: auto;
  margin-right: auto;
  overflow: auto;
  line-height: 1.6;
  /* font-size: 85%; */
  /* overflow-x: hidden; */
  max-width: 98%;
  /* outline: auto; */
  outline: none;
  padding: 4px;
  /* overflow-wrap: break-word; */
  word-break: break-word; }

.entry:last-child {
  border-bottom: unset; }

.entry:hover {
  /* background: #f8f9fa; */
  /* outline: none; */ }

.entry > a {
  white-space: normal; }

.decor {
  /* border-top: inset; */
  /* border-top: groove;
  width: 30%; */
  /* padding-right: 30%;
  padding-left: 30%; */
  margin-right: 30% !important;
  margin-left: 30% !important;
  padding-top: 1.5em !important;
  padding-bottom: 1.5em !important;
  text-align: center;
  /* text-decoration: overline; */
  display: block; }

.decor:after {
  /* content: '∽ ✦ ∼' */
  /* content: '· · ✦ · ·'; */
  content: '· · • · ·'; } /* ✦ ✧ ۞ ⍟ ⍣ ✹ ✸ ✴ ✶ ✵ ✷ */

.title {
  cursor: pointer;
  display: inline-block;
  font-size: 150%;
  font-weight: bold;
  text-decoration: underline;
  overflow-wrap: anywhere;
  /* overflow: visible;
  text-overflow: ellipsis; */
  font-variant: small-caps;
  margin: 0; }

/*
.title > a {
  text-decoration: none; }

.title > a:hover {
  text-decoration: underline; }
*/

.geolocation > a {
  text-decoration: none;
  padding-left: 6px; }

.author {
  /* font-size: 75%; */
  font-weight: bold;
  margin: 0 auto 0 auto;
  text-decoration: none; }

.author:before {
  font-weight: normal;
  content: 'Posted by '; }

/*
.author:after {
  content: ' / '; }
*/

.published, .updated {
  /* font-size: 75%; */
  margin: 0 auto 0 auto;
  /* direction: ltr; */ }

.content {
  margin: 15px auto 15px 1%;
  inline-size: 95%;
  text-indent: 3px; }

.content-text {
  white-space: pre-wrap; }

.content[type='text'] {
  font-family: monospace; }

.content * {
  /* max-width: 96%; */
  object-fit: contain;
  height: auto; }

img, svg {
  margin: 1em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  display: block;
  /* border: 4px solid #555; */
  border-radius: 0.5em;
  /* min-width: 96%; */
  max-width: 96%;
}

video {
  border-radius: 0.5em;
  outline: none;
}

iframe {
  display: block;
  border-radius: 0.5em;
  width: 96%;
  min-height: 70vw;
}

/* TODO Test <pre> */
code, pre {
  color: WhiteSmoke !important;
  background: #555 !important;
  overflow: auto;
  /* display: inline-flex; */
  /* display: inline-block; */
  max-height: 100%;
  border-radius: 4px;
  max-width: 100%; }

code *, pre * {
  color: WhiteSmoke !important;
  background: #555 !important; }

.enclosures {
  background: #eee;
  border: 1px solid GrayText;
  border-radius: 4px;
  clear: both;
  color: #525c66;
  cursor: help;
  direction: ltr;
  font-size: .8em;
  margin: 5px auto 15px 1%;
  padding: 15px;
  vertical-align: middle;
  /* border: 1px solid #aaa; */
  border-radius: .5em;
  max-width: 100%;
  border-left: double;
  padding: 1em; }

.enclosure a {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  text-decoration: none; }

.enclosure {
  display: flex; }

.enclosure > a:hover {
  text-decoration: underline; }

.enclosure > * {
  white-space: nowrap;
  margin: 3px; }

.enclosure > span:after {
  content: ' (Document file) '; }

.enclosure > span[icon]:after {
  content: '📄️';
  margin: 3px; }

.enclosure > span.executable:after{
  content: ' (Executable file) '; }

.enclosure > span[icon='executable']:after {
  content: '📦️';
  margin: 3px; }

.enclosure > span.image:after {
  content: ' (Image file) '; }

.enclosure > span[icon='image']:after {
  content: '🖼️';
  margin: 3px; }

.enclosure > span.audio:after {
  content: ' (Audio file) '; }

.enclosure > span[icon='audio']:after{
  content: '🎼️';
  margin: 3px; }

.enclosure > span.video:after {
  content: ' (Video file) '; }

.enclosure > span[icon='video']:after {
  content: '📽️';
  margin:3px; }

.enclosure > span[icon='atom']:after {
  content: '📰';
  margin:3px; }

.enclosure > span[icon='html5']:after {
  content: '📰';
  margin:3px; }

.enclosure > span[icon='rss']:after {
  content: '📰';
  margin:3px; }

.notice {
  text-align: center;
  display: block;
  /* font-size: 130%; */
  /* font-weight: lighter; */
  font-variant-caps: all-small-caps;
  color: FireBrick; }

.warning {
  display: block;
  font-size: 85%; /* 60 */
  font-weight: bold;
  color: DarkRed; }

.atom1.author:after {
  content: 'Atom 1.0 Warning: Element </author> is missing'; }

.atom1.id:after {
  content: 'Atom 1.0 Warning: Element </id> is missing'; }

.atom1.link:after {
  content: 'Atom 1.0 Warning: Element </link> is missing'; }

.atom1.published:after {
  content: 'Atom 1.0 Warning: Element </published> is missing'; }

.atom1.title:after {
  content: 'Atom 1.0 Warning: Element </title> is missing'; }

.rss2.description:after {
  content: 'RSS 2.0 Warning: Element </description> is missing'; }

.rss2.link:after {
  content: 'RSS 2.0 Warning: Element </link> is missing'; }

.rss2.title:after {
  content: 'RSS 2.0 Warning: Element </title> is missing'; }

abbr,acronym {
  border-bottom: 1px dotted #c30; }

dt {
  font-weight: bold; }

#about-toc {
  display: grid;
  /* border-bottom: inset;
  text-align: right;
  width: 70%;
  margin-left: 30%; */ }

#about-toc li > a,
#feeds li a {
  /* display: list-item; */
  display: block; }

#about-toc > li > a {
  text-decoration: none; }

#about-toc > li > a:hover {
  text-decoration: underline; }

#empty-feed h3 {
  font-size: 135%; }

#empty-feed p {
  font-size: 120%; }

#empty-feed a {
  font-size: 100%; }

#empty-feed {
  direction: ltr;
  width: 75%;
  max-width: 550px;
  margin: auto; }

#empty-feed .subject,
.about-newspaper .subject {
  font-size: 130%;
  font-weight: bold;
  padding-bottom: 5px;
  display: block; }

.about-newspaper .subtitle {
  font-weight: bold;
  /* font-style: italic; */
  font-size: 110%; }

.about-newspaper .cyan {
  font-weight: bold;
  color: cyan; }

.about-newspaper .content {
  margin-bottom: 3em;
  white-space: unset; }

.about-newspaper .orange-color {
  color: orange;
  margin-right: 5px; }

.about-newspaper .red-color {
  color: red; }

.about-newspaper .lizard {
  filter: hue-rotate(250deg); }

.about-newspaper .redice {
  filter: hue-rotate(170deg); }

.about-newspaper #personal {
  font-style: italic; }

#info-square {
  direction: ltr;
  position: fixed;
  margin: auto;
  bottom: 0;
  right: 0;
  left: 0;
  /* top: 33px; */
  padding: 3px;
  color: WhiteSmoke;
  background: #555;
  /* border-radius: 50px;
  width: 50%;
  font-size: 85%; */
  /* font-style: italic; */
  font-family: system-ui;
  /* justify-content: center; */
  align-items: center;
  display: flex;
  text-overflow: ellipsis;
  overflow: hidden;
  /* white-space: pre; in case we have html tags */
  white-space: nowrap; }

#info-square > * {
  color: WhiteSmoke;
  margin-left : 0.5em;
  margin-right : 0.5em; }

#top-navigation-button {
  text-decoration: none;
  /* set position */
  position : fixed;
  bottom : 10px;
  right : 20px;
  z-index : 1;
  /* set appearance */
  background : WhiteSmoke;
  color: #555;
  border : 2px solid #555;
  border-radius : 50px;
  /* margin : 10px; */
  min-width : 30px;
  min-height : 30px;
  font-size : 20px;
  /* opacity : 0.3; */
  /* center character */
  justify-content: center;
  align-items : center;
  display : none;
  /* disable selection marks */
  outline : none;
  /* cursor : default;
  transform: rotate(-90deg) scale(1, -1); */ }

#links-bar,
#buttons-action *,
#buttons-control,
.about-newspaper #buttons-custom > span,
.about-newspaper #buttons-custom,
.about-newspaper #buttons,
.about-newspaper .text-icon,
.about-newspaper .filter,
.decor,
#top-navigation-button,
#page-settings {
  user-select: none; }

/*
#page-settings button,
#page-settings input,
#page-settings label {
  padding: 5px; }
*/

#page-settings span {
  display: block; }

#page-settings td {
  vertical-align: initial; }

#email-link {
  margin-top: 25px;
  text-decoration: overline;
  outline: none; }

#feed-banner {
  outline: none;
  display: table;
  margin: auto;
  /* filter: drop-shadow(2px 4px 6px black); */ }

.about-newspaper #buttons {
  float: right; }

#feature-limited {
  background: indianred; }

#not-well-formed {
  background: dimgrey; /* #449 */ }

#xslt-message {
  background: darkgoldenrod; /* royalblue #2c3e50 coral */ }

.infobar-message {
  font-family: system-ui;
  color: white; /* #eee navajowhite */
  padding: 6px; /* 13px //15px //11px //9px //3px //1px */
  display: block;
  text-align: center; /* justify */
  text-decoration: none;
  user-select: none;
  direction: ltr; }

body.dark {
  background: #333; }

code.dark,
.enclosures.dark {
  background: #555; }

/* WONTFIX mainstream due to document.contentType is thought to be xml, which is not; it's html */
a.dark,
body.dark,
code.dark,
.enclosures.dark,
#empty-feed.dark {
  color: WhiteSmoke; }

#links-bar a.dark {
  color: WhiteSmoke !important; }

#links-bar #subscribe.dark,
#links-bar #buttons-control span.dark {
  color: #333 !important; }

#feed-info {
  border-bottom: 1px solid;
  width: 70%;
  margin: auto;
  font-size: 80%;
  padding: 3px;
  /* margin: 3px; */
  /* margin-top: 1em; */
  text-align: center; }

footer {
  user-select: none;
  direction: ltr;
  display: block;
  /* font-family: system-ui; */
  font-size: 70%;
  /* font-weight: lighter; */
  margin: auto;
  text-align: center;
  width: 96%;
  }

footer > *,
footer > *:hover {
  display: inline-flex;
  justify-content: center;
  text-decoration: unset;
  /* min-width: 100px; */
  color: unset;
  margin: 5px;
  }
/*
footer > *:after {
  content: '|';
  margin-left: inherit;
  }

footer > *:last-child:after {
  content: '';
  }
*/
placeholder {
  display: block;
  margin-bottom: 3em;
  }`,
  cssFileRTL = `
html, body {
  text-align: right; }

#feed {
  direction: rtl; }

#logo {
  float: right;
  margin-left: 9; }

.geolocation > a {
  padding-right: 6px; }

.image {
  float: right;
  margin-left: 40px;
  margin-right: auto; }`;

var
  cssFileBase, gmGetValue, gmSetValue, ignoreMinimumItemNumber = false,
  minimumItemNumber, wellFormed, xmlStylesheet = false;

// Check availability of Greasemonkey APIs

if (typeof GM !== 'undefined' && typeof GM.getValue === 'function') {
  gmGetValue = true;
} else {
  gmGetValue = false;
  console.warn('Greasemonkey API GM.getValue does not seem to be available');
}

if (typeof GM !== 'undefined' && typeof GM.setValue === 'function') {
  gmSetValue = true;
} else {
  gmSetValue = false;
  console.warn('Greasemonkey API GM.setValue does not seem to be available');
}

// Start processing

init = (function init() {
  checkContentType()
})();

function checkContentType() {
  let myPromise = new Promise(function(myResolve, myReject) {
    let request = new XMLHttpRequest();
    //request.overrideMimeType('text/plain');
    //request.responseType = 'text'; // ms-stream also works but both don't make a difference
    request.open('GET', document.documentURI);
    //request.setRequestHeader('Content-Type', 'text/plain;charset=UTF-8');
    //request.setRequestHeader('Content-Type', 'text/plain');
    request.onload = function() {
      if (document.URL.startsWith('file:') || request.status == 200) {
        myResolve(request);
      }
      else {
        myReject("File not Found");
      }
    };
    request.send();

    /* gmXmlhttpRequest({
      method: 'GET',
      url: document.documentURI,
      headers: {
        "Content-Type": "text/plain",
        "Accept": "text/plain"
      },
      onprogress: function(request) {
        request.responseType = 'text';
      },
      onload: function(request) {
        request.overrideMimeType = 'text/plain';
        if (document.URL.startsWith('file:') ||
            request.status == 200) {
          myResolve(request);
        }
        else {
          myReject("File not Found");
        }
      },
      onerror: function(request) {
        myReject('File not Found')
      }
    }) */
  });

  myPromise.then(
    async function(request) {

      // Read settings
      minimumItemNumber = await getMinimumItemNumber() -1;

      /*
      if (request.response.toLowerCase().includes('<?xml-stylesheet')) {
        // Apparently, this software doesn't influence server stylesheet
        // This if statement is useful to save CPU and RAM resources.
        // NOTE We can remove it using DOMParser.
        return; // exit
      }
      */
      let xmlFile;
      let domParser = new DOMParser();
      xmlFile = domParser.parseFromString(request.response.trim(), 'text/xml');
//    orgFile = domParser.parseFromString(request.response, 'text/xml');
//    /questions/6334119/check-for-xml-errors-using-javascript
//    console.error(orgFile.documentElement.nodeName == 'parsererror' ? 'error while parsing' : orgFile.documentElement.nodeName);
      wellFormed = xmlFile.getElementsByTagName('parsererror').length ? 
        (new XMLSerializer()).serializeToString(xmlFile) : 'This XML is well-formed.';
      if (wellFormed != 'This XML is well-formed.') {
        console.error('This XML is not-well-formed.');
      }

      // TODO Preference to respect or override stylesheet
      // TODO Ignore all stylesheets if all are CSS
      // TODO Infobar suggesting to render with Streamburner ?streamburner=1
      // TODO Infobar suggesting to disable (watch without) Streamburner ?streamburner=0 <-- do this
      if (xmlFile) {

        //let xmlStylesheet;
        for (childNode of xmlFile.childNodes) {
          if (childNode.target == 'xml-stylesheet') {
            childNode.remove();
            xmlStylesheet = true;
            //return; // exit
          }
        }

/*
        // TODO Configuration to override existing stylesheet
        if (override) {
          if (xmlFile.firstChild.nodeName == "xml-stylesheet") {
            console.log(xmlFile.firstChild)
            xmlFile.firstChild.remove();
          }
        } else {
          return; // exit
        }
*/

/*
        // Remove node of type comment
        // Because of this code below
        if (xmlFile.childNodes[0] == xmlFile.querySelector('feed')) {
          while (xmlFile.firstChild.nodeName == '#comment') {
            xmlFile.firstChild.remove(); // xmlFile.childNodes[0]
          }
        }
*/

/*
        // Remove all nodes of type comment
        nodeIterator = xmlDoc.createNodeIterator(
          xmlDoc,  // Starting node, usually the document body
          NodeFilter.SHOW_ALL,  // NodeFilter to show all node types
          null,  
          false  
        );

        let currentNode;
        // Loop through each node in the node iterator
        while (currentNode = nodeIterator.nextNode()) {
          // Do something with each node
          console.log(currentNode.nodeName);
        }
*/

        switch (xmlFile.firstElementChild) {
        // <feed xmlns="http://www.w3.org/2005/Atom">
        // xmlFile.getElementsByTagNameNS('http://www.w3.org/2005/Atom','feed')
        case xmlFile.querySelector('feed'):
          pageLoader();
          newDocument = renderXML(xmlFile, atomRules);
          //aboutInfo(xmlFile, rdfRules);
          newDocument = feedInfoXML(
            newDocument,
            xmlFile,
            atomRules,
            'Atom Syndication Format 1.0'); // Atom Syndication Feed 1.0
          newDocument = await preProcess(newDocument);
          placeNewDocument(newDocument);
          await postProcess();
          break;
        // Netscape RSS 0.91 <!DOCTYPE rss SYSTEM "http://my.netscape.com/publish/formats/rss-0.91.dtd">
        // Userland RSS 0.91 <rss version="0.91">
        // RSS 0.92 <rss version="0.92">
        // RSS 0.93 <rss version="0.93">
        // RSS 0.94 <rss version="0.94">
        // RSS 2.0 <rss version="2.0">
        case xmlFile.querySelector('rss'):
          pageLoader();
          newDocument = renderXML(xmlFile, rssRules);
          //aboutInfo(xmlFile, rdfRules);
          // FIXME https://www.elegislation.gov.hk/verified-chapters!en.rss.xml
          if (rssVersion = xmlFile.firstElementChild.getAttribute('version')) {
            newDocument = feedInfoXML(
              newDocument,
              xmlFile,
              rssRules,
              `RSS ${rssVersion}`);
          } else {
            newDocument = feedInfoXML(
              newDocument,
              xmlFile,
              rssRules,
              `RSS`); // RSS Syndication Feed 2.0
          }
          newDocument = await preProcess(newDocument);
          placeNewDocument(newDocument);
          await postProcess();
          break;
        // TODO Check by namespace xmlns
        // https://yaxim.org/doap/yaxim.rdf.xml
        // https://wiki.gnome.org/action/rss_rc/Home?action=rss_rc&unique=1&ddiffs=1
        // https://web.resource.org/rss/1.0/schema.rdf
        // RSS 0.90 <rdf:RDF xmlns="http://my.netscape.com/rdf/simple/0.9/">
        // RSS 1.0 <rdf:RDF xmlns="http://purl.org/rss/1.0/">
        // NOTE firstElementChild test page https://web.resource.org/rss/1.0/
        // xmlFile.getElementsByTagNameNS('http://www.w3.org/1999/02/22-rdf-syntax-ns#', 'RDF');
        case xmlFile.getElementsByTagName("rdf:RDF")[0]: // RDF Vocabulary
          switch (xmlFile.firstElementChild.getAttribute('xmlns')) {
            case 'http://my.netscape.com/rdf/simple/0.9/':
            case 'https://web.resource.org/rss/1.0/': // TODO TEST
            case 'http://purl.org/rss/1.0/':
            pageLoader();
            newDocument = renderXML(xmlFile, rdfRules);
            //aboutInfo(xmlFile, rdfRules);
            switch (xmlFile.firstElementChild.getAttribute('xmlns')) {
              case 'https://web.resource.org/rss/1.0/':
              case 'http://purl.org/rss/1.0/':
                newDocument = feedInfoXML(
                  newDocument,
                  xmlFile,
                  rdfRules,
                  'RSS 1.0');
                break;
              case 'http://my.netscape.com/rdf/simple/0.9/':
                newDocument = feedInfoXML(
                  newDocument,
                  xmlFile,
                  rdfRules,
                  'RSS 0.9');
                break;
            }
            newDocument = await preProcess(newDocument);
            placeNewDocument(newDocument);
            await postProcess();
          }
          break;
        case xmlFile.querySelector('opml'):
          pageLoader();
          // dateCreated http://source.scripting.com/?format=opml&streamburner_active=0
          newDocument = renderOPML(xmlFile, opmlRules);
          //aboutInfo(xmlFile, rdfRules);
          newDocument = feedInfoXML(
            newDocument,
            xmlFile,
            opmlRules,
            'OPML Outline'); // OPML
          newDocument = await preProcess(newDocument);
          placeNewDocument(newDocument);
          await postProcess();
          break;
        case xmlFile.getElementsByTagName("smf:xml-feed")[0]:
          pageLoader();
          newDocument = renderXML(xmlFile, smfRules);
          //aboutInfo(xmlFile, rdfRules);
          newDocument = feedInfoXML(
            newDocument,
            xmlFile,
            smfRules,
            'Simple Machines Forum'); // SMF
          newDocument = await preProcess(newDocument);
          placeNewDocument(newDocument);
          await postProcess();
          break;
        }
        // FIXME
        // This appears to be a not usuable Atom feed
        // Either make it usable or invalidate it
        // https://dbpedia.org/data/Searx.atom
        // FIXME Parse Friendica entry
        // https://libranet.de/display/feed-item/171774921.atom
        // FIXME Parse Friendica entry
        // https://venera.social/display/feed-item/99550546.atom
      }

      // Information of request
      //console.info(xmlFile);
      //console.info(document);
      //console.info(`all headers: ${request.getAllResponseHeaders()}`);
      //console.info(`content-type header: ${request.getResponseHeader('content-type')}`);
      //console.info(`content-type document: ${document.contentType}`);

      // errorPage is a good idea to promote Falkon
      //setTimeout(function(){renderFeed(request.response)}, 1500); // timeout for testing

      try {
        if (JSON.parse(request.response)) {
          let jsonFile = JSON.parse(request.response);
          if (jsonFile.version) {
            // FIXME TODO Handle empty feed https://jblevins.org/index.json
            if (jsonFile.version.toLowerCase().includes('jsonfeed.org')) {
              pageLoader();
              //setTimeout(function(){renderJSONFeed(jsonFile)}, 1500);
              newDocument = renderJSONFeed(jsonFile);
              newDocument = feedInfoJSON(
                newDocument,
                jsonFile,
                jsonFile.home_page_url,
                jsonFile.generator,
                jsonFile.version,
                jsonFile.items[0].date_published,
                'JSON Feed');
              newDocument = await preProcess(newDocument);
              placeNewDocument(newDocument);
              await postProcess();
            }
          } else
          if (jsonFile.generator) {
            if (jsonFile.generator.toLowerCase().includes('statusnet') || // TODO Case insensitive
                jsonFile.generator.toLowerCase().includes('gnu social')) {
              pageLoader();
              newDocument = renderActivityStream(jsonFile);
              newDocument = feedInfoJSON(
                newDocument,
                jsonFile,
                //jsonFile.items[0].id, // NOTE Not good. This is done so that infoSquare will load
                location.protocol + '//' + location.hostname,
                jsonFile.generator,
                jsonFile.generator,
                jsonFile.items[0].published,
                'ActivityStream');
              newDocument = await preProcess(newDocument);
              placeNewDocument(newDocument);
              await postProcess();
            }
          } else
          if (jsonFile.rss) {
            if (jsonFile.rss.version.toLowerCase().includes('2.0')) {
              pageLoader();
              newDocument = renderRssInJson(jsonFile.rss.channel);
              newDocument = feedInfoJSON(
                newDocument,
                jsonFile,
                jsonFile.rss.channel.link,
                jsonFile.rss.channel.generator,
                jsonFile.rss.version,
                jsonFile.rss.channel.pubDate,
                'RSS-in-JSON');
              newDocument = await preProcess(newDocument);
              placeNewDocument(newDocument);
              await postProcess();
            }
          }
          // FIXME Parse ActivityStream entry
          // https://nu.federati.net/api/statuses/show/3424682.json
        }
      } catch {
        // Not JSON
      }
    }
  );
}

/*

Test code (attempting to modify content type):

console.info(document);
request = new XMLHttpRequest();
// "false" is only used for this test
request.open('GET', document.documentURI, false);
request.overrideMimeType('text/plain');
request.setRequestHeader('content-type', 'text/plain');
request.send();
//console.info(request.response);
console.info(`all headers: ${request.getAllResponseHeaders()}`);
console.info(`content-type header:
${request.getResponseHeader('content-type')}`);
console.info(`content-type document: ${document.contentType}`);

*/

/*
(function checkContentType() {

  fetch(
    document.documentURI,
    {
      method: 'GET',
      headers: {
        "Content-Type" : "text/plain",
      },
    }
  )

  .then((response) => {
     console.info(response.headers.get('content-type'))
     //console.info(response.arrayBuffer())
     return response.arrayBuffer();
  })

  .then((data) => {
    let decoder = new TextDecoder(document.characterSet);
    let text = decoder.decode(data);

      domParser = domParser = new DOMParser();

      try {
        if (JSON.parse(text)) {
          jsonFile = JSON.parse(text);
          if (jsonFile.version) {
            if (jsonFile.version.toLowerCase().includes('jsonfeed.org')) {
              renderJSONFeed(jsonFile);
              await extensionLoader(jsonFile.feed_url); // , jsonFile, 'JSON'
            }
          } else
          if (jsonFile.generator) {
            if (jsonFile.generator.toLowerCase().includes('statusnet') || // TODO Case insensitive
                jsonFile.generator.toLowerCase().includes('gnu social')) {
              renderActivityStream(jsonFile);
              await extensionLoader(); // null, jsonFile, 'ActivityStream'
            }
          }
        }
      } catch {
        if (domParser.parseFromString(text, 'text/xml')) {
          xmlFile = domParser.parseFromString(text, 'text/xml');
          // errorPage is a good idea to promote Falkon
          if (xmlFile.querySelector('feed')) {
            renderXML(xmlFile, atomRules);
            await extensionLoader(xmlFile.querySelector('feed > link').href); // , xmlFile, 'Atom'
          } else
          if (xmlFile.querySelector('rss')) {
            renderXML(xmlFile, rssRules);
            await extensionLoader(xmlFile.querySelector('channel > link').href); // , xmlFile, 'RSS'
          }
        }
      }
  });
})();
*/

function renderActivityStream(jsonFile) {

  let newDocument = createPage();

  newDocument.title = jsonFile.title;
  if (jsonFile.language) {
    newDocument
    .documentElement
    .setAttribute('lang', jsonFile.language);
  }

  let feed = newDocument.createElement('div');
  feed.id = 'feed';

  let title = newDocument.createElement('h1');
  if (jsonFile.title) {
    title.textContent = jsonFile.title;
  } else {
    title.textContent = document.location.hostname;
  }
  title.id = 'title';
  feed.append(title);

  let subtitle = newDocument.createElement('h2');
  if (jsonFile.description) {
    subtitle.textContent = jsonFile.description;
  } else {
    subtitle.textContent = defaultSubtitle;
  }
  subtitle.id = 'subtitle';
  feed.append(subtitle);

  let toc = newDocument.createElement('ol');
  toc.id = 'toc';
  feed.append(toc);

  let articles = newDocument.createElement('div');
  articles.id = 'articles';
  feed.append(articles);

  if (jsonFile.items.length) {
    for (const item of jsonFile.items) {
    //for (let i = 0; i < jsonFile.items.length; i++) {
      let items = jsonFile.items.length;
      let index = jsonFile.items.indexOf(item) + 1;
      let titleToc = newDocument.createElement('a');
      // /questions/5002111/how-to-strip-html-tags-from-string-in-javascript
      let dateAsTitle = new Date(item.published);
      titleToc.textContent =
        item
        .actor
        .portablecontacts_net.preferredUsername
        + ' on ' +
        dateAsTitle
        .toDateString();
      //titleToc.textContent = item.content.replace(/(<([^>]+)>)/gi, "");
      //titleToc.textContent = item.actor.portablecontacts_net.preferredUsername;
      titleToc.href = `#newspaper-oujs-${index}`;
      titleToc.title = titleToc.textContent;
      let liElement = newDocument.createElement('li');
      liElement.append(titleToc)
      toc.append(liElement);

      let entry = newDocument.createElement('div');
      entry.className = 'entry';

      let link = newDocument.createElement('a');
      link.textContent =
        item
        .actor
        .portablecontacts_net.preferredUsername;
      link.href = item.url;
      //link.id = item.id;
      link.id = `newspaper-oujs-${index}`;

      title = newDocument.createElement('h3');
      title.className = 'title';
      title.append(link);
      entry.append(title);

      let date = newDocument.createElement('div');
      date.className = 'published';
      date.textContent = item.published;
      entry.append(date);

      if (item.image) {
        let image = newDocument.createElement('img');
        image.src = item.actor.image;
        entry.append(image);
      }

      let text = newDocument.createElement('div');
      text.className = 'content';
      text.innerHTML = item.content;
      entry.append(text);

      articles.append(entry);

      if (
        index > minimumItemNumber &&
        index < items &&
        !ignoreMinimumItemNumber
         )
      {
        let titleToc = newDocument.createElement('a');
        titleToc.textContent = 'See all posts >';
        titleToc.title = `This feed offers ${items} items`;
        titleToc.className = 'expand';
        toc.append(titleToc);
        articles.append(titleToc.cloneNode(true));
        break;
      }
    }
  } else {
    toc.remove(); // NOTE Redundant. See checkContentEmptiness
    articles.insertAdjacentHTML('beforeend', htmlEmpty);
  }

  newDocument.body.append(feed);
  newDocument = checkContentEmptiness(newDocument);
  return newDocument;

}

function renderRssInJson(jsonFile) {

  let newDocument = createPage();

  newDocument.title = jsonFile.title;
  if (jsonFile.language) {
    newDocument
    .documentElement
    .setAttribute('lang', jsonFile.language);
  }

  let feed = newDocument.createElement('div');
  feed.id = 'feed';

  let title = newDocument.createElement('h1');
  if (jsonFile.title) {
    title.textContent = jsonFile.title;
  } else {
    title.textContent = document.location.hostname;
  }
  title.id = 'title';
  feed.append(title);

  let subtitle = newDocument.createElement('h2');
  if (jsonFile.description) {
    subtitle.textContent = jsonFile.description;
  } else {
    subtitle.textContent = defaultSubtitle;
  }
  subtitle.id = 'subtitle';
  feed.append(subtitle);

  let toc = newDocument.createElement('ol');
  toc.id = 'toc';
  feed.append(toc);

  let articles = newDocument.createElement('div');
  articles.id = 'articles';
  feed.append(articles);

  if (jsonFile.item.length) {
    for (const item of jsonFile.item) {
      let items = jsonFile.item.length;
      let index = jsonFile.item.indexOf(item) + 1;
      let titleToc = newDocument.createElement('a');
      if (item.title) {
        titleToc.textContent =
          item
          .title
          .replace(/(<([^>]+)>)/gi, "");
      } else
      if (item.pubDate) {
        let dateAsTitle = new Date(item.pubDate);
        titleToc.textContent = dateAsTitle.toDateString();
      } else {
        titleToc.textContent = '*** No Title ***';
      }
      titleToc.textContent = titleToc.textContent
      titleToc.href = `#newspaper-oujs-${index}`;
      titleToc.title = titleToc.textContent;
      let liElement = newDocument.createElement('li');
      liElement.append(titleToc)
      toc.append(liElement);

      let entry = newDocument.createElement('div');
      entry.className = 'entry';

      let link = newDocument.createElement('a');
      if (item.title) {
        link.textContent = item.title.replace(/(<([^>]+)>)/gi, "");
      } else
      if (item.pubDate) {
        let dateAsTitle = new Date(item.pubDate);
        link.textContent = dateAsTitle.toDateString();
      } else {
        link.textContent = 'No Title';
      }
      link.href = item.link; // item['source:outline'].permalink
      //link.id = item.id;
      link.id = `newspaper-oujs-${index}`;

      title = newDocument.createElement('h3');
      title.className = 'title';
      title.append(link);
      entry.append(title);

      let date = newDocument.createElement('div');
      date.className = 'published';
      // item['source:outline'].created
      // item['source:outline'].pubDate
      date.textContent = item.pubDate; 
      entry.append(date);

      /*
      if (item['source:outline'].image) {
        let image = newDocument.createElement('img');
        image.src = item['source:outline'].image;
        entry.append(image);
      }
      */

      let text = newDocument.createElement('div');
      text.className = 'content';
      // item['source:outline'].text
      // item['source:outline'].description
      // item['source:outline'].subs (array)
      text.innerHTML = item.description;
      entry.append(text);

      articles.append(entry);

      if (
        index > minimumItemNumber &&
        index < items &&
        !ignoreMinimumItemNumber
         )
      {
        let titleToc = newDocument.createElement('a');
        titleToc.textContent = 'See all posts >';
        titleToc.title = `This feed offers ${items} items`;
        titleToc.className = 'expand';
        toc.append(titleToc);
        articles.append(titleToc.cloneNode(true));
        break;
      }
    }
  } else {
    toc.remove(); // NOTE Redundant. See checkContentEmptiness
    articles.insertAdjacentHTML('beforeend', htmlEmpty);
  }

  newDocument.body.append(feed);
  newDocument = checkContentEmptiness(newDocument);
  return newDocument;

}

function renderJSONFeed(jsonFile) {

  let feedMap = {
    "title": "title",
    "subtitle": "description",
    "language" : "language",
    "item": [{
      "title" : "title",
      "url" : ["url", "id"],
      "content" : ["content_html", "content_text"],
      "image" : "image",
      "date" : ["date_published", "date_modified"],
      "authors" : ["authors", "author"],
      "tags" : "tags",
      "language" : "language",
      "id" : "id",
      }],
    "attachments": [{
      "url" : "url",
      "mime_type" : "mime_type",
      "title" : "title",
      "size_in_bytes" : "size_in_bytes",
      "duration_in_seconds" : "duration_in_seconds"
      }],
    "homepage": "home_page_url",
    "version": "version",
    "url": "feed_url"
  };

  let newDocument = createPage();

  /*
  newDocument = domParser.parseFromString('<html></html>', 'text/html');
  elements = ['html', 'head', 'body'];
  //for (const element of elements) {
  for (let i = 1; i < elements.length; i++) {
    element = newDocument.createElement(elements[i]);
    newDocument.documentElement.append(element);
  }
  */

  newDocument.title = jsonFile.title;
  if (jsonFile.language) {
    newDocument
    .documentElement
    .setAttribute('lang', jsonFile.language);
  }

  let feed = newDocument.createElement('div');
  feed.id = 'feed';

  let title = newDocument.createElement('h1');
  if (jsonFile.title) {
    title.textContent = jsonFile.title;
  } else {
    title.textContent = document.location.hostname;
  }
  title.id = 'title';
  feed.append(title);

  let subtitle = newDocument.createElement('h2');
  if (jsonFile.description) {
    subtitle.textContent = jsonFile.description;
  } else {
    subtitle.textContent = defaultSubtitle;
  }
  subtitle.id = 'subtitle';
  feed.append(subtitle);

  let toc = newDocument.createElement('ol');
  toc.id = 'toc';
  feed.append(toc);

  let articles = newDocument.createElement('div');
  articles.id = 'articles';
  feed.append(articles);

  /* FIXME
     These couple of for-loops don't work
     Failing part: jsonFile.cellOfArray
     Uncaught (in promise) TypeError: Cannot read property '0' of undefined

  tags = ['title', 'description'];
  for (const tag of tags) {
    element = newDocument.createElement('div');
    element.textContent = jsonFile.tag;
    element.id = tag;
    feed.append(element);
  }

  elements = ['title', 'description'];
  for (let i = 0; i < elements.length; i++) {

    element = newDocument.createElement('div');
    element.textContent = jsonFile.elements[i];
    element.id = elements[i];
    feed.append(element);

  }
  */

  if (jsonFile.items.length) {
    for (const item of jsonFile.items) {
    //for (let i = 0; i < jsonFile.items.length; i++) {
      let items = jsonFile.items.length;
      let index = jsonFile.items.indexOf(item) + 1;
      let titleToc = newDocument.createElement('a');
      if (item.title) {
        titleToc.textContent = item.title;
      } else
      if (item.date_published) {
        let dateAsTitle = new Date(item.date_published);
        titleToc.textContent = dateAsTitle.toDateString();
      } else {
        titleToc.textContent = '*** No Title ***';
      }
      titleToc.href = `#newspaper-oujs-${index}`;
      titleToc.title = titleToc.textContent;
      let liElement = newDocument.createElement('li');
      liElement.append(titleToc)
      toc.append(liElement);

      let entry = newDocument.createElement('div');
      entry.className = 'entry';

      let link = newDocument.createElement('a');
      if (item.title) {
        link.textContent = item.title;
      } else
      if (item.date_published) {
        let dateAsTitle = new Date(item.date_published);
        link.textContent = dateAsTitle.toDateString();
      } else {
        link.textContent = 'No Title';
      }
      link.href = item.url;
      //link.id = item.id;
      link.id = `newspaper-oujs-${index}`;

      title = newDocument.createElement('h3');
      title.className = 'title';
      title.append(link);
      entry.append(title);

      let date = newDocument.createElement('div');
      date.className = 'published';
      date.textContent = item.date_published; // date_modified
      entry.append(date);

      // TODO Set it as enclosure unless content is not html (i.e. is text)
      if (item.image) {
        let image = newDocument.createElement('img');
        image.src = item.image;
        entry.append(image);
      }

      let text = newDocument.createElement('div');
      text.className = 'content';
      text.innerHTML = item.content_html; // content_text
      entry.append(text);

      // TODO Test
      if (item.authors) {
        let author = newDocument.createElement('a');
        author.className = 'author';
        authorItem = item.authors;
        if (authorItem.name) {
          author.textContent = authorItem.name;
          if (authorItem.uri) {
            author.href = authorItem.uri;
          }
        }
        entry.append(author);
      }

      // TODO Test
      if (item.author) {
        let author = newDocument.createElement('a');
        author.className = 'author';
        authorItem = item.author;
        if (authorItem.name) {
          author.textContent = authorItem.name;
          if (authorItem.uri) {
            author.href = authorItem.uri;
          }
        }
        entry.append(author);
      }

      articles.append(entry);

      if (
        index > minimumItemNumber &&
        index < items &&
        !ignoreMinimumItemNumber
         )
      {
        let titleToc = newDocument.createElement('a');
        titleToc.textContent = 'See all posts >';
        titleToc.title = `This feed offers ${items} items`;
        titleToc.className = 'expand';
        toc.append(titleToc);
        articles.append(titleToc.cloneNode(true));
        break;
      }
    }
  } else {
    toc.remove(); // NOTE Redundant. See checkContentEmptiness
    articles.insertAdjacentHTML('beforeend', htmlEmpty);
  }

  newDocument.body.append(feed);
  newDocument = checkContentEmptiness(newDocument);
  return newDocument;

}

function renderXML(xmlFile, xmlRules) {

  let newDocument = createPage();

  if (xmlFile.querySelector(xmlRules.feedTitlePage)) {
    // SMF
    if (xmlFile.querySelector(xmlRules.feedTitlePage).getAttribute('forum-name')) {
      newDocument.title =
        xmlFile
        .querySelector(xmlRules.feedTitlePage)
        .getAttribute('forum-name');
    } else {
    newDocument.title =
      xmlFile
      .querySelector(xmlRules.feedTitlePage)
      .textContent;
    }
  }

  // SMF
  if (xmlFile.getElementsByTagName('smf:xml-feed')[0]) {
    newDocument.documentElement.setAttribute(
      'lang',
      xmlFile
      .getElementsByTagName('smf:xml-feed')[0]
      .getAttribute('xml:lang')
    );
  } else
  // Atom
  if (xmlFile.querySelector(xmlRules.feedLanguage) &&
      xmlFile.querySelector(xmlRules.feedLanguage).getAttribute('xml:lang')) {
    newDocument.documentElement.setAttribute(
      'lang',
      xmlFile
      .querySelector(xmlRules.feedLanguage)
      .getAttribute('xml:lang')
    );
  } else
  // RDF and RSS
  if (xmlRules == rdfRules || xmlRules == rssRules) {
    if (xmlFile.querySelector(xmlRules.feedLanguage)) {
      newDocument.documentElement.setAttribute(
        'lang',
        xmlFile
        .querySelector(xmlRules.feedLanguage)
        .textContent
      );
    }
  }

  let feed = newDocument.createElement('div');
  feed.id = 'feed';

  let titlePage = newDocument.createElement('h1');
  if (xmlFile.getElementsByTagName('smf:xml-feed')[0] &&
      xmlFile.getElementsByTagName('smf:xml-feed')[0].getAttribute('forum-name')) {
    titlePage.textContent =
      xmlFile
      .getElementsByTagName('smf:xml-feed')[0]
      .getAttribute('forum-name');
  } else
  if (xmlFile.querySelector(xmlRules.feedTitlePage)) {
    titlePage.textContent =
      xmlFile
      .querySelector(xmlRules.feedTitlePage)
      .textContent;
  } else { // if (!titlePage.textContent)
    titlePage.textContent = document.location.hostname;
  }
  titlePage.id = 'title';
  feed.append(titlePage);

  let subtitle = newDocument.createElement('h2');
  if (xmlFile.getElementsByTagName('smf:xml-feed')[0] &&
      xmlFile.getElementsByTagName('smf:xml-feed')[0].getAttribute('description')) {
    subtitle.textContent =
      xmlFile
      .getElementsByTagName('smf:xml-feed')[0]
      .getAttribute('description');
      //.getAttribute('about');
  } else
  if (xmlFile.querySelector(xmlRules.feedSubtitle)) {
    subtitle.textContent =
      xmlFile
      .querySelector(xmlRules.feedSubtitle)
      .textContent
      .replace(/(<([^>]+)>)/gi, "");
  } else { // if (!subtitle.textContent)
    subtitle.textContent = defaultSubtitle;
  }
  subtitle.id = 'subtitle';
  feed.append(subtitle);

  let toc = newDocument.createElement('ol');
  toc.id = 'toc';
  feed.append(toc);

  let articles = newDocument.createElement('div');
  articles.id = 'articles';
  feed.append(articles);

  if (xmlFile.querySelectorAll(xmlRules.feedItem).length) {
    for (const item of xmlFile.querySelectorAll(xmlRules.feedItem)) {
      let items = xmlFile.querySelectorAll(xmlRules.feedItem).length;
      let index = Array.from(xmlFile.querySelectorAll(xmlRules.feedItem)).indexOf(item) + 1;
      let titleToc = newDocument.createElement('a');
      // /questions/5002111/how-to-strip-html-tags-from-string-in-javascript
      if (item.querySelector(xmlRules.feedItemTitle) &&
          item.querySelector(xmlRules.feedItemTitle).textContent.length) { // FIXME there are two of the same
        titleToc.textContent =
          item
          .querySelector(xmlRules.feedItemTitle)
          .textContent;
        //titleToc.textContent =
        titleToc.innerHTML =
          titleToc
          .textContent
          .replace(/(<([^>]+)>)/gi, "");
      } else
      if (item.querySelector(xmlRules.feedItemDate)) {
        let dateAsTitle = new Date(item.querySelector(xmlRules.feedItemDate).textContent);
        titleToc.textContent = dateAsTitle.toDateString();
      } else
      if (item.querySelector(xmlRules.feedItemPublished)) {
        let dateAsTitle = new Date(item.querySelector(xmlRules.feedItemPublished).textContent);
        titleToc.textContent = dateAsTitle.toDateString();
      } else {
        titleToc.textContent = '*** No Title ***';
      }
      titleToc.href = `#newspaper-oujs-${index}`;
      titleToc.title = titleToc.textContent;
      let liElement = newDocument.createElement('li');
      liElement.append(titleToc)
      toc.append(liElement);

      let entry = newDocument.createElement('div');
      entry.className = 'entry';

      let link = newDocument.createElement('a');
      link.id = `newspaper-oujs-${index}`;
      if (item.querySelector(xmlRules.feedItemTitle) &&
          item.querySelector(xmlRules.feedItemTitle).textContent.length) { // FIXME there are two of the same
        //link.textContent =
        link.innerHTML =
          item
          .querySelector(xmlRules.feedItemTitle)
          .textContent
          .replace(/(<([^>]+)>)/gi, "");
      } else
      if (item.querySelector(xmlRules.feedItemDate)) {
        let dateAsTitle = new Date(item.querySelector(xmlRules.feedItemDate).textContent);
        link.textContent = dateAsTitle.toDateString();
      } else
      if (item.querySelector(xmlRules.feedItemPublished)) {
        let dateAsTitle = new Date(item.querySelector(xmlRules.feedItemPublished).textContent);
        link.textContent = dateAsTitle.toDateString();
      } else {
        link.textContent = 'No Title';
      }

      if (item.querySelector(xmlRules.feedItemLink) &&
          item.querySelector(xmlRules.feedItemLink).getAttribute('href')) {
        // Atom
        if (item.querySelector(xmlRules.feedItemLink + "[rel='alternate']")) {
          link.href =
            item
            .querySelector(xmlRules.feedItemLink + "[rel='alternate']")
            .getAttribute('href');
        } else {
          link.href =
            item
            .querySelector(xmlRules.feedItemLink)
            .getAttribute('href');
        }
      } else {
      if (item.querySelector(xmlRules.feedItemLink) &&
          item.querySelector(xmlRules.feedItemLink).textContent.length) {
        // RSS
        // FIXME Ignore whitespace
        // https://handheldgameconsoles.com/f.atom
        link.href =
          item
          .querySelector(xmlRules.feedItemLink)
          .textContent;
      } else
      if (getHomeLink(xmlFile, xmlRules)) {
        link.href = getHomeLink(xmlFile, xmlRules) + '?ref=feed';
      } else
        link.href = './?ref=feed';
      }

      let title = newDocument.createElement('h3');
      title.className = 'title';
      title.append(link);
      entry.append(title);

      if (item.querySelector(xmlRules.feedItemDate)) {
        let date = newDocument.createElement('div');
        date.className = 'published';
        date.textContent =
          item
          .querySelector(xmlRules.feedItemDate)
          .textContent;
        entry.append(date);
      } else
      if (item.querySelector(xmlRules.feedItemPublished)) {
        let date = newDocument.createElement('div');
        date.className = 'published';
        date.textContent =
          item
          .querySelector(xmlRules.feedItemPublished)
          .textContent;
        entry.append(date);
      }

      if (item.querySelector(xmlRules.feedItemContent)) {
        let text = newDocument.createElement('div');
        text.className = 'content content-text';
        text.innerHTML =
          item
          .querySelector(xmlRules.feedItemContent)
          .textContent;
        if (/<\/?[a-z][\s\S]*>/i.test(text.innerHTML)) {
          text.className = 'content';
        }
        entry.append(text);
      }

      if (item.querySelector(xmlRules.feedItemSummary)) {
        let text = newDocument.createElement('div');
        text.className = 'content content-text';
        text.innerHTML =
          item
          .querySelector(xmlRules.feedItemSummary)
          .textContent;
        if (/<\/?[a-z][\s\S]*>/i.test(text.innerHTML)) {
          text.className = 'content';
        }
        entry.append(text);
      }

      // Handle enclosures with search parameters (images of "the mark" website)
      if (item.querySelector(xmlRules.feedItemEnclosure)) {
        let enclosures = newDocument.createElement('div');
        enclosures.className = 'enclosures';
        enclosures.title = 'Right-click and Save link as…';
        for (const enclosure of item.querySelectorAll(xmlRules.feedItemEnclosure)) {
        // FIXME Skip enclosures with empty href
        // https://gnu.tiflolinux.org/api/statuses/public_timeline.atom
          let file = newDocument.createElement('div');
          file.className = 'enclosure';
          enclosures.append(file);
          let icon = newDocument.createElement('span');
          let documentType;
          if (enclosure.getAttribute('type')) {
            documentType = enclosure.getAttribute('type').split('/')[0];
          } else {
            documentType = '';
          }
          icon.setAttribute('icon', documentType);
          file.append(icon);
          let link = newDocument.createElement('a');
          let enclosureBase, enclosureUrl;
          // rss
          if (enclosure.getAttribute('url')) {
            enclosureUrl = enclosure.getAttribute('url');
            enclosureBase = enclosureUrl.split('/').pop();
          } else
          // atom https://tomosnowbug.hatenablog.com/feed
          if (enclosure.getAttribute('href')) {
            enclosureUrl = enclosure.getAttribute('href');
            enclosureBase = enclosureUrl.split('/').pop();
          }
          link.textContent = enclosureBase;
          link.download = enclosureBase;
          link.href = enclosureUrl;
          file.append(link);
          let size = newDocument.createElement('span');
          // class="size" is needed for function transformFileSize
          size.className = `size ${documentType}`;
          size.textContent = `${enclosure.getAttribute('length')}`;
          file.append(size);
        }
        entry.append(enclosures);
      }

      // /questions/45110893/select-elements-by-attributes-with-colon
      // const feedItemMediaQuery = CSS.escape(feedItemMedia)
      // console.log(document.querySelectorAll(`[${feedItemMediaQuery}]`))

      // Neither work. Use XPath.
      //console.log(item.querySelectorAll(`[media\\:content]`))
      //console.log(item)
      //console.log(item.querySelectorAll(`[media\\3A content]`))

      // Mastodon
      if (item.getElementsByTagName(xmlRules.feedItemMedia).length) {
        let medias = newDocument.createElement('div');
        medias.className = 'enclosures';
        medias.title = 'Right-click and Save link as…';
        for (const media of item.getElementsByTagName(xmlRules.feedItemMedia)) {
          let file = newDocument.createElement('div');
          file.className = 'enclosure';
          medias.append(file);
          let icon = newDocument.createElement('span');
          let documentType;
          if (media.getAttribute('medium')) {
            documentType = media.getAttribute('medium');
          } else {
            documentType = '';
          }
          icon.setAttribute('icon', documentType);
          file.append(icon);
          let link = newDocument.createElement('a');
          let mediaBase, mediaUrl;
          if (media.getAttribute('url')) {
            mediaUrl = media.getAttribute('url');
            mediaBase = mediaUrl.split('/').pop();
          }
          link.textContent = mediaBase;
          link.download = mediaBase;
          link.href = mediaUrl;
          file.append(link);
          let size = newDocument.createElement('span');
          // class="size" is needed for function transformFileSize
          size.className = `size ${documentType}`;
          size.textContent = `${media.getAttribute('length')}`;
          file.append(size);
        }
        entry.append(medias);
      }

      let authorItem;
      if (xmlRules.feedItemAuthor.includes(':')) {
        authorItem = item.getElementsByTagName(xmlRules.feedItemAuthor)[0];
      } else {
        authorItem = item.querySelector(xmlRules.feedItemAuthor);
      }

      if (authorItem) {
        let author = newDocument.createElement('a');
        author.className = 'author';
        if (authorItem.querySelector('name')) {
          author.textContent = authorItem.querySelector('name').textContent;
          if (authorItem.querySelector('link, uri')) {
            author.href = authorItem.querySelector('link, uri').textContent;
          }
        } else {
          author.textContent = authorItem.textContent;
        }
        if (author.textContent) {
          entry.append(author);
        }
      }

      articles.append(entry);

      if (
        index > minimumItemNumber &&
        index < items &&
        !ignoreMinimumItemNumber
         )
      {
        let titleToc = newDocument.createElement('a');
        titleToc.textContent = 'See all posts >';
        titleToc.title = `This feed offers ${items} items`;
        titleToc.className = 'expand';
        toc.append(titleToc);
        articles.append(titleToc.cloneNode(true));
        break;
      }
    }
  }

  newDocument.body.append(feed);
  newDocument = checkContentEmptiness(newDocument);
  return newDocument;
}

function renderOPML(xmlFile, xmlRules) {

  let newDocument = createPage();

  if (xmlFile.querySelector(xmlRules.feedTitlePage)) {
    newDocument.title =
      xmlFile
      .querySelector(xmlRules.feedTitlePage)
      .textContent;
  }
  if (xmlFile.querySelector(xmlRules.feedLanguage)) {
    let language;
    if (xmlFile.querySelector(xmlRules.feedLanguage)) {
      language =
        xmlFile
        .querySelector(xmlRules.feedLanguage)
        .textContent;
    }
    newDocument.documentElement.setAttribute('lang', language);
  }

  let feed = newDocument.createElement('div');
  feed.id = 'feed';

  let title = newDocument.createElement('h1');
  if (xmlFile.querySelector(xmlRules.feedTitlePage)) {
    title.textContent =
      xmlFile
      .querySelector(xmlRules.feedTitlePage)
      .textContent;
  }
  if (!title.textContent) {
    title.textContent = document.location.hostname;
  }
  title.id = 'title';
  feed.append(title);

  let subtitle = newDocument.createElement('h2');
  if (xmlFile.querySelector(xmlRules.feedSubtitle)) {
    subtitle.textContent =
      xmlFile
      .querySelector(xmlRules.feedSubtitle)
      .textContent
      .replace(/(<([^>]+)>)/gi, "");
  }
  if (!subtitle.textContent) {
    subtitle.textContent = defaultSubtitle;
  }
  subtitle.id = 'subtitle';
  feed.append(subtitle);

  let toc = newDocument.createElement('ol');
  toc.id = 'toc';
  feed.append(toc);

  let articles = newDocument.createElement('div');
  articles.id = 'articles';
  feed.append(articles);

  if (xmlFile.querySelectorAll(xmlRules.feedItem).length) {
    for (const item of xmlFile.querySelectorAll(xmlRules.feedItem)) {
    if (!item.children.length) {
      let items = xmlFile.querySelectorAll(xmlRules.feedItem).length;
      let index = Array.from(xmlFile.querySelectorAll(xmlRules.feedItem)).indexOf(item) + 1;
      let titleToc = newDocument.createElement('a');
      // /questions/5002111/how-to-strip-html-tags-from-string-in-javascript
      if (item.getAttribute(xmlRules.feedItemTitle)) {
        titleToc.textContent =
          item
          .getAttribute(xmlRules.feedItemTitle);
        //titleToc.textContent =
        titleToc.innerHTML =
          titleToc
          .textContent
          .replace(/(<([^>]+)>)/gi, "");
      } else
      if (item.getAttribute(xmlRules.feedItemDate)) {
        let dateAsTitle = new Date(item.getAttribute(xmlRules.feedItemDate));
        titleToc.textContent = dateAsTitle.toDateString();
      } else
      if (item.getAttribute(xmlRules.feedItemSummary)) {
        titleToc.innerHTML =
          item
          .getAttribute(xmlRules.feedItemSummary)
          .replace(/(<([^>]+)>)/gi, "");
      } else {
        titleToc.textContent = '*** No Title ***';
      }
      titleToc.href = `#newspaper-oujs-${index}`;
      titleToc.title = titleToc.textContent;
      let liElement = newDocument.createElement('li');
      liElement.append(titleToc)
      toc.append(liElement);

      let entry = newDocument.createElement('div');
      entry.className = 'entry';

      let link = newDocument.createElement('a');
      link.id = `newspaper-oujs-${index}`;
      if (item.getAttribute(xmlRules.feedItemTitle)) {
        //link.textContent =
        link.innerHTML =
          item
          .getAttribute(xmlRules.feedItemTitle)
          .replace(/(<([^>]+)>)/gi, "");
      } else
      if (item.getAttribute(xmlRules.feedItemDate)) {
        let dateAsTitle = new Date(item.getAttribute(xmlRules.feedItemDate));
        link.textContent = dateAsTitle.toDateString();
      } else
      if (item.getAttribute(xmlRules.feedItemSummary)) {
        //link.textContent =
        link.innerHTML =
          item
          .getAttribute(xmlRules.feedItemSummary)
          .replace(/(<([^>]+)>)/gi, "");
      } else {
        link.textContent = 'No Title';
      }

      // NOTE Test
      if (item.getAttribute(xmlRules.feedItemLink)) {
        // rss
        link.href =
          item
          .getAttribute(xmlRules.feedItemLink);
      } else {
        link.href = './?ref=feed';
      }

      title = newDocument.createElement('h3');
      title.className = 'title';
      title.append(link);
      entry.append(title);

      if (item.getAttribute(xmlRules.feedItemDate)) {
        let date = newDocument.createElement('div');
        date.className = 'published';
        date.textContent =
          item
          .getAttribute(xmlRules.feedItemDate);
        entry.append(date);
      }

      if (item.getAttribute(xmlRules.feedItemContent)) {
        let text = newDocument.createElement('div');
        text.className = 'content content-text';
        text.innerHTML =
          item
          .getAttribute(xmlRules.feedItemContent);
        if (/<\/?[a-z][\s\S]*>/i.test(text.innerHTML)) {
          text.className = 'content';
        }
        entry.append(text);
      } else
      if (item.getAttribute(xmlRules.feedItemSummary)) {
        let text = newDocument.createElement('div');
        text.className = 'content content-text';
        text.innerHTML =
          item
          .getAttribute(xmlRules.feedItemSummary);
        if (/<\/?[a-z][\s\S]*>/i.test(text.innerHTML)) {
          text.className = 'content';
        }
        entry.append(text);
      }

      if (item.getAttribute(xmlRules.feedItemEnclosure)) {
        let enclosures = newDocument.createElement('div');
        enclosures.className = 'enclosures';
        enclosures.title = 'Right-click and Save link as…';
        // TODO Skip enclosures with empty href
        // https://gnu.tiflolinux.org/api/statuses/public_timeline.atom
        let file = newDocument.createElement('div');
        file.className = 'enclosure';
        enclosures.append(file);
        let icon = newDocument.createElement('span');
        let documentType;
        if (item.getAttribute('type')) {
          documentType = item.getAttribute('type');
        }
        icon.setAttribute('icon', documentType);
        file.append(icon);
        let link = newDocument.createElement('a');
        let enclosureBase, enclosureUrl;
        if (item.getAttribute(xmlRules.feedItemEnclosure)) {
          enclosureUrl = item.getAttribute(xmlRules.feedItemEnclosure);
          enclosureBase = enclosureUrl.split('/').pop();
          if (!enclosureBase.includes('.')) {
            if (['atom','json','rss'].includes(documentType)) {
              enclosureBase = 'feed.' + documentType;
            } else {
              enclosureBase = 'feed';
            }
          }
        }
        if (documentType) {
          link.textContent = enclosureBase + ' (' + documentType + ')';
        } else {
          link.textContent = enclosureBase;
        }
        link.download = enclosureBase;
        link.href = enclosureUrl;
        file.append(link);
        entry.append(enclosures);
      }

      articles.append(entry);

      if (
        index > minimumItemNumber &&
        index < items &&
        !ignoreMinimumItemNumber
         )
      {
        let titleToc = newDocument.createElement('a');
        titleToc.textContent = 'See all subscriptions >';
        titleToc.title = `This feed offers ${items} items`; // NOTE Miscount
        titleToc.className = 'expand';
        toc.append(titleToc);
        articles.append(titleToc.cloneNode(true));
        break;
      }
    }
    }
  }

  newDocument.body.append(feed);
  newDocument = checkContentEmptiness(newDocument);
  return newDocument;

}

function createPage() {
  let domParser = new DOMParser();
  let newDocument = domParser.parseFromString('', 'text/html');
  return newDocument;
}

async function getMinimumItemNumber() {
  if (gmGetValue) {
    return await GM.getValue('item-number', 5);
  }
}

function checkContentEmptiness(newDocument) {
  if (newDocument.getElementsByClassName('entry').length == 1) {
    newDocument.getElementById('toc').remove();
    // NOTE https://dbpedia.org/data/Searx.atom
    if (!newDocument.getElementById('articles').outerText) {
      newDocument.getElementsByClassName('entry')[0].remove();
      // Should removed data be added to the htmlEmpty message?
      // newDocument.getElementsByClassName('entry')[0].outerHTML;
      newDocument.getElementById('articles').insertAdjacentHTML('beforeend', htmlEmpty);
    }
  } else
  if (newDocument.getElementsByClassName('entry').length == 0) {
    newDocument.getElementById('toc').remove();
    newDocument.getElementById('articles').insertAdjacentHTML('beforeend', htmlEmpty);
  }
  return newDocument;
}

// Possible solution for the document.contentType issue
// /questions/40201137/i-need-to-read-a-text-file-from-a-javascript
// https://openuserjs.org/garage/Loading_functions_after_document_is_replaced_by_new_document
function placeNewDocument(newDocument) {
  //newDocument.querySelector('#homepage').href = location.protocol + '//' + location.hostname;
  //var newDoc = document.adoptNode(newDoc.documentElement, true);
  let insertDocument = document.importNode(newDocument.documentElement, true);
  let removeDocument = document.documentElement;
  document.replaceChild(
    insertDocument,
    removeDocument
  );
}

async function preProcess(newDocument) {

  if (xmlStylesheet) {
//  function stylesheetMessage(newDocument) {
    let aElement = newDocument.createElement('a');
    newDocument.body.prepend(aElement);
    //aElement.href = location.href.substring(0, location.href.indexOf('#')) + location.search + '?streamburner=0';
    let url = new URL(location.href);
    url.searchParams.set('streamburner_active','0');
    aElement.href = url.href;
    aElement.innerHTML = 'View this syndicated document with its own stylesheet.'; // This feed has its own stylesheet
    aElement.id = 'xslt-message';
    aElement.className = 'infobar-message';
//    return newDocument;
//  }
  }

// NOTE newDocument.contentType when is executed
// directly from this function, returns text/html
//function issue3164Message(newDocument, mimetype) {
  if (document.contentType.endsWith('xml')) {
      let mimeType = document.contentType;
      let aElement = newDocument.createElement('div');
      newDocument.body.prepend(aElement);
      aElement.textContent = `Some actions might not work on this page due to MIME-Type ${mimeType}.`;
      //aElement.title = mimeType;
      aElement.id = 'feature-limited';
      aElement.className = 'infobar-message';
  }
//  return newDocument;
//}

  if (wellFormed != 'This XML is well-formed.') {
      let aElement = newDocument.createElement('div');
      newDocument.body.prepend(aElement);
      aElement.textContent = `Contents of this document might not appear as intended (XML document is not-well-formed). Please contact the administrators.`;
      aElement.id = 'not-well-formed';
      aElement.className = 'infobar-message';
  }

// NOTE
// https://momi.ca/feed.xml
// https://momi.ca/css/base.css
// https://momi.ca/css/dark.css
// https://chee.party/feeds/everything.xml element style of post https://chee.party/quiet-party/

//function purgeStylesheets(newDocument) {
  if (gmGetValue) {
    if (await GM.getValue('ignore-css', true)) {
      for (const style of newDocument.querySelectorAll('style, link[rel="stylesheet"]')) {
        style.remove();
      }
    }
  }
//  return newDocument; // FIXME
//}

// TODO SET XML-STYLESHEET IF CONTENT-TYPE IS XML
//function setCssStylesheet(newDocument) {
  let cssStylesheet = newDocument.createElement('style');
  newDocument.head.append(cssStylesheet);
  //stylesheet.setAttribute('crossorigin', 'anonymous');
  cssStylesheet.type = 'text/css';
  cssStylesheet.id = namespace;

  // TODO
  // Set direction by the letters of the initial
  // set of words if no language specified.
  if (rtlLocales.includes(newDocument.documentElement.getAttribute('lang'))) {
    cssFileBase = cssFileLTR + cssFileRTL;
  } else {
    cssFileBase = cssFileLTR;
  }

  cssStylesheet.textContent = cssFileBase;
  //cssStylesheet.setAttribute('unsafe-hashes', null);
//  return newDocument; // FIXME
//}

//function footerBar(newDocument) {
  //if (newDocument.contentType.endsWith('xml')) { return; }
  let infoFooter = newDocument.createElement('footer');
  newDocument.body.append(infoFooter);
  let linkSubscribe = newDocument.createElement('a');
  linkSubscribe.title = 'Subscribe to feed';
  linkSubscribe.className = 'subscribe-link';
  linkSubscribe.textContent = 'Subscribe';
  infoFooter.append(linkSubscribe);
  let linkHome = newDocument.createElement('a');
  linkHome.title = 'Visit homepage';
  linkHome.className = 'homepage-link';
  linkHome.textContent = 'Homepage';
  infoFooter.append(linkHome);
  let linkSource = newDocument.createElement('a');
  linkSource.href = 'view-source:${location.href}?streamburner_active=0';
  linkSource.title = 'View page source code: Right-click and open in new tab';
  linkSource.textContent = 'Page Source';
  linkSource.target = '_blank';
  linkSource.rel = 'noopener';
  linkSource.id = 'source-link';
  infoFooter.append(linkSource);
  let linkHelp = newDocument.createElement('span');
  linkHelp.title = 'Learn about syndication feed and how you can help';
  linkHelp.className = 'cursor-help';
  linkHelp.textContent = 'Help & Information';
  linkHelp.id = 'about-help';
  infoFooter.append(linkHelp);
  let linkSupport = newDocument.createElement('span');
  linkSupport.title = 'Learn how you can support';
  linkSupport.className = 'cursor-pointer';
  linkSupport.textContent = 'Support Our Cause';
  linkSupport.id = 'about-support';
  infoFooter.append(linkSupport);
  let linkMuc = newDocument.createElement('a');
  //linkMuc.href = 'xmpp:syndication@conference.movim.eu?join';
  linkMuc.href = 'https://join.jabber.network/#syndication@conference.movim.eu?join';
  linkMuc.title = 'Chat with us about Syndictaion and PubSub over XMPP';
  linkMuc.textContent = 'Visit Our Groupchat';
  //linkMuc.target = '_blank';
  //linkMuc.rel = 'noopener';
  linkMuc.id = 'about-muc';
  infoFooter.append(linkMuc);
//  let linkVisit = newDocument.createElement('a');
//  linkVisit.href = 'http://schimon.i2p/';
//  linkVisit.title = 'Visit project site: schimon.i2p';
//  linkVisit.textContent = 'Visit Us';
//  linkVisit.id = 'about-visit';
//  infoFooter.append(linkVisit);
  let proFooter = newDocument.createElement('footer');
  newDocument.body.append(proFooter);
  let software = [
    { // 100daystooffload
      'text' : '#100DaysToOffload',
      'link' : 'https://100daystooffload.com/',
      'title' : 'Can you publish 100 posts on your blog in a year?',
    },
    { // 100daystooffload
      'text' : '100 Days To Offload',
      'link' : 'https://100daystooffload.com/',
      'title' : 'Can you publish 100 posts on your blog in a year?',
    },
    { // divested
      'text' : 'Get DivestOS',
      'link' : 'https://divestos.org/',
      'title' : 'A Mobile Operating System Divested From The Norm. ("take back (some) control of your device")',
    },
    { // fdroid
      'text' : 'Get F-Droid',
      'link' : 'https://f-droid.org/',
      'title' : 'Free and Open Source Android App Repository',
    },
    { // falkon
      'text' : 'Get Falkon',
      'link' : 'https://falkon.org/',
      'title' : 'Reclaim Your Online Privacy',
    },
    { // futo
      'text' : 'Visit FUTO',
      'link' : 'https://futo.org/',
      'title' : 'Bringing control of computing back to the people',
    },
    { // gajim
      'text' : 'Get Gajim',
      'link' : 'https://gajim.org/',
      'title' : 'A fully-featured XMPP client',
    },
    { // gutenberg
      'text' : 'Project Gutenberg',
      'link' : 'https://gutenberg.org/',
      'title' : 'Project Gutenberg is a library of over 70,000 free eBooks',
    },
    { // greasyfork
      'text' : 'Visit GreasyFork',
      'link' : 'https://greasyfork.org/',
      'title' : 'Lightweight site-specific browser extensions',
    },
    { // izzysoft
      'text' : 'Visit IzzyOnDroid',
      'link' : 'https://apt.izzysoft.de/fdroid/',
      'title' : 'IzzyOnDroid F-Droid Repository',
    },
    { // kmeleon
      'text' : 'Get K-Meleon',
      'link' : 'http://kmeleonbrowser.org/',
      'title' : 'The Browser You Control',
    },
    { // ladybird
      'text' : 'Get Ladybird',
      'link' : 'https://ladybird.org/',
      'title' : 'A New Cross Platform Browser Project',
    },
    { // lagrange
      'text' : 'Get Lagrange',
      'link' : 'https://gmi.skyjake.fi/lagrange/',
      'title' : 'Your Guide To The Gemini',
    },
    { // librivox
      'text' : 'Project LibriVox',
      'link' : 'https://librivox.org/',
      'title' : 'Free public domain audiobooks',
    },
    { // nlnet
      'text' : 'Visit NLnet Foundation',
      'link' : 'https://nlnet.nl/',
      'title' : 'Help to help the internet',
    },
    { // otter
      'text' : 'Get Otter Browser',
      'link' : 'https://otter-browser.org/',
      'title' : 'Controlled By The User, Not Vice Versa.',
    },
    { // oujs
      'text' : 'Visit OpenUserJS.org',
      'link' : 'https://openuserjs.org/',
      'title' : 'Lightweight site-specific browser extensions',
    },
    { // palemoon
      'text' : 'Get Pale Moon',
      'link' : 'https://palemoon.org/',
      'title' : 'Your Browser, Your Way.',
    },
    { // peoplesopen
      'text' : 'Join People\'s Open Network',
      'link' : 'https://peoplesopen.net/learn/build/',
      'title' : 'So You Want to Build Your Own Internet?!',
    },
    { // pmos
      'text' : 'Get postmarketOS',
      'link' : 'https://postmarketos.org/',
      'title' : 'A Real Linux Distribution For Phones',
    },
    { // salix
      'text' : 'Get SalixOS',
      'link' : 'https://salixos.org/',
      'title' : 'The Bonsai OS - Linux for the lazy Slacker',
    },
    { // ubports
      'text' : 'Get Ubuntu Touch',
      'link' : 'https://devices.ubuntu-touch.io/',
      'title' : 'Linux Mobile OS That Gives You Pure Freedom',
    }
  ];
  // TODO Each software to each day: new Date().getDay()
  selected = software[Math.floor(Math.random()*software.length)];
  let linkSoftware = newDocument.createElement('a');
  linkSoftware.href = selected.link;
  linkSoftware.title = selected.title;
  linkSoftware.textContent = selected.text;
  linkSoftware.id = 'about-software';
  proFooter.append(linkSoftware);
  let linkJabber = newDocument.createElement('a');
  linkJabber.href = 'https://joinjabber.org/';
  linkJabber.title = 'Welcome to the inclusive place of the Jabber network';
  linkJabber.textContent = 'JoinJabber';
  linkJabber.id = 'about-jabber';
  proFooter.append(linkJabber);
  let linkGemini = newDocument.createElement('a');
  linkGemini.href = 'https://geminiprotocol.net/';
  linkGemini.title = 'The internet as it was truly intended';
  linkGemini.textContent = 'Project Gemini';
  linkGemini.id = 'about-gemini';
  proFooter.append(linkGemini);
  if (isMoz()) {
    let linkMoz = newDocument.createElement('a');
    linkMoz.href = 'https://diggy.club/articles/mozilla.xhtml';
    linkMoz.title = 'Mozilla - Devil Incarnate';
    linkMoz.textContent = 'Mozilla Secrets';
    linkMoz.id = 'about-moz';
    proFooter.append(linkMoz);
  }
  let placeHolder = newDocument.createElement('placeholder');
  newDocument.body.append(placeHolder);
//  return newDocument;
//}

//function viewSourceCode(newDocument) {
  //if (newDocument.contentType.endsWith('xml')) { return; }
  let url = new URL(location.href);
  url.searchParams.set('streamburner_active','0');
  url.hash = '';
  let sourceLink = newDocument.querySelector('#source-link')
  sourceLink.href = 'view-source:' + url.href;
  //sourceLink.title = 'Right-click and open in new tab';
//  return newDocument;
//}

//function decorateEntry(newDocument) {
  for (const entry of newDocument.querySelectorAll('.entry')) {
    let divElement = newDocument.createElement('span');
    divElement.className = 'decor';
    entry.parentNode.insertBefore(divElement, entry.nextSibling);
  }
//  return newDocument;
//}

//async function setFont(newDocument) {
  //if (newDocument.contentType.endsWith('xml')) return;

  // type
  if (gmGetValue) {
    newDocument.body.style.fontFamily = await GM.getValue('font-type', 'serif');
  }

  // size
  if (gmGetValue) {
    newDocument.getElementById('articles').style
    .fontSize = await GM.getValue('font-size') + 'px';
  }
//  return newDocument;
//}

//function trimEnclosureFilename(newDocument) {
  for (const fileName of newDocument.querySelectorAll('.enclosure > a')) {
    if (fileName.textContent.includes('?')) {
      //let newfileName;
      //newfileName = fileName.href.split('/').pop();
      //newfileName = newfileName.substring(0, newfileName.indexOf('?'));
      let newfileName = fileName.textContent.substring(0, fileName.textContent.indexOf('?'));
      fileName.textContent = newfileName;
      fileName.download = newfileName;
      fileName.href = newfileName;
    }
  }
//  return newDocument;
//}

//function mailTo(newDocument) {
  // Add link with emails
  if (newDocument.querySelector('#empty-feed')) {
    let ele, eml, hyl;
    ele = newDocument.querySelector('#empty-feed');
    aElement = newDocument.createElement('a');
    aElement.id = 'email-link';
    if (ele.className.includes('dark')) {
      aElement.className = 'dark';
    }
    aElement.textContent = 'Send Email Message';
    let una = ['admin', 'contact', 'feedback', 'form',
           'hello', 'hi', 'info', 'me', 'office', 'pr',
           'press', 'support', 'web', 'webmaster',];
    hyl = `${una[0]}@${location.hostname},`
    for (let i = 1; i < una.length; i++) {
      hyl += `${una[i]}@${location.hostname},`;
    }
    //hyl = hyl.slice(0. -1);
    aElement.href = `mailto:?subject=Add Syndication Feeds for ${location.hostname}&body=Hello,%0D%0A%0D%0AI have visited ${document.baseURI.slice(document.baseURI.indexOf(':')+3)} and saw that your Syndication Feed is empty.%0D%0A%0D%0APlease populate your RSS Syndication Feed so that people can easily receive updates from your site.%0D%0A%0D%0AIf you do not know what a Syndication Feed is or how you can benefit from it, visit aboutfeeds.com to read more about it.%0D%0A%0D%0AThe recommended standard of RSS is The Atom Syndication Format (RFC 4287).%0D%0A%0D%0AKind regards,%0D%0A&bcc=${hyl}`
    ele.append(aElement);
  }
//  return newDocument;
//}

//function linksBar(newDocument) {
  let divElement = newDocument.createElement('div');
  divElement.innerHTML = htmlBar;
  let subtitle = newDocument.querySelector('#subtitle');
  subtitle.parentNode.insertBefore(divElement, subtitle.nextSibling);
//  return newDocument;
//}

//async function handler(newDocument) {
  //let service = newDocument.querySelector('#subscribe');
  //service.removeAttribute('href');
  let handler, instance, link, text;
  if (gmGetValue) {
    handler = await GM.getValue('handler', 'subtome');
    switch (handler) {
      case 'desktop':
        text = 'Follow';
        link = `feed:${location.href}`;
        break;
      case 'commafeed':
        text = 'CommaFeed';
        instance = await GM.getValue('instance', 'www.commafeed.com');
        link = `https://${instance}/rest/feed/subscribe?url=${location.href}`;
        break;
      case 'feedly':
        text = 'Feedly';
        link = `https://feedly.com/i/discover/sources/search/feed/${location.host}`;
        break;
      case 'subtome':
        text = 'SubToMe';
        instance = await GM.getValue('instance', 'www.subtome.com');
        subToMe(instance);
        break;
      case 'custom':
        text = 'Subscribe';
        instance = await GM.getValue('instance', 'news.schimon.i2p');
        link = `${instance}${location.href}`;
        break;
    }
  } else {
    // TODO Change to SubToMe
    text = 'Follow';
    link = `feed:${location.href}`;
  }
  for (const element of newDocument.querySelectorAll('.subscribe-link')) {
      element.textContent = text;
      element.href = link;
  }
//  return newDocument;
//}

//async function dark(newDocument) {
//  if (!newDocument.contentType.endsWith('xml')) {
  if (gmGetValue) {
      cssSelectors = [
        'body', 'code', 'a', '.enclosures', '#empty-feed'];
      if (await GM.getValue('view-mode') == 'dark') {
        for (cssSelector of cssSelectors) {
          for (element of newDocument.querySelectorAll(cssSelector)) {
            element.classList.add('dark');
            let mode = newDocument.querySelector('#mode');
            //mode.textContent = '💡'; // 🌓
            //mode.style.filter = 'saturate(7)';
            mode.style.filter = 'brightness(0.5)'; // invert
            mode.title = 'Switch to bright mode';
          }
        }
      }
    }
//  }
//  return newDocument;
//}

//function formatDate(newDocument) {
  let elements = ['.published', '.updated'];
  for (let i = 0; i < elements.length; i++) {
    for (const element of newDocument.querySelectorAll(elements[i])) {
      let date = new Date(element.textContent);
      if (date == 'Invalid Date') continue;
      //element.textContent = date.toDateString();
      element.textContent = date.toLocaleString();
    }
  }
//  return newDocument;
//}

// FIXME
// questions/10420352/converting-file-size-in-bytes-to-human-readable-string
//function transformFileSize(newDocument) {
  for (const item of newDocument.querySelectorAll('.size')) {
    size = item.textContent;
    var i = size == 0 ? 0 : Math.floor(Math.log(size) / Math.log(1024));
    item.textContent = (size / Math.pow(1024, i)).toFixed(2) * 1 + ' ' + ['B', 'kB', 'MB', 'GB', 'TB'][i];
    if (item.textContent == '0 B' ||
        item.textContent == 'NaN undefined') {
      item.textContent = null;
    }
  }
//  return newDocument;
//}

//function noReferrer(newDocument) {
  for (const element of newDocument.querySelectorAll('a[href]')) {
    element.rel = 'noreferrer';
  }
//  return newDocument;
//}

  // Failed attempt to force browser to treat file as HTML
  let meta = newDocument.createElement('meta');
  meta.setAttribute('http-equiv', 'Content-Type');
  meta.setAttribute('content', 'text/html; charset=utf-8');
  // Append the <meta> element to the <head> element
  newDocument.head.appendChild(meta);
  // Failed attempt to force browser to treat file as HTML

  // Add #top-navigation-button
  let navigateTop = newDocument.createElement('a');
  navigateTop.textContent = '^'; // ^ is better than ⬆️⥣⇧⇪➦
  navigateTop.href = '#';
  navigateTop.id = 'top-navigation-button';
  newDocument.body.append(navigateTop);

  return newDocument;

}

async function postProcess() {

// NOTE
// Consider https://openuserjs.org/libs/BigTSDMB/setStyle
//function setNonceUponCSP() {
  window.addEventListener("securitypolicyviolation", (e) => {
    //let message = e.originalPolicy;
    //messageTruncated = message.substring(message.indexOf("'nonce-") + 7);
    //let nonceValue = messageTruncated.substring(0, messageTruncated.indexOf("'"));
    cssStylesheet = document.getElementById(namespace);
    let nonceValue = e.originalPolicy.match(/'nonce-(.*?)'/)[1];
    cssStylesheet.setAttribute('nonce', nonceValue);
    //let hashValue = e.originalPolicy.match(/sha256-[A-Za-z0-9+/=]+/)[0];
    //cssStylesheet.setAttribute('unsafe-inline', hashValue);

    // Reload stylesheet
    textContent = cssStylesheet.textContent;
    cssStylesheet.textContent = null;
    cssStylesheet.textContent = textContent;
  }, { passive : true, once: true});
//}

// Write element #top-navigation-button as HTML or create it at preProcess
// instead of creatnig it with ECMA, so it would work with XML.
  let navigateTop = document.querySelector('#top-navigation-button');
  navigateTop.onmouseover = () => {
    navigateTop.removeAttribute('href');
  };
  navigateTop.onclick = () => {
    window.scrollTo({ top: 0 });
  };

  for (let titleToc of document.querySelectorAll('.expand')) {
    titleToc.onclick = () => {
      titleToc.textContent = 'Loading all of the items. Please wait...';
      ignoreMinimumItemNumber = true;
      checkContentType();
      init;
    };
  }

//function scrollDown(document) {
  let urlA;
  // Create toolbar and a button when scrolling down
  document.addEventListener ('scroll', function() {
    if (location.href == urlA || window.pageYOffset < 300) {
    //function floatBar() {
      const cssStylesheet = document.getElementById(namespace);
      if (document.querySelector('#links-bar')) {
        document.querySelector('#links-bar').style.display = 'auto';
      }
      if (window.pageYOffset > 300) { // TODO when first entry is focused
        cssStylesheet.textContent = cssFileBase + cssFileBar;
      } else {
        cssStylesheet.textContent = cssFileBase;
        document.querySelector('#links-bar').removeAttribute('style');
      }
    }
    if (location.href != urlA) {
      urlA = location.href;
    }
  });
//  return document;
//}

//function homePage(document) {
  let linkHomePage;
  for (const element of document.querySelectorAll('.homepage-link')) {
    if (document.querySelector('meta[name="link"]')) {
      linkHomePage = document.querySelector('meta[name="link"]').getAttribute('content');
      element.href = linkHomePage;
    } else {
      element.remove();
      //return;
    }
  }
  /*
  if (!link && document.location.hostname) {
    link = document.location.hostname;
  } else
  if (!link) { // Local file (i.e. file://)
    link = document.location.href.slice(0, location.href.lastIndexOf('/'));
  }
  document.querySelector('#homepage').href = link;
  */
//  return document;
//}

// Issue with header indication of XML
//function modeChange(document){
  let mode = document.querySelector('#mode');
  mode.addEventListener ('click', async function() {
    if (document.contentType.endsWith('xml')) {
      alert('Dark mode is disabled for this page due to unmodifiable XML header.');
      //return;
    } else {
      await toggleMode()
    }
  })
//  return document;
//}

// /questions/38627822/increase-the-font-size-with-a-click-of-a-button-using-only-javascript
//function fontSizeControl(document) {
  document.querySelector('#increase')
  .addEventListener ('click', async function() {
    txt = document.getElementById('articles');
    style = window.getComputedStyle(txt, null).getPropertyValue('font-size');
    currentSize = parseFloat(style);
    if (currentSize < 35) {
      txt.style.fontSize = (currentSize + 5) + 'px';
      infoSquare('Text size: ' + txt.style.fontSize);
    }
    if (gmSetValue) {
      await GM.setValue('font-size', currentSize + 5);
    }
  });
  document.querySelector('#decrease')
  .addEventListener ('click', async function() {
    txt = document.getElementById('articles');
    style = window.getComputedStyle(txt, null).getPropertyValue('font-size');
    currentSize = parseFloat(style);
    if (currentSize > 20) {
      txt.style.fontSize = (currentSize - 5) + 'px';
      infoSquare('Text size: ' + txt.style.fontSize);
    }
    if (gmSetValue) {
      await GM.setValue('font-size', currentSize - 5);
    }
  });
//  return document;
//}

// TODO Change variable 'currentEntry' upon scrolling
//function navigation(document) {
  let entries = document.querySelectorAll('.entry').length - 1;
  var currentEntry = -1;
  document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.shiftKey && e.which == 40) {
      currentEntry = itemNext(entries, currentEntry);
    }
  });
  document.querySelector('#next')
  .addEventListener ('click', function() {
    currentEntry = itemNext(entries, currentEntry);
  });
  document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.shiftKey && e.which == 38) {
      currentEntry = itemPrevious(entries, currentEntry);
    }
  });
  document.querySelector('#previous')
  .addEventListener ('click', function() {
    currentEntry = itemPrevious(entries, currentEntry);
  });
//  return document;
//}

//function direction(document) {
  let dire = document.querySelector('#direction');
  dire.addEventListener ('click', function() {
    if (document.dir == 'ltr' || !document.dir) {
      document.dir = 'rtl';
      dire.textContent = 'RTL'; // ❰
      dire.title = 'Switch to Left-to-right direction';
      infoSquare('Right-to-left');
    } else {
      document.dir = 'ltr';
      dire.textContent = 'LTR'; // ❱
      dire.title = 'Switch to Right-to-left direction';
      infoSquare('Left-to-right');
    }
  });
//  return document;
//}

  let aboutMuc = document.querySelector('#about-muc');
  document.querySelector('#about-muc')
  .addEventListener ("click", function() {
    location.href = 'xmpp:syndication@conference.movim.eu?join';
  });

//function supportPage(document) {
  document.body.insertAdjacentHTML('beforeend', htmlSupport);
  let pageSupport = document.querySelector('#page-support');
  document.querySelector('#about-support')
  .addEventListener ("click", function() {
    pageSupport.style.display = 'block';
  });
  // freedos at sourceforge won't allow inline ondblclick
  // ondblclick="this.style.display = &quot;none&quot;"
  document.querySelector('#page-support .return-to-feed')
  .addEventListener ("click", function() {
      pageSupport.style.display = 'none';
    });
//  return document;
//}

//function helpPage(document) {
  document.body.insertAdjacentHTML('beforeend', htmlAbout);
  let pageAbout = document.querySelector('#about-help');
  pageAbout.addEventListener ('click', function() {
    document.querySelector('#page-about').style.display = 'block';
  });
  // freedos at sourceforge won't allow inline ondblclick
  // ondblclick="this.style.display = &quot;none&quot;"
  /*
  let pageSupport = document.querySelector('#page-about');
  pageSupport.addEventListener ('dblclick', function() {
    document
    .querySelector('#page-about')
    .style
    .display = 'none';
  });
  */
//  return document;
//}
 
//function instructions() {
  let gecko = isGecko();
  if (gecko) {
    let software = gecko[0].toUpperCase() + gecko.substring(1);
    document.querySelector('#page-about')
    .insertAdjacentHTML('afterbegin', helpGecko);
    document.querySelector('#about-toc')
    .insertAdjacentHTML(
      'afterbegin',
      `
       <li>
         <a href="#open-in-browser">${software} Help: Enable XML-based Feeds</a>
       </li>
       <li>
         <a href="#gecko">${software} Help: Enable JSON-based Feeds</a>
       </li>
      `);
    document.querySelector('#open-in-browser-rules')
    .addEventListener ('click', function() {
      savePage(
        ruleSetOpenInBrowser,
        'streamburner-open-in-browser-ruleset',
        'application/json',
        'json'
      )
    });
  }
 
  // Header Editor
  /* softwares = ["waterfox", "librewolf", "seamonkey", "firefox", "chrome", "edge"];
  for (let i = 0; i < softwares.length; i++) {
    if (navigator.userAgent.toLowerCase().includes(softwares[i])) {
      let software = softwares[i][0].toUpperCase() + softwares[i].substring(1);
      document
      .querySelector('#page-about')
      .insertAdjacentHTML('beforeend', helpHeaderEditor);
      document
      .querySelector('#header-editor-install')
      .href = (function () {
        let link;
        switch (softwares[i]) {
          case 'chrome':
            link = 'https://chrome.google.com/webstore/detail/header-editor/eningockdidmgiojffjmkdblpjocbhgh';
            break;
          case 'edge':
            link = 'https://microsoftedge.microsoft.com/addons/detail/header-editor/afopnekiinpekooejpchnkgfffaeceko';
            break;
          default:
            link = 'https://addons.mozilla.org/firefox/addon/header-editor/';
        }
        return link;
      }());
      document
      .querySelector('#about-toc')
      .insertAdjacentHTML(
        'beforeend',
        `<li><a href="#header-editor">${software} Help: Enable syndication feeds with Header Editor</a></li>`);
      document
      .querySelector('#header-editor-rules')
      .addEventListener ('click', function() {
        savePage(
          ruleSetHeaderEditor,
          'streamburner-header-editor-ruleset'
          'application/json',
          'json'
        )
      });
    }
  } */
//}
if (gmGetValue || gmSetValue) {
//  function settingsPage(document) {
  let buttonSettings = document.querySelector('#about-settings');
  document.body.insertAdjacentHTML('beforeend', htmlSettings);
  let pageSettings = document.querySelector('#page-settings');
  buttonSettings.addEventListener ("click", function() {
    if (document.contentType.endsWith('xml')) {
      alert('Settings dialog is disabled for this page due to an unmodifiable XML header.');
      //return;
    } else {
      pageSettings.style.display = 'block';
    }
  });

  // TODO Save setting upon click on button "Save" (does not exist yet)
  //async function settings(document) {
  for (const controller of document.querySelectorAll('#page-settings input, #page-settings select')) {
    let value = await GM.getValue(controller.name);
    switch (controller.type) {

//          case ('select-one'):
//            controller.querySelector(`[value=${value}`).setAttribute('selected', null);
//            break;

      case ('number'):
        controller.setAttribute('value', value);
        break;

      case ('checkbox'):
        if (value == true) {
          controller.setAttribute('checked', null);
        }
        break;

      case ('radio'):
        if (value == controller.id) {
          controller.setAttribute('checked', null);
        }
        break;
    }

    controller.addEventListener ('input', async function() {
    //controller.addEventListener ('click', function() {
      let value, key = this.name;
      if (this.type == 'radio') {
        value = this.id;
      } else
      if (this.checked) {
        value = this.checked;
      } else
      if (this.value) {
        value = this.value;
      }
      await GM.setValue(key, value);
      //console.log(key,':', value);
      //console.log(await GM.listValues());
    });
  }

  document.querySelector('#page-settings #close')
  .addEventListener ('click', function() {
    document.querySelector('#page-settings')
    .style.display = 'none';
  });

  document.querySelector('#page-settings #reload')
  .addEventListener ('click', function() {
    //window.location.reload(true);
    //window.location.reload();
    location.reload();
  });
//      return document;
//    }
//    return document;
//  }
}

//function compactHelpPage(document) {

  for (const element of document.querySelectorAll('.about-newspaper .decor')) {
    element.classList.add('hide');
  }

  for (const element of document.querySelectorAll('.about-newspaper .segment')) {
    if (element.id != 'table-of-contents') {
      element.classList.add('hide');
    }
  }

  for (const element of document.querySelectorAll('#about-toc a, a.link')) {
    element.addEventListener ('click', function() {
      document.querySelector(`${element.href.slice(element.href.indexOf('#'))}`).classList.remove('hide');
      document.querySelector('.about-newspaper .back-to-menu').classList.remove('hide');
      document.querySelector(`.about-newspaper #table-of-contents`).classList.add('hide');
    });
    //element.removeAttribute('href');
  }

  let button = document.querySelector('.about-newspaper .back-to-menu');
  button.classList.add('hide');
  button.addEventListener ('click', function() {
    for (const element of document.querySelectorAll('.segment')) {
      if (element.id != 'table-of-contents') {
        element.classList.add('hide');
      }
    }
    //button.classList.add('hide');
    document.querySelector('#page-about .back-to-menu').classList.add('hide');
    document.querySelector(`#table-of-contents`).classList.remove('hide');
  });

  document.querySelector('#page-about .return-to-feed')
  .addEventListener ('click', function() {
    document.querySelector('#page-about').style.display = 'none';
  });
//  return document;
//}

//function pickRandomFeed(document) {
  //let feeds = document.querySelectorAll('#feeds .content .category a');
  let sections = document.querySelectorAll('#feeds .content .category');
  let section = sections[Math.floor(Math.random()*sections.length)];
  let category = section.querySelector('h3');
  let feeds = section.querySelectorAll('a');
  let feed = feeds[Math.floor(Math.random()*feeds.length)];
  for (const a of document.querySelectorAll('#feeds a.feed-category')) {
    a.textContent = category.outerText;
    a.href = '#' + section.id;
  }
  for (const a of document.querySelectorAll('#feeds a.feed-url')) {
    a.textContent = feed.outerText;
    a.href = feed.href;
  }
//  return document;
//}

//function generateOPML(document) {
/*
<?xml version="1.0" encoding="utf-8"?>
<opml version="1.0">
  <head>
    <title>Liferea Feed List Export</title>
  </head>
  <body>
    <outline title="TITLE" text="TITLE" description="TITLE" type="folder">
      <outline title="TITLE" text="TITLE" description="TITLE" type="rss" xmlUrl="URL"/>
    </outline>
  </body>
</opml>
*/

  document.querySelector('#opml-selection')
  .addEventListener ('click', function() {
    var opmlData = document.implementation.createDocument(null, "opml", null);
    opmlData.getElementsByTagName("opml")[0].setAttribute("version", "1.0");
    var text = opmlData.createTextNode("Newspaper Feed Selection");
    let name = opmlData.createElement("title")
    let head = opmlData.createElement("head")
    let body = opmlData.createElement("body");
    let sections = document.querySelectorAll('#feeds .content .category');
    for (const section of sections) {
      let title = section.querySelector('h3').outerText;
      let category = opmlData.createElement("outline");
      category.setAttribute("title", title);
      category.setAttribute("text", title); // Why twice?
      category.setAttribute("text", title); // Why twice?
      category.setAttribute("type", "folder");
      // TODO Handle subcategories
      let links = section.querySelectorAll('a');
      for (const link of links) {
        let feed = opmlData.createElement("outline");
        let title = link.outerText;
        let url = link.href;
        feed.setAttribute("title", title);
        feed.setAttribute("text", title); // Why twice?
        feed.setAttribute("text", title); // Why twice?
        // NOTE This value (rss) is arbitrary.
        // TODO Add type to class.
        //feed.setAttribute("type", "rss");
        feed.setAttribute("xmlUrl", url);
        category.appendChild(feed);
      }
      body.appendChild(category);
    }
    head.appendChild(name);
    name.appendChild(text);
    opmlData.getElementsByTagName("opml")[0].appendChild(head);
    opmlData.getElementsByTagName("opml")[0].appendChild(body);
    var opmlFile = new XMLSerializer().serializeToString(opmlData);
    savePage(
      opmlFile,
      'i2p-schimon-newspaper',
      'text/x-opml+xml',
      'opml'
    )
  });

  document.querySelector('#opml-selection-even-they')
  .addEventListener ('click', function() {
    var opmlData = document.implementation.createDocument(null, "opml", null);
    opmlData.getElementsByTagName("opml")[0].setAttribute("version", "1.0");
    var text = opmlData.createTextNode("Newspaper Newsreel Selection");
    let name = opmlData.createElement("title")
    let head = opmlData.createElement("head")
    let body = opmlData.createElement("body");
    let sections = document.querySelectorAll('#page-about #even h3');
    for (const section of sections) {
      let title = section.outerText;
      let category = opmlData.createElement("outline");
      category.setAttribute("title", title);
      category.setAttribute("text", title);
      category.setAttribute("type", "folder");
      list = section.nextElementSibling // #page-about #even h3 + ul a:not(.not-an-xml)
      let lines = list.querySelectorAll('li');
      for (const line of lines) {
        link = line.querySelector('a:not(.not-an-xml)');
        if (link) {
          let feed = opmlData.createElement("outline");
          let title = link.outerText;
          let desc = line.outerText;
          let url = link.href;
          feed.setAttribute("title", title);
          feed.setAttribute("text", desc);
          // NOTE This value (rss) is arbitrary.
          // TODO Add type to class.
          //feed.setAttribute("type", "rss");
          feed.setAttribute("xmlUrl", url);
          category.appendChild(feed);
        }
      }
      body.appendChild(category);
    }
    head.appendChild(name);
    name.appendChild(text);
    opmlData.getElementsByTagName("opml")[0].appendChild(head);
    opmlData.getElementsByTagName("opml")[0].appendChild(body);
    var opmlFile = new XMLSerializer().serializeToString(opmlData);
    savePage(
      opmlFile,
      'i2p-schimon-newspaper-even-they',
      'text/x-opml+xml',
      'opml'
    )
  });
//  return document;
//}

//function settleFilters(document) {
  // Hide all links to software that are not of news
  for (const element of document.querySelectorAll('#software > div.content a')) {
    //if (element.className != 'news') {
    if (!element.className.includes('news')) {
      element.classList.add('hide');
    }
  }

  // Create toggle mechanism
  for (const element of document.querySelectorAll('.filter')) { // #filter > span
    if (element.id != 'news') {
      element.classList.toggle('grey');
    }
    element.addEventListener ('click', function() {
      element.classList.toggle('grey');
      for (const span of document.querySelectorAll(`.${element.id}`)) {
        span.classList.toggle('hide');
      }
    });
  }

  // TODO set class="background" to system by navigator.platform
  // TODO switch () { case }
  if (navigator.platform.toLowerCase().includes('ubuntu'))  {
        document.querySelector('#ubports').classList.add('background');
  } else
  if (navigator.platform.toLowerCase().includes('tizen'))  {
        document.querySelector('#tizen').classList.add('background');
  } else
  if (navigator.platform.toLowerCase().includes('sailfish'))  {
        document.querySelector('#sailfish-os').classList.add('background');
  } else
  if (navigator.platform.toLowerCase().includes('kai'))  {
        document.querySelector('#gerda-os').classList.add('background');
  } else
  if (navigator.platform.toLowerCase().includes('android'))  {
        document.querySelector('#android-os').classList.add('background');
  } else
  if (navigator.platform.toLowerCase().includes('linux') ||
      navigator.platform.toLowerCase().includes('bsd')) {
        document.querySelector('#unix').classList.add('background');
  } else
  if (navigator.platform.toLowerCase().includes('mac'))  {
        document.querySelector('#mac-os').classList.add('background');
  } else
  if (navigator.platform.toLowerCase().includes('windows') ||
      navigator.platform.toLowerCase().includes('react'))  {
        document.querySelector('#react-os').classList.add('background');
  } else
  if (navigator.platform.toLowerCase().includes('ipad') ||
      navigator.platform.toLowerCase().includes('iphone'))  {
        document.querySelector('#ios').classList.add('background');
  }
//  return document;
//}

//function statusBar(document) {

  // Display entry title in status bar
  for (const element of document.querySelectorAll('.entry')) {
    element.addEventListener ('mouseover', function() {
      infoSquare(`${this.querySelector('.title > a').textContent}`);
    });
  }

  // Prepare links to be used with status bar
  for (const element of document.querySelectorAll('#buttons-action *, #buttons-control *, #articles > a, #toc a, footer *')) {
    element.addEventListener ('mouseover', function() {
      //infoSquare(this.title);
      if (this.title) {
        this.setAttribute('info', this.title);
        this.removeAttribute('title');
      }
      //infoSquare(`<b>Info:&nbsp</b> ${this.getAttribute('info')}`);
      infoSquare(`${this.getAttribute('info')}`);
    });
  }

  // Remove status bar
  for (const element of document.querySelectorAll('#links-bar, footer')) {
  //for (const element of document.querySelectorAll('#links-bar a')) {
    element.addEventListener ('mouseleave', function() { // mouseout
      if (document.querySelector('#info-square')) {
        document.querySelector('#info-square').remove();
      }
    });
  }
//  return document;
//}

//function bittorrent(document) {
  document
  //.querySelector('.category:has(#torrents)')
  //.parentElement
  .querySelector('#torrents')
  .addEventListener ('mouseover', function() {
    document
  .querySelector('#torrents h3')
  //.innerHTML = `<span class="text-icon orange">RSS</span> &amp; BitTorrent. It's A Neverending Love Story...`;
  .innerHTML = `<span class="text-icon orange">Feeds</span> &amp; BitTorrent. The NeverEnding Story.`;
  // TODO Add animated effect which will be activated upon each event mouseover
  });
//  return document;
//}

//function noReferrer(document) {
  for (const element of document.querySelectorAll('a[href]')) {
    element.rel = 'noreferrer';
  }
//  return document;
//}

}

// TODO
// The following events don't work on some pages: https://momi.ca/feed.xml
// Perhaps, confine them to some type of window.onload = (event) => { CODE }
// /questions/381744/is-there-anyway-to-change-the-content-type-of-an-xml-document-in-the-xml-docume
// /questions/23034283/is-it-possible-to-use-htmls-queryselector-to-select-by-xlink-attribute-in-an

function truncateToc(newDocument) {
  for (const titleToc of newDocument.querySelectorAll('#toc > li > a')) {
    if (titleToc.textContent.length > 70) {
      titleToc.title = titleToc.textContent;
      titleToc.textContent =
        titleToc
        .textContent
        .substring(0, 70) + ' […]';
    }
  }
  return newDocument;
}

function isGecko() {
  // Gecko
  let softwares = ["waterfox", "librewolf", "seamonkey", "thunderbird", "firefox"];
  for (let i = 0; i < softwares.length; i++) {
    if (navigator.userAgent.toLowerCase().includes(softwares[i])) {
      return softwares[i];
    }
  }
}

function isMoz() {
  let softwares = ["seamonkey", "thunderbird", "firefox"];
  for (let i = 0; i < softwares.length; i++) {
    if (navigator.userAgent.toLowerCase().includes(softwares[i])) {
      return softwares[i];
    }
  }
}

function setBanner(newDocument) {
  let aElement = newDocument.createElement('a');
  aElement.href = 'https://www.falkon.org/?ref=newspaper';
  aElement.id = 'feed-banner';
  newDocument.body.append(aElement);
  aElement.insertAdjacentHTML('beforeend', banner);
  return newDocument;
}

function setQuote(newDocument) {
  let divElement = newDocument.createElement('div');
  divElement.id = 'feed-quote';
  newDocument.body.append(divElement);
  divElement.insertAdjacentHTML('beforeend', quote);
  return newDocument;
}

// TODO Write this function in a sensible manner
function getHomeLink(xmlFile, xmlRules) {
  let url = null;
  //console.log(xmlFile.querySelectorAll(xmlRules.feedLink))
  let links = xmlFile.querySelectorAll(xmlRules.feedLink)
  //links.forEach(link => {
  //  if (link.getAttribute('rel') == 'alternate') {
  //    url = link.getAttribute('href');
  //  }
  //})
  for (link of links) {
    if (link.getAttribute('rel') == 'alternate') {
      url = link.getAttribute('href');
      break;
    }
  }
  for (link of links) {
    if (url) { break; }
    let rel = link.getAttribute('rel');
    if (rel && rel != 'alternate') { continue; }
    if (link.getAttribute('href')) {
      url = link.getAttribute('href');
      break;
    }
  }
  for (link of links) {
    if (url) { break; }
    let rel = link.getAttribute('rel');
    if (rel && rel != 'alternate') { continue; }
    if (link.textContent.length > 0) {
      url = link.textContent;
      break;
    }
  }

  // let links = xmlFile.querySelectorAll(xmlRules.feedLink), url = null;
  // 
  // for (let link of links) {
  //   if (url) break; // if url is already assigned, break the loop

  //   let rel = link.getAttribute('rel');
  //   if (['hub', 'self', 'search'].includes(rel)) {
  //     break;
  //   }
  //   if (link.getAttribute('rel') == 'alternate') {
  //     url = link.getAttribute('href');
  //   } else if (link.textContent.length > 0) {
  //     url = link.textContent;
  //   }
  // }

  // SMF
  if (xmlFile.getElementsByTagName('smf:xml-feed')[0] &&
      xmlFile.getElementsByTagName('smf:xml-feed')[0].getAttribute('forum-url')) {
    url = xmlFile
          .getElementsByTagName('smf:xml-feed')[0]
          .getAttribute('forum-url');
          //.getAttribute('source');
  }

  if (url) {
    //if (url == document.baseURI) {
    // TODO https://aur.archlinux.org/rss/ and https://aur.archlinux.org/rss
    urlNow = document.baseURI.substring(document.baseURI.indexOf(':'));
    urlNew = url.substring(url.indexOf(':'));
    if (urlNew == urlNow ||             // Case HTTP and HTTPS
        urlNew.slice(0,-1) == urlNow || // Case rss and rss/
        urlNew == urlNow.slice(0,-1)) { // Case rss/ and rss
      url = document.location.protocol + '//' + document.location.hostname;
    }
    return url;
//} else {
//  return location.protocol + '//' + location.hostname;
  }
}

// FIXME https://lw1.at/en/postfeed.xml
function getDateXML(xmlFile, xmlRules) {
  let date;
  //if (xmlFile.getElementsByTagName('smf:xml-feed')[0]) {
  //  date = xmlFile.getElementsByTagName('smf:xml-feed')[0].getAttribute('generated-date-UTC');
  //} else
  if (xmlFile.querySelector(xmlRules.feedDate)) {
    date = xmlFile.querySelector(xmlRules.feedDate).textContent;
  } else
  if (xmlFile.querySelector(xmlRules.feedItemDate)) {
    date = xmlFile.querySelector(xmlRules.feedItemDate).textContent;
  } else
  if (xmlFile.querySelector(xmlRules.feedItemPublished)) {
    date = xmlFile.querySelector(xmlRules.feedItemPublished).textContent;
  } else {
    return null;
  }
  return date;
}

function feedInfoXML(newDocument, xmlFile, xmlRules, type) {
  // metadata
  let
    keys =   [
      'language',
      'document.contentType',
      'description',
      'link',
      'generator',
      'updated',
      'type'],
    rules =  [
      null,
      null,
      xmlRules.feedSubtitle,
      null,
      xmlRules.feedGenerated,
      null,
      null];
    values = [
      newDocument.querySelector('html').lang,
      newDocument.contentType,
      null,
      getHomeLink(xmlFile, xmlRules),
      null,
      getDateXML(xmlFile, xmlRules),
      type];
  for (let i = 0; i < keys.length; i++) {
    let meta = newDocument.createElement('meta');
    let name = keys[i];
    let content;
    if (values[i]) {
      content = values[i];
    } else
    if (xmlFile.querySelector(rules[i])) {
      content = xmlFile.querySelector(rules[i]).textContent;
    }
    if (content) {
      meta.setAttribute('name', name);
      meta.setAttribute('content', content);
      newDocument.head.appendChild(meta);
    }
  }

  let divElement = newDocument.createElement('div');
  divElement.id = 'feed-info';
  let spanElement = newDocument.createElement('span');
  if (generator = xmlFile.querySelector(xmlRules.feedGenerated)) {
    spanElement.textContent = `${type} : ${generator.textContent}`
  } else {
    spanElement.textContent = type;
  }
  divElement.append(spanElement);
  if (date = xmlFile.querySelector(xmlRules.feedDate)) {
    // FIXME No date for https://www.parlament.mt/en/rss/?t=calendar
    let spanElement = newDocument.createElement('span');
    spanElement.innerHTML = ` : Updated at <span class="published">${date.textContent}</span>`;
    divElement.append(spanElement);
  }
  newDocument.body.append(divElement);
  return newDocument;
}

function feedInfoJSON(newDocument, jsonFile, homeRule, generatedRule, versionRule, dateRule, type) {
  // metadata
  let
    keys =   [
      'language',
      'document.contentType',
      'link',
      'generator',
      'version',
      'updated',
      'type'],
    rules =  [
      null,
      null,
      homeRule,
      generatedRule,
      versionRule,
      dateRule,
      null];
    values = [
      newDocument.querySelector('html').lang,
      newDocument.contentType,
      homeRule,
      null,
      null,
      null,
      type];
  for (let i = 0; i < keys.length; i++) {
    let meta = newDocument.createElement('meta');
    let name = keys[i];
    let content;
    if (values[i]) {
      content = values[i];
    } else
    if (rules[i]) {
      content = rules[i];
    }
    if (content) {
      meta.setAttribute('name', name);
      meta.setAttribute('content', content);
      newDocument.head.appendChild(meta);
    }
  }

  let divElement = newDocument.createElement('div');
  divElement.id = 'feed-info';
  let spanElement = newDocument.createElement('span');
  if (generator = generatedRule) {
    spanElement.textContent = `${type} : ${generator}`
  } else {
    spanElement.textContent = type;
  }
  divElement.append(spanElement);
  if (date = dateRule) {
    let spanElement = newDocument.createElement('span');
    spanElement.innerHTML = ` : Updated at <span class="published">${date}</span>`;
    divElement.append(spanElement);
  }
  newDocument.body.append(divElement);
  return newDocument;
}

// FIXME Falkon
// Blocked due to server policy
// https://archlinux.org/feeds/packages/
// https://www.openstreetmap.org/traces/rss
// https://artemislena.eu/feed.json
// https://pypi.org/rss/updates.xml

function hideQuote(newDocument) {
  newDocument
  .querySelector('.quote.content')
  .addEventListener ('dblclick', function() {
    newDocument
  .querySelector('.quote.content')
  .style
  .display = 'none';
  });
  return newDocument;
}

function _subToMe(instance) {
  for (const element of document.querySelectorAll('.subscribe-link')) {
    element.href = `https://${instance}/#/subscribe?feeds=${location.href}`;
  }
}

function subToMe(instance) {
  for (const service of document.querySelectorAll('.subscribe-link')) {
    if (document.contentType.endsWith('xml')) {
      service.href = `https://${instance}/#/subscribe?feeds=${location.href}`;
    } else {
      service.removeAttribute('href');
      service.addEventListener ('click', function() {
      (function(btn){
        let z = document.createElement('script');
        document.subtomeBtn = btn;
        z.src = `https://${instance}/load.js`;
        document.body.appendChild(z);
      })(service);
        return false;
      });
    }
  }
}

async function toggleMode() {
  cssSelectors = [
    'body', 'code', 'a', '.enclosures', '#empty-feed'];
    try {
      if (await GM.getValue('view-mode') == 'dark') {
        await GM.setValue('view-mode', 'bright');
        //mode.textContent = 'Light View';
        //mode.textContent = '💡';
        //mode.textContent = '◐';
        mode.style.filter = 'saturate(7)'; // revert
        mode.title = 'Switch to dark mode';
        infoSquare('Bright mode');
        for (cssSelector of cssSelectors) {
          for (element of document.querySelectorAll(cssSelector)) {
            element.classList.remove('dark');
          }
        }
      } else {
        await GM.setValue('view-mode', 'dark');
        //mode.textContent = 'Dark View';
        //mode.textContent = '🌙';
        //mode.textContent = '●';
        mode.style.filter = 'brightness(0.5)'; // invert
        mode.title = 'Switch to bright mode';
        infoSquare('Dark mode');
        for (cssSelector of cssSelectors) {
          for (element of document.querySelectorAll(cssSelector)) {
            element.classList.add('dark');
          }
        }
      }
    } catch { // Greasemonkey API Not Available
      if (document.querySelector('#feed .dark')) {
        mode.style.filter = 'saturate(7)'; // revert
        mode.title = 'Switch to bright mode';
        infoSquare('Dark mode');
        for (cssSelector of cssSelectors) {
          for (element of document.querySelectorAll(cssSelector)) {
            element.classList.remove('dark');
          }
        }
      } else {
        mode.style.filter = 'brightness(0.5)'; // invert
        mode.title = 'Switch to dark mode';
        infoSquare('Bright mode');
        for (cssSelector of cssSelectors) {
          for (element of document.querySelectorAll(cssSelector)) {
            element.classList.add('dark');
          }
        }
      }
    }
}

/*
function toggleMode() {
  let mode = document.querySelector('#mode');
  mode.addEventListener ('click', function() {
    cssSelectors = [
      'body', 'code', 'a', '.enclosures', '#empty-feed'];
    for (cssSelector of cssSelectors) {
      for (element of document.querySelectorAll(cssSelector)) {
        //element.style.color = 'WhiteSmoke';
        element.classList.toggle('dark');
      }
    }
    if (document.querySelector('body.dark')) {
      mode.textContent = 'Light View';
      mode.title = 'Switch to bright mode';
    } else {
      mode.textContent = 'Dark View';
      mode.title = 'Switch to dark mode';
    }
    //document.querySelector('#links-bar > a:nth-child(1)').style.color = '#333';
    //document.body.style.background = '#333';
  });
}
*/

function itemNext(entries, currentEntry) {
  //currentEntry = entries[currentEntry - 1];
  if (currentEntry < entries) {
    currentEntry += 1;
  }
  if (currentEntry > 0) {
    document.querySelectorAll('.entry')[currentEntry].previousElementSibling.scrollIntoView();
  } else {
    document.querySelectorAll('.entry')[currentEntry].parentElement.scrollIntoView();
  }
  return currentEntry;
}

function itemPrevious(entries, currentEntry) {
  //currentEntry = entries[currentEntry - 1];
  if (currentEntry > 0) {
    currentEntry -= 1;
  }
  if (currentEntry > 0) {
    document.querySelectorAll('.entry')[currentEntry].previousElementSibling.scrollIntoView();
  } else {
    document.querySelectorAll('.entry')[currentEntry].parentElement.scrollIntoView();
  }
  return currentEntry;
}


  /*
  window.addEventListener ('hashchange', function() {
    document.querySelector('#links-bar').style.display = 'none';
  });
  */

  /*
  window.addEventListener ('scroll', function() {
    const elementTitle = document.querySelector('#title');
    const elementStyle = document.getElementById(namespace);
    if (isInViewport(elementTitle)) {
      elementStyle.textContent = stylesheetBase;
    } else {
      elementStyle.textContent = stylesheetBase + stylesheetBar;
    }
  });
  */

  /*
  // FIXME This is a safer fashion to do this task,
  //       specifically against server policy.
  // NOTE Element is created, albeit without type="text/css",
  //      but no change applied, not even with !important
  window.addEventListener ('scroll', function() {
    const elementTitle = document.querySelector('#subtitle');
    let elementStyle = document.querySelector('#bar');
    if (isInViewport(elementTitle) && elementStyle) {
      if (elementStyle) {
        elementStyle.remove();
      }
    } else if (!elementStyle) {
      elementStyle = document.createElement('style');
      document.head.append(elementStyle);
      elementStyle.textContent = stylesheetBar;
      elementStyle.type = 'text/css';
      elementStyle.id = 'bar';
    }
  });
  */

function imageData() {
  /* TODO handle loading of images by saving bandwidth
  document.body.addEventListener ('mouseover', function(e) {
    if (e.target && e.target.nodeName == "IMG" && !e.target.src) {
      console.log('DELEGATED');
      source = e.target.getAttribute('src-data');
      e.target.removeAttribute('src-data');
      e.target.src = source;
    }
  });

  for (const image of document.querySelectorAll('img')) {
    image.addEventListener('mouseover', loadImage(image));
    //image.onmouseover = () => {
    //  image.removeEventListener('mouseover',loadImage(image));
    //}
  }
  */

  /*
  for (const image of document.querySelectorAll('img')) {
    image.addEventListener('focus',event => {
    //image.addEventListener('mouseover',event => {
      if (image.getAttribute('src-data')) {
        //toggleAttribute(image);
        source = image.getAttribute('src-data');
        image.removeAttribute('src-data');
        image.src = source;
      }
    }, {passive: true});
    image.onmouseover = () => {
      if (image.getAttribute('src-data')) {
        //toggleAttribute(image);
        source = image.getAttribute('src-data');
        image.removeAttribute('src-data');
        image.src = source;
      }
    };
  }
  */
}

// Create status bar
function infoSquare(text) {
  if (document.querySelector('#info-square')) {
    document.querySelector('#info-square').remove();
  }
  let divElement = document.createElement('div');
  divElement.id = 'info-square';
  //divElement.innerHTML = text; // codeberg feeds
  // TODO Sanitize titles from HTML tags and re-place them.
  // NOTE divElement.innerHTML raises error for some title
  // of https://events.ccc.de/feed
  divElement.textContent = text;
  document.body.append(divElement);
}

// /questions/123999/how-can-i-tell-if-a-dom-element-is-visible-in-the-current-viewport
// https://www.javascripttutorial.net/dom/css/check-if-an-element-is-visible-in-the-viewport/
function isInViewport(element) {
  const rect = element.getBoundingClientRect();
  return (
    rect.top >= 0 &&
    rect.left >= 0 &&
    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
    rect.right <= (window.innerWidth || document.documentElement.clientWidth)
  );
}

function loadImage(image) {
  //image.removeEventListener('mouseover',loadImage(image));
  console.log('onmouseover');
  let source = image.getAttribute('src-data');
  image.removeAttribute('src-data');
  image.src = source;
}

/* TODO handle loading of images by saving bandwidth
function toggleAttribute(image) {
    source = image.getAttribute('src-data');
    image.removeAttribute('src-data');
    image.src = source;
}
*/

/* TODO handle loading of images by saving bandwidth
for (const image of document.querySelectorAll('img')) {
  //source = image.src;
  //image.removeAttribute('src');
  //image.setAttribute('src-data', source);
  image.setAttribute('src-data', image.src);
  image.removeAttribute('src');
}
*/

/* TODO remove or parse <aside> or refer to XSLT to parse it as HTML
// https://web.dev/feed.xml
// /questions/9848465/js-remove-a-tag-without-deleting-content
for (const aside of document.querySelectorAll('aside')) {
  aside.remove();
}
*/

function getNodeByXPath(node, query) { // FIXME
  res = document.evaluate(
    query, node, null,
    XPathResult.ANY_UNORDERED_NODE_TYPE);
  nRes = result.singleNodeValue;
  return nRes;
}

function queryByXPath(node, queries) {
  let result, i = 0;
  do {
    result = document.evaluate(
      queries[i], document,
      null, XPathResult.STRING_TYPE);
    i = i + 1;
    result = result.stringValue;
  } while (!result && i < queries.length);
  return result;
}

function pageLoader() {

  let
    newDocument, insertDocument, removeDocument;

  // /questions/6464592/how-to-align-entire-html-body-to-the-center
  const
    loadPage = `
<html>
  <head>
    <title>Newspaper</title>
    <style>
      html, body {
        height: 100%; }

      html {
        display: table;
        margin: auto; }

      body {
        display: table-cell;
        vertical-align:middle;
        background-color: #f1f1f1;
        font-family: system-ui;
        cursor:default;
        user-select: none;
        max-height: 100%;
        max-width: 100%; }

      div {
        text-align: center;
        font-size: 3vw;
        font-style: italic; }

      #title {
        font-size: 5vw;
        font-style: unset;
        font-weight: bold; }
    </style>
  </head>
  <body>
    <div id="title">📰 Newspaper</div>
    <div>Loading news feed. Please wait…</div>
  </body>
</html>`,
    domParser = new DOMParser();

  newDocument = domParser.parseFromString(loadPage, 'text/html');
  insertDocument = document.importNode(newDocument.documentElement, true);
  removeDocument = document.documentElement;
  document.replaceChild(insertDocument, removeDocument);
}

// export file
// /questions/4545311/download-a-file-by-jquery-ajax
// /questions/43135852/javascript-export-to-text-file
var savePage = (function () {
  var a = document.createElement("a");
  // document.body.appendChild(a);
  // a.style = "display: none";
  return function (fileData, fileName, fileType, fileExtension) {
    var blob = new Blob([fileData], {type: fileType}),
        url = window.URL.createObjectURL(blob);
    a.href = url;
    a.download = fileName + '.' + fileExtension;
    a.click();
    window.URL.revokeObjectURL(url);
  };
}());

(async function registerMenuCommand(){
  if (typeof GM !== 'undefined' && typeof GM.registerMenuCommand === 'function') {
    await GM.registerMenuCommand('Toggle mode', () => toggleMode(), 'T');
  } else {
    console.warn('Greasemonkey API GM.registerMenuCommand does not seem to be available');
  }
})();
